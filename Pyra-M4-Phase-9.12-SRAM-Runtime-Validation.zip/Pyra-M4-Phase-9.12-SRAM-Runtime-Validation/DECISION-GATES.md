# Phase 9.12 test gates

| Gate | Why | Pass criterion |
|---|---|---|
| G0 | Proven kernel unchanged | Running Phase 9.11.5 kernel exposes `pyra15_boot_once=Y` |
| G1 | No reset conflict | `pyra_cpu0_only=Y`, `pyra10_ammu_probe=Y`, old repair flags `N` |
| G2 | Safe single start | remoteproc offline and separate `m4base` kernel image exists |
| G3 | Correct firmware bytes | pinned SHA-256 of `pyra-m4-sram-v12.elf` and static ELF contract |
| G4 | Assembly and initializer execution | `M12A` and `M12I` at exact trace offsets |
| G5 | C runtime | `M12B`, `M12C`, `OK=1`, no `M12F` or `ERR` |
| G6 | Living application | 4 valid samples with strictly advancing 32-bit `HB=` |
| G7 | Failure containment | no automatic restart; preserve logs; reboot to known-good `m4base` on errors |

A `PYRA9115: RELEASE_ALLOWED` event or remoteproc `running` does **not** pass G4–G6 by itself. The C runtime result is not confirmed until the new firmware itself writes M12 markers and moving HB value.
