/* OMAP5432 local L2 SRAM runtime validation (Phase 9.12).
 * Deliberately NO libc, time/interrupt, MMIO, DDR or C++ runtime.
 * All writes stay inside the first 4 KiB of local boot SRAM.
 */
#include <stdint.h>
#include <stddef.h>
extern volatile uint8_t trace_data[512];
extern volatile uint32_t scratch_words[128];

/* These must be installed by startup assembly, not pre-copied by host. */
volatile uint32_t data_cookie = 0x13579BDFu;
volatile uint32_t data_cookie_b = 0x2468ACE0u;
volatile uint32_t bss_cookie;
volatile uint32_t heartbeat_count;

static void marker(unsigned offset, uint8_t last)
{
    trace_data[offset] = 'M';
    trace_data[offset + 1] = '1';
    trace_data[offset + 2] = '2';
    trace_data[offset + 3] = last;
    trace_data[offset + 4] = '\n';
    __asm__ volatile ("dsb sy" ::: "memory");
}

static void hex8(unsigned offset, uint32_t value)
{
    static const char hexdigits[16] = "0123456789ABCDEF";
    for (unsigned i = 0; i < 8; ++i) {
        trace_data[offset + 7 - i] = (uint8_t)hexdigits[value & 15u];
        value >>= 4;
    }
}

__attribute__((noreturn)) static void fail(uint32_t code)
{
    /* A failure must be visible before debugfs stops at the first NUL. */
    trace_data[20] = 'E';
    trace_data[21] = 'R';
    trace_data[22] = 'R';
    trace_data[23] = '=';
    hex8(24u, code);
    trace_data[32] = '\n';
    trace_data[33] = 0;
    marker(15u, 'F');
    __asm__ volatile ("dsb sy" ::: "memory");
    for (;;) __asm__ volatile ("wfi");
}

__attribute__((noreturn)) void main(void)
{
    volatile uint32_t stack_probe = 0x4A7E239Du;
    uintptr_t stack_addr = (uintptr_t)&stack_probe;
    marker(10u, 'B'); /* executing compiled C with a live stack */

    if (stack_addr < 0x00000C00u || stack_addr >= 0x00001000u ||
        stack_probe != 0x4A7E239Du) fail(0x00000001u);
    if (data_cookie != 0x13579BDFu || data_cookie_b != 0x2468ACE0u)
        fail(0x00000002u);
    if (bss_cookie != 0 || heartbeat_count != 0)
        fail(0x00000003u);
    bss_cookie = 0x6B2D49E1u;
    if (bss_cookie != 0x6B2D49E1u) fail(0x00000004u);

    /* Volatile scratch test: every word, both endpoints, no stack/trace overlap. */
    for (uint32_t i = 0; i < 128u; ++i)
        scratch_words[i] = 0xA5A50000u ^ (i * 0x01010101u);
    __asm__ volatile ("dsb sy" ::: "memory");
    for (uint32_t i = 0; i < 128u; ++i)
        if (scratch_words[i] != (0xA5A50000u ^ (i * 0x01010101u)))
            fail(0x00010000u | i);

    trace_data[20] = 'H'; trace_data[21] = 'B'; trace_data[22] = '=';
    hex8(23u, 0);
    trace_data[31] = '\n';
    trace_data[32] = 'O'; trace_data[33] = 'K'; trace_data[34] = '=';
    trace_data[35] = '1'; trace_data[36] = '\n';
    trace_data[37] = 0;
    __asm__ volatile ("dsb sy" ::: "memory");
    marker(15u, 'C');  /* all .data/.bss/stack/scratch tests passed */

    for (;;) {
        /* Busy-wait avoids untested timer, IRQ, clock or external MMIO. */
        for (volatile uint32_t delay = 0; delay < 500000u; ++delay)
            __asm__ volatile ("nop" ::: "memory");
        uint32_t n = ++heartbeat_count;
        hex8(23u, n);
        __asm__ volatile ("dsb sy" ::: "memory");
    }
}
