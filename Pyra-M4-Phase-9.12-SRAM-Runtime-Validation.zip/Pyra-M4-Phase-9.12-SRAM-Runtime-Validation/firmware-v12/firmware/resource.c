/* The Linux resource table is not addressed by Cortex-M4 at runtime. */
#include <stdint.h>
#include <stddef.h>
#define TRACE_LOADER_DA 0x20000800u
#define TRACE_LENGTH 512u
struct __attribute__((packed)) fw_rsc_trace {
    uint32_t type, da, len, reserved;
    char name[32];
};
struct __attribute__((packed)) fw_rsc_table {
    uint32_t version, num, reserved[2], offset[1];
    struct fw_rsc_trace trace;
};
_Static_assert(offsetof(struct fw_rsc_table, trace) == 20, "table offset");
_Static_assert(sizeof(struct fw_rsc_table) == 68, "table ABI");
__attribute__((used, section(".resource_table"), aligned(4)))
const struct fw_rsc_table resources = {
    .version = 1, .num = 1, .offset = {20},
    .trace = {2, TRACE_LOADER_DA, TRACE_LENGTH, 0, "pyra_m4_v12_sram"}
};
__attribute__((used, section(".tracebuf"), aligned(4)))
volatile uint8_t trace_data[TRACE_LENGTH];
__attribute__((used, section(".scratch"), aligned(4)))
volatile uint32_t scratch_words[128];
