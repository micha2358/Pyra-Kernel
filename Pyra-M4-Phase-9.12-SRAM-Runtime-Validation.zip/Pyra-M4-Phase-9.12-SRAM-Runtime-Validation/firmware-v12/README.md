# Phase 9.12 bare-metal Cortex-M4 firmware

This subproject extends the **proven v5 instruction-fetch test** with a real assembly-to-C runtime, SRAM data/scratch tests, and a live trace heartbeat. See `../README.md` for safety gates, exact memory map and boot procedure.

Use `make USE_CLANG=1` for Clang+LLD, `make` for `arm-none-eabi-gcc` when available. The release archive contains a prebuilt validated ELF and map. Rebuilding can change its SHA-256; the start script refuses unreviewed binaries on purpose.
