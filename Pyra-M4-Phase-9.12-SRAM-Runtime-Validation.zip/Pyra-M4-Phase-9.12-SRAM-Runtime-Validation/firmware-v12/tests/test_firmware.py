import importlib.util
import io
import shutil
import struct
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ELF = ROOT / 'build/pyra-m4-sram-v12.elf'

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj

verify = module('v12_elf', ROOT/'tools/check_elf.py')
trace = module('v12_trace', ROOT/'tools/check_trace.py')
boot = module('v12_boot', ROOT/'tools/check-boot-entry.py')

class ElfTests(unittest.TestCase):
    def test_valid(self):
        with redirect_stdout(io.StringIO()):
            verify.check(ELF)

    def mutate(self, offset, value):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)/'mutant.elf'
            contents = bytearray(ELF.read_bytes())
            contents[offset:offset+len(value)] = value
            p.write_bytes(contents)
            with self.assertRaises(ValueError):
                with redirect_stdout(io.StringIO()):
                    verify.check(p)

    def test_elf_entry_blocked(self):
        self.mutate(24, struct.pack('<I', 0x45))

    def test_msp_blocked(self):
        self.mutate(0x10000, struct.pack('<I', 0xDEADBEEF))

    def test_resource_extra_count_blocked(self):
        self.mutate(0x11004, struct.pack('<I', 2))

    def test_data_initializer_tampering_blocked(self):
        self.mutate(0x10680, bytes(8))

    def test_resource_iommu_type_blocked(self):
        self.mutate(0x11014, struct.pack('<I', 0))

class TraceTests(unittest.TestCase):
    def frame(self, hb=0, status=b'OK=1\n'):
        return b'M12A\nM12I\nM12B\nM12C\nHB='+f'{hb:08X}'.encode()+b'\n'+status

    def test_parse(self):
        self.assertEqual(trace.parse(self.frame(0x1234)), 0x1234)

    def test_fault(self):
        with self.assertRaises(ValueError):
            trace.parse(b'M12A\nM12I\nM12B\nM12F\nERR=00000002\n')

    def test_missing_init(self):
        with self.assertRaises(ValueError):
            trace.parse(b'M12A\nM12B\nM12C\nHB=00000003\nOK=1\n')

    def test_missing_c_ready(self):
        with self.assertRaises(ValueError):
            trace.parse(self.frame(status=b'OK=0\n'))

    def test_wrap_progress(self):
        self.assertTrue(trace.advanced(0xFFFFFFFE, 1))
        self.assertFalse(trace.advanced(7, 7))
        self.assertFalse(trace.advanced(8, 7))

    def test_progress(self):
        with tempfile.TemporaryDirectory() as td:
            f = Path(td)/'trace'
            f.write_bytes(self.frame(2))
            i = [2]
            def advance(_):
                i[0] += 2
                f.write_bytes(self.frame(i[0]))
            with redirect_stdout(io.StringIO()):
                self.assertTrue(trace.check(f, 4, 1, sleeper=advance))

    def test_stall(self):
        with tempfile.TemporaryDirectory() as td:
            f = Path(td)/'trace'
            f.write_bytes(self.frame(2))
            with self.assertRaisesRegex(ValueError, 'stalled'):
                with redirect_stdout(io.StringIO()):
                    trace.check(f, 3, 1, sleeper=lambda _: None)

class BootTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        (self.root/'base.img').write_bytes(b'base')
        (self.root/'ipu.img').write_bytes(b'ipu')
        self.config = self.root/'user.cfg'

    def test_independent_images(self):
        self.config.write_text('LABEL m4base\n LINUX /base.img\nLABEL m4ipu\n LINUX /ipu.img\n')
        self.assertEqual(boot.check(self.config,self.root), ('/base.img','/ipu.img'))

    def test_shared_images_refused(self):
        self.config.write_text('LABEL m4base\n LINUX /ipu.img\nLABEL m4ipu\n LINUX /ipu.img\n')
        with self.assertRaisesRegex(ValueError, 'independent'):
            boot.check(self.config,self.root)

    def test_missing_image_refused(self):
        self.config.write_text('LABEL m4base\n LINUX /base.img\nLABEL m4ipu\n LINUX /missing.img\n')
        with self.assertRaises(ValueError):
            boot.check(self.config,self.root)

if __name__ == '__main__':
    unittest.main()
