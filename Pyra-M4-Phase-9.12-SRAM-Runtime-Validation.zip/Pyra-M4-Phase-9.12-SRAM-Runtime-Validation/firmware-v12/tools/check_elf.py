#!/usr/bin/env python3
"""Fail-closed v12 Cortex-M4 ELF validator; no extra loads or external accesses."""
from pathlib import Path
import struct
import sys

BASE = 0x20000000
EXPECTED = {
    '.vectors': (0x000, BASE+0x000, 0x40, 1),
    '.text': (0x040, BASE+0x040, None, 1),
    '.data': (0x680, BASE+0x600, None, 1),
    '.bss': (0x700, BASE+0x700, None, 8),
    '.tracebuf': (0x800, BASE+0x800, 0x200, 8),
    '.scratch': (0xA00, BASE+0xA00, 0x200, 8),
    '.stack': (0xC00, BASE+0xC00, 0x400, 8),
    '.resource_table': (BASE+0x1000, BASE+0x1000, 68, 1),
}


def need(condition, why):
    if not condition:
        raise ValueError(why)


def check(path):
    raw = Path(path).read_bytes()
    need(len(raw) >= 52 and raw[:7] == b'\x7fELF\x01\x01\x01', 'expected little-endian ELF32')
    e_type, e_machine = struct.unpack_from('<HH', raw, 16)
    e_entry, phoff, shoff = struct.unpack_from('<III', raw, 24)
    phentsize, phnum = struct.unpack_from('<HH', raw, 42)
    shentsize, shnum, shstridx = struct.unpack_from('<HHH', raw, 46)
    need((e_type, e_machine, e_entry) == (2, 40, 0x41), 'not ARM EXEC with reset PC 0x41')
    need(phentsize == 32 and shentsize == 40 and 0 < phnum <= 16 and 0 < shnum <= 80,
         'invalid ELF headers')
    need(shstridx < shnum and phoff+phentsize*phnum <= len(raw)
         and shoff+shentsize*shnum <= len(raw), 'truncated ELF')
    phdrs = [struct.unpack_from('<8I', raw, phoff+i*32) for i in range(phnum)]
    loads = [p for p in phdrs if p[0] == 1]
    need(len(loads) == len(EXPECTED), 'unexpected PT_LOAD count')
    need(all(p[0] in (1, 0x6474e551) for p in phdrs), 'non-LOAD dynamic/unknown segment')
    nameshdr = struct.unpack_from('<10I', raw, shoff+shstridx*40)
    need(nameshdr[4]+nameshdr[5] <= len(raw), 'bad name section')
    nametab = raw[nameshdr[4]: nameshdr[4]+nameshdr[5]]
    sections = {}
    for i in range(shnum):
        sh = struct.unpack_from('<10I', raw, shoff+i*40)
        n = sh[0]
        need(n < len(nametab), 'bad section name offset')
        end = nametab.find(b'\0', n)
        need(end >= 0, 'unterminated section name')
        name = nametab[n:end].decode('ascii')
        sections[name] = sh
    alloc = {n for n,s in sections.items() if s[2] & 2}
    need(alloc == set(EXPECTED), 'unexpected SHF_ALLOC sections: '+repr(alloc ^ set(EXPECTED)))
    ranges = []
    for name, (va, pa, sz, typ) in EXPECTED.items():
        sh = sections[name]
        need(sh[3] == va and sh[1] == typ and (sz is None or sh[5] == sz),
             name+' address/size/type mismatch')
        matches = [p for p in loads if p[2] == va and p[3] == pa]
        need(len(matches) == 1, name+' must have precisely one expected PT_LOAD')
        p = matches[0]
        _, off, _, p_pa, filesz, memsz, flags, align = p
        need(memsz == sh[5] and filesz == (0 if typ == 8 else sh[5]), name+' segment length/type')
        need(off + filesz <= len(raw) and filesz <= memsz, name+' malformed load')
        need(p_pa >= BASE and p_pa+memsz <= BASE+0x1100, name+' outside internal L2 DA')
        need(not (flags & 1) or name == '.text', name+' unexpected executable segment')
        need(align >= 4 and not (align & (align-1)), name+' alignment mismatch')
        ranges.append((p_pa, p_pa+memsz, name))
    for i, (a,b, n) in enumerate(ranges):
        for c,d,m in ranges[i+1:]:
            need(b <= c or d <= a, f'physical DA overlap: {n} and {m}')
    code = sections['.text'][5]
    datasz = sections['.data'][5]
    bsssz = sections['.bss'][5]
    need(0 < code <= 0x5c0, 'code intrudes on .data initializers')
    need(8 <= datasz <= 0x80 and datasz % 4 == 0, 'bad initialized data')
    need(8 <= bsssz <= 0x100 and bsssz % 4 == 0, 'bad BSS')
    vec = sections['.vectors']
    vectors = struct.unpack_from('<16I', raw, vec[4])
    need(vectors[0:2] == (0x1000, 0x41), 'MSP / Reset vector mismatch')
    need(all((v & 1) and 0x40 <= (v & ~1) < 0x600 for v in vectors[2:]),
         'unexpected fault vector')
    meta = sections['.resource_table']
    need(meta[4] + meta[5] <= len(raw), 'truncated resource table')
    v, count, r0, r1, offset = struct.unpack_from('<5I', raw, meta[4])
    need((v,count,r0,r1,offset) == (1,1,0,0,20), 'bad resource table header')
    rtype, rda, rlen, reserved = struct.unpack_from('<4I', raw, meta[4]+20)
    name = raw[meta[4]+36:meta[4]+68]
    need((rtype,rda,rlen,reserved)==(2,BASE+0x800,512,0), 'unexpected resource type/DA')
    need(name.startswith(b'pyra_m4_v12_sram\0'), 'trace resource name incorrect')
    # Strong evidence .data requires M4 copy: distinct paddr / vaddr and known constants at LMA.
    init = sections['.data']
    need(raw[init[4]:init[4]+datasz] in (
        bytes.fromhex('e0ac6824df9b5713'), bytes.fromhex('df9b5713e0ac6824')),
        'missing .data initializer cookies')
    print('PASS: ARM Cortex-M4 ELF entry=0x41, MSP=0x1000, 8 exact SRAM loads')
    print('PASS: .data load local 0x600 -> runtime local 0x680; .bss at 0x700')
    print('PASS: trace local 0x800 / Linux DA 0x20000800; scratch 0xa00; stack 0xc00-0x1000')
    print('PASS: exactly one RSC_TRACE; no DEVMEM, DDR, external MMIO, or VDEV resources')
    print('NOTE: static ELF checks cannot establish live Cortex-M4 execution')


if __name__ == '__main__':
    if len(sys.argv) != 2:
        sys.exit('Usage: check_elf.py PATH_TO_ELF')
    try:
        check(sys.argv[1])
    except (OSError, ValueError, UnicodeError, struct.error) as exc:
        sys.exit('FAIL: '+str(exc))
