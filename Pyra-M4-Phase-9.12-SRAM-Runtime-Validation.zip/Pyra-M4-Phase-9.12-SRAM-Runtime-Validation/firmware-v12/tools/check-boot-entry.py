#!/usr/bin/env python3
"""Verify that m4base and m4ipu use independent existing kernel images."""
from pathlib import Path
import sys


def check(filename='/boot/extlinux/user.cfg', boot='/boot'):
    text = Path(filename).read_text(encoding='utf-8')
    sections = {}
    current = None
    for line in text.splitlines():
        parts = line.strip().split(None, 1)
        if not parts or line.lstrip().startswith('#'):
            continue
        if parts[0].upper() == 'LABEL' and len(parts) == 2:
            current = parts[1].strip()
            if current in sections:
                raise ValueError('duplicate boot label: '+current)
            sections[current] = {}
        elif current and parts[0].upper() in ('LINUX','FDT','APPEND') and len(parts) == 2:
            sections[current][parts[0].upper()] = parts[1].strip()
    a, b = sections.get('m4base', {}), sections.get('m4ipu', {})
    ka, kb = a.get('LINUX'), b.get('LINUX')
    if not ka or not kb or ka == kb:
        raise ValueError('independent m4base and m4ipu LINUX paths are required')
    if not ka.startswith('/') or not kb.startswith('/') or '..' in Path(ka).parts or '..' in Path(kb).parts:
        raise ValueError('unsafe kernel image path')
    root = Path(boot)
    if not (root / ka.lstrip('/')).is_file() or not (root / kb.lstrip('/')).is_file():
        raise ValueError('one or both kernel images are missing in /boot')
    return ka, kb


if __name__ == '__main__':
    try:
        base, ipu = check()
        print('PASS: independent boot images: m4base='+base+' m4ipu='+ipu)
    except (OSError, ValueError) as exc:
        print('BLOCKED: '+str(exc), file=sys.stderr)
        sys.exit(1)
