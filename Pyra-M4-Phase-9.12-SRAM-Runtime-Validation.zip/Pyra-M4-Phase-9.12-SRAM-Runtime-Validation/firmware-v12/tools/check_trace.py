#!/usr/bin/env python3
"""Evaluate live M4 SRAM runtime traces. Requires HB progress across timed reads."""
import argparse
import re
import sys
import time
from pathlib import Path

HEADER = b'M12A\nM12I\nM12B\nM12C\nHB='
PATTERN = re.compile(rb'^M12A\nM12I\nM12B\nM12C\nHB=([0-9A-F]{8})\nOK=1\n')


def parse(buf):
    if b'M12F\n' in buf or b'ERR=' in buf:
        raise ValueError('M12F / ERR: firmware failure or fault indicator present')
    if not buf.startswith(HEADER):
        observed = buf[:48].decode('ascii', 'backslashreplace')
        raise ValueError(f'expected A/I/B/C markers and HB header, saw {observed!r}')
    match = PATTERN.match(buf)
    if not match:
        raise ValueError('marker present but counter or OK=1 malformed / incomplete')
    return int(match.group(1), 16)


def advanced(a, b):
    return 0 < ((b-a) & 0xFFFFFFFF) < 0x80000000


def check(path, samples, interval, sleeper=time.sleep):
    values = []
    for i in range(samples):
        try:
            raw = Path(path).read_bytes()
        except OSError as exc:
            raise ValueError(f'cannot read trace: {exc}') from exc
        try:
            hb = parse(raw)
        except ValueError as exc:
            raise ValueError(f'sample {i+1}: {exc}') from exc
        values.append(hb)
        print(f'sample {i+1}/{samples}: HB=0x{hb:08X} ({hb})')
        if i != samples-1:
            sleeper(interval)
    if samples < 2:
        print('MARKERS ONLY: heartbeat progression requires >= 2 samples')
        return False
    if any(not advanced(a,b) for a,b in zip(values,values[1:])):
        raise ValueError(f'heartbeat stalled or went backwards: {values}')
    print('PASS: Cortex-M4 C runtime, initialized SRAM, scratch tests and live heartbeat observed')
    return True


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('trace', help='debugfs /sys/kernel/debug/remoteproc/remoteprocN/trace0')
    ap.add_argument('--samples', type=int, default=4)
    ap.add_argument('--interval', type=float, default=1.0)
    args = ap.parse_args()
    if not 2 <= args.samples <= 30 or not 0.1 <= args.interval <= 20:
        ap.error('samples must be 2..30, interval 0.1..20 seconds')
    try:
        check(args.trace, args.samples, args.interval)
    except ValueError as exc:
        print('NOT VERIFIED: '+str(exc), file=sys.stderr)
        return 2
    return 0


if __name__ == '__main__':
    sys.exit(main())
