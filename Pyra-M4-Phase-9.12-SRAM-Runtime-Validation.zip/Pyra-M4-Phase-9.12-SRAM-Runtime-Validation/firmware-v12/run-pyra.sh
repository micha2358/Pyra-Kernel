#!/bin/sh
# Safe opt-in Phase 9.12 SRAM runtime test on the known-good 9.11.5 driver.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
FW=pyra-m4-sram-v12.elf
ELF="$ROOT/build/$FW"
DST="/lib/firmware/$FW"
EXPECTED_SHA256='1c8b2c16aa02a7231d810a3072d11954c7f319ab2706859afde050e955c17a89'
VER=5.6.19-pyradef-m4test
DT=/proc/device-tree/ocp/ipu@55020000
fail() { echo "ERROR: $*" >&2; exit 1; }
need_root() { [ "$(id -u)" -eq 0 ] || fail 'Use sudo.'; }
find_ipu() {
    for r in /sys/class/remoteproc/remoteproc*; do
        [ -r "$r/name" ] || continue
        [ "$(cat "$r/name")" = '55020000.ipu' ] || continue
        echo "$r"; return 0
    done
    return 1
}
debug_dir() {
    r=$(find_ipu) || return 1
    echo "/sys/kernel/debug/remoteproc/$(basename "$r")"
}
verify() {
    [ -s "$ELF" ] || fail 'v12 firmware not present; build using make USE_CLANG=1 or make'
    digest=$(sha256sum "$ELF" | cut -d ' ' -f1)
    [ "$digest" = "$EXPECTED_SHA256" ] || fail "v12 SHA256 differs from validated project ELF ($digest); do not proceed blindly"
    python3 "$ROOT/tools/check_elf.py" "$ELF"
}
check_env() {
    [ "$(uname -r)" = "$VER" ] || fail "unexpected kernel release (expected $VER)"
    [ -d "$DT" ] || fail 'IPU DT node missing; select m4ipu kernel'
    tr '\000' '\n' < "$DT/compatible" | grep -Fxq ti,omap5-ipu || fail 'wrong IPU compatible'
    [ -r "$DT/status" ] && [ "$(tr -d '\000' < "$DT/status")" = okay ] || fail 'IPU DT not enabled'
    find_ipu >/dev/null || fail 'IPU remoteproc absent'
    for flag in pyra15_boot_once pyra_cpu0_only pyra10_ammu_probe; do
        f="/sys/module/omap_remoteproc/parameters/$flag"
        [ -r "$f" ] || fail "active kernel lacks $flag"
        case $(cat "$f") in Y|1) ;; *) fail "inactive $flag";; esac
    done
    for flag in pyra11_ammu_repair pyra11_boot_after_repair pyra11_stage0_only pyra13_consistency_only; do
        f="/sys/module/omap_remoteproc/parameters/$flag"
        [ -r "$f" ] || fail "missing safety flag $flag"
        case $(cat "$f") in N|0) ;; *) fail "conflicting flag $flag";; esac
    done
    grep -Eq '^LABEL[[:space:]]+m4base[[:space:]]*$|^[[:space:]]*LABEL[[:space:]]+m4base[[:space:]]*$' /boot/extlinux/user.cfg || fail 'm4base recovery entry absent'
    python3 "$ROOT/tools/check-boot-entry.py" || fail 'm4base image must be independent of m4ipu'
    tr ' ' '\n' < /proc/cmdline | grep -Fxq 'omap_remoteproc.pyra15_boot_once=1' || fail 'pyra15 boot mode not set in active cmdline'
}
install_fw() {
    need_root
    verify
    if [ -e "$DST" ]; then
        cmp -s "$ELF" "$DST" || fail "$DST already differs; refusing overwrite"
        echo "Firmware already installed and identical: $DST"
    else
        install -m 0644 "$ELF" "$DST"
        cmp -s "$ELF" "$DST" || fail 'firmware installation mismatch'
        echo "Installed new firmware: $DST"
    fi
}
mount_debugfs() {
    grep -Eq '^[^ ]+ /sys/kernel/debug debugfs ' /proc/mounts ||
        mount -t debugfs debugfs /sys/kernel/debug || fail 'cannot mount debugfs'
}
probe() {
    check_env
    r=$(find_ipu)
    echo "Remoteproc: $(cat "$r/name") state=$(cat "$r/state") firmware=$(cat "$r/firmware")"
    echo 'NOTE: active kernel flags do not prove M4 executed the new firmware.'
}
status() {
    r=$(find_ipu) || fail 'remoteproc absent'
    [ "$(cat "$r/firmware")" = "$FW" ] || fail 'another firmware configured'
    [ "$(cat "$r/state")" = running ] || fail 'M4 not in running state'
    d=$(debug_dir)
    [ -r "$d/trace0" ] || fail 'missing trace0 (debugfs may need mounting)'
    python3 "$ROOT/tools/check_trace.py" "$d/trace0" --samples 4 --interval 1
}
start_once() {
    need_root
    [ "${2:-}" = BOOT-M4-SRAM-ONCE ] || fail 'requires --start BOOT-M4-SRAM-ONCE'
    check_env
    verify
    r=$(find_ipu)
    [ "$(cat "$r/state")" = offline ] || fail 'M4 not offline: reboot to reset one-shot latch; never rerun same boot'
    install_fw
    mount_debugfs
    d=$(debug_dir)
    [ -w "$d/recovery" ] || fail 'remoteproc recovery control unavailable'
    echo disabled > "$d/recovery"
    [ "$(cat "$d/recovery")" = disabled ] || fail 'could not disable recovery'
    echo 'One hardware attempt only; reset / AMMU still handled solely by Phase 9.11.5 kernel.'
    echo 'No auto-retry. Preserve logs and reboot via m4base on hang/fault.'
    echo "$FW" > "$r/firmware"
    echo start > "$r/state"
    sleep 1
    status
}
stop_test() {
    need_root
    r=$(find_ipu) || fail 'remoteproc absent'
    [ "$(cat "$r/firmware")" = "$FW" ] || fail 'refusing to stop different firmware'
    [ "$(cat "$r/state")" = running ] || fail 'remoteproc not running; do not retry crashed state'
    echo stop > "$r/state"
    echo "After stop: $(cat "$r/state"); reboot before another CPU0 attempt"
}
case "${1:---probe}" in
    --verify) verify ;;
    --probe) probe ;;
    --install) install_fw ;;
    --status) status ;;
    --start) start_once "$@" ;;
    --stop) stop_test ;;
    *) echo 'Usage: ./run-pyra.sh [--verify|--probe|--install|--status|--start BOOT-M4-SRAM-ONCE|--stop]' >&2; exit 2 ;;
esac
