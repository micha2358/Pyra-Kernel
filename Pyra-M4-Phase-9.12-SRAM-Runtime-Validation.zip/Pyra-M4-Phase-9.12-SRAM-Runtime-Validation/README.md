# DragonBox Pyra – Phase 9.12: M4 SRAM Runtime Validation

**Status:** Firmware built and checked offline using Clang 17 / LLD 17. **NOT YET TESTED ON PYRA HARDWARE.**

**Known-good prerequisite from the user's Phase 9.11.5 run:** Linux remoteproc reached `running` and the local M4 wrote `M5A1`, `M5B2`, `M5D3` to L2 SRAM. The existing `pyra15_boot_once=Y` code path must remain unchanged. This phase **does not patch the kernel**, reset controller, AMMU, Linux IOMMU, device tree, or bootloader.

## What Phase 9.12 proves (if all runtime markers and progressive samples appear)

1. **M12A**: Cortex-M4 reset entry executed, from the same Thumb `0x41` entry as v5.
2. **M12I**: startup assembly copied `.data` from local L2 `0x600` to `0x680` and cleared `.bss` at `0x700`.
3. **M12B**: control transferred to compiled C and used the actual Cortex-M4 stack in local `0xC00..0xFFF`.
4. **M12C** + `OK=1`: initialization values, BSS, stack probe and 128 volatile 32-bit scratch words at local `0xA00..0xBFF` were validated.
5. **HB=XXXXXXXX**: M4 code updated an ASCII hex counter in the existing `RSC_TRACE` buffer; the host proves counter advancement using **4 separate reads one second apart**. Static markers alone are insufficient to claim a continuing runtime.
6. **M12F** or **ERR=...**: test failure. Do not retry until a safe reboot. An exception before the first marker can leave no trace at all.

## Memory map – M4 LOCAL addresses, NOT Linux bus addresses

| Region | M4 local VMA | Linux firmware-load DA (`0x20000000 + local`) | Role |
|---|---|---|---|
| Vectors | `0x0000..0x003F` | `0x20000000` | MSP `0x1000`, Reset-PC `0x41` |
| Text & constants | `0x0040..0x05FF` maximum | `0x20000040` | freestanding Thumb code |
| `.data` initializer | `0x0600..0x067F` reserved | `0x20000600` | initialized bytes Linux loads here |
| Runtime `.data` | `0x0680..0x06FF` reserved | **not loaded here** | startup copies initializer bytes to here |
| `.bss` | `0x0700..0x07FF` reserved | `0x20000700` (NOBITS) | startup clears |
| Trace buffer | `0x0800..0x09FF` | `0x20000800` | one RSC_TRACE, 512 bytes |
| SRAM scratch test | `0x0A00..0x0BFF` | `0x20000A00` (NOBITS) | 128 volatile words |
| MSP stack | `0x0C00..0x0FFF` | `0x20000C00` (NOBITS) | 1 KiB |
| Linux resource table | not addressed by M4 | `0x20001000` | exactly one TRACE, no DEVMEM |

Physical L2 SRAM base remains **`0x55020000`**, reached from M4-local `0x0` by the proven Phase-9.11.5 P0_XLTE commit. The 9.11.5 kernel preflight still sees MSP=`0x1000`, PC=`0x41`, exactly one trace and valid DA pointers. This is why no kernel code is changed here.

## 1. Verify package locally (no root needed)

```sh
cd /path/to/Pyra-M4-Phase-9.12-SRAM-Runtime-Validation
python3 firmware-v12/tools/check_elf.py firmware-v12/build/pyra-m4-sram-v12.elf
python3 -m unittest discover -s firmware-v12/tests -v
sha256sum -c SHA256SUMS
sh -n firmware-v12/run-pyra.sh tools/collect-phase912.sh
bash -n start-phase912.sh
```

You can use the supplied **already compiled ELF**. To rebuild the same source using Clang with embedded ARM target and LLD, `make -C firmware-v12 USE_CLANG=1`. Alternatively try `make -C firmware-v12` with `arm-none-eabi-gcc`. Note: the explicit release SHA256 in `firmware-v12/run-pyra.sh` is pinned to the *supplied verified binary*. A GCC or locally rebuilt ELF may differ in bytes and is **intentionally refused by the start script**. Keep the original binary for the initial hardware test. A reproducible local rebuild is not guaranteed across tool versions.

## 2. Pre-flight BEFORE attempting to start

You must have **rebooted into `m4ipu`**, with the new Phase 9.11.5 kernel image actually active; running the original 9.11.5 v5 experiment already consumed the in-kernel one-shot latch. Verify the independent `m4base` recovery kernel image has not been replaced by 9.11.5.

```sh
cat /sys/module/omap_remoteproc/parameters/pyra15_boot_once   # expected Y
cat /sys/class/remoteproc/remoteproc0/state                    # expected offline
python3 firmware-v12/tools/check-boot-entry.py
./firmware-v12/run-pyra.sh --verify
sudo ./firmware-v12/run-pyra.sh --probe
```

Other required enabled kernel parameters: `pyra_cpu0_only=Y`, `pyra10_ammu_probe=Y`. Dangerous older repair modes must all be `N`. The launcher checks them. The selected `m4ipu` entry retains the known-good bootargs including `omap_remoteproc.pyra15_boot_once=1`. **Do not invoke the old v5 start script on this boot**.

## 3. Single experimental CPU0 run (explicit, opt-in)

```sh
sudo ./start-phase912.sh BOOT-M4-SRAM-ONCE
```

This installs **`/lib/firmware/pyra-m4-sram-v12.elf`** (new name, never overwrites the working v5 firmware), disables auto-recovery, sets remoteproc firmware, starts **one time only**, waits briefly, then checks 4 heartbeat samples. It logs kernel messages to `/root/pyra-phase912-start-YYYYMMDD-HHMMSS.log` when executed via `sudo` with a root HOME. It does not modify kernel code or any bootloader entry. It does not start until the strict active-driver and independent recovery-image gates pass.

If the trace checker says `NOT VERIFIED`, there is a failure, or the system hangs: **no repeat start in the same boot**. Preserve kernel logs and use the `m4base` recovery entry for the next boot. With a running firmware, only if the Pyra remains responsive, you may stop it using `sudo ./firmware-v12/run-pyra.sh --stop` (no restart in the same boot).

## 4. Capture hardware evidence

```sh
sudo ./tools/collect-phase912.sh /home/USER/pyra-phase912-evidence
sudo ./firmware-v12/run-pyra.sh --status
```

The collector performs only reads. It stores cmdline, all relevant `dmesg`, remoteproc state, firmware identity, kernel flags and four spaced trace samples. The runtime checker requires **increasing counter values**, not merely text markers and `running`.

Expected trace (numbers will vary):

```text
M12A
M12I
M12B
M12C
HB=000000A3
OK=1
```

You may see previous `bogus pgd` diagnostics during remoteproc preparations, as in Phase 9.11.5. Those are *not* proof that M4 C runtime accessed external DDR. Distinguish the timestamps and failure semantics. This firmware itself requests no external IOMMU mapping and makes no DDR accesses.

## Known limitations and next phase

- LLVM/GNU static validation only; M4 hardware execution is **not claimed** until user captures changing HB values.
- This is a **bare-metal, freestanding C runtime**: assembler explicitly initializes `.data`/`.bss`, calls C, uses its live stack. No libc, heap, interrupts, timer, DMA, clocks, cache control, SCACHE/MMU maintenance, remote services or peripheral MMIO are exercised.
- Busy-wait heartbeat is deliberately clockless; the numeric rate is **not a benchmark**. The host checks progression, not frequency.
- `.bss` may also be zeroed by Linux's ELF loader; the firmware still executes its own zero loop and checks the resulting zero state, but the check alone does **not uniquely prove** who first zeroed those bytes.
- Byte-wise ASCII `HB=` updates are not atomic. The host reads once per second, so a transient incoherent snapshot is possible; if a sample is malformed, treat it as inconclusive and save the trace rather than assuming a hardware failure.
- Full TI SCACHE and DDR/IOMMU capability still unverified. A subsequent phase would be required for local timer/IRQ or external memory.

The entire previous 9.11.5-r2 source/package is preserved unchanged in `phase9115-reference/` for audit. **Do not reapply its kernel patch if it is already active.**
