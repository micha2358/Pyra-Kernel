#!/usr/bin/env bash
# Deliberately separate from the successful Phase 9.11.5 start command.
set -euo pipefail
ROOT=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
[[ "${1:-}" == BOOT-M4-SRAM-ONCE ]] || {
  echo 'Usage: sudo ./start-phase912.sh BOOT-M4-SRAM-ONCE' >&2; exit 2;
}
[[ $(id -u) == 0 ]] || { echo 'ERROR: sudo required' >&2; exit 1; }
LOG="${HOME}/pyra-phase912-start-$(date +%Y%m%d-%H%M%S).log"
echo "Phase 9.12: single experimental Cortex-M4 SRAM runtime attempt. Log: $LOG"
echo 'Only use after reboot into m4ipu; an earlier 9.11.5 boot attempt consumes the kernel one-shot latch.'
(
  echo "BEGIN $(date -Is)"
  "$ROOT/firmware-v12/run-pyra.sh" --start BOOT-M4-SRAM-ONCE
  echo 'AFTER_START: relevant dmesg'
  dmesg | grep -E 'PYRA9115:|remoteproc|iommu.*(fault|bogus)|L3 (Custom|Standard) Error' | tail -85 || true
) 2>&1 | tee "$LOG"
