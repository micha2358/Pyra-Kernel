# 9.11.5-r2 – active driver verification

## Diagnosis

The guard message `ERROR: active module does not expose pyra15_boot_once`
comes from `tools/start-phase9115.sh` **before** triggering the M4 remoteproc.
It is not evidence that the M4 attempted to boot or that the AMMU mapping failed.

The r1 C source uses `module_param_named(pyra15_boot_once, ..., bool, 0444)`
and correct kernel module parameter scope `omap_remoteproc.pyra15_boot_once`.
The build script creates a staging directory, without installing anything in
`/boot` or the live `/lib/modules` directory. `uname -r` is intentionally the
same as in prior experiments and cannot identify the active code revision.

## Read-only checks on the Pyra

```sh
SRC=/mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef
BUILD=/mnt/pyra-kernel-m4/build-pyradef10-m4
python3 tools/check-active-phase9115.py --source "$SRC" --build "$BUILD"
grep '^CONFIG_OMAP_REMOTEPROC=' "$BUILD/.config"
grep -nE '^\s*(LABEL|KERNEL|LINUX|FDT|APPEND)\b' /boot/extlinux/user.cfg
ls /sys/module/omap_remoteproc/parameters
```

- `CONFIG_OMAP_REMOTEPROC=y`: driver is built into **zImage**. Confirm the boot
  entry `m4ipu` loads the newly staged image, and install it following the
  previously verified local method. Preserve `m4base` separately. Reboot.
- `CONFIG_OMAP_REMOTEPROC=m`: check the staged and installed
  `omap_remoteproc.ko` (including kernel release directory). Install the
  matching module tree with normal `modules_install` / `depmod` and reboot.
  Merely updating the .ko file does not replace a module already loaded.

If the active parameter is missing, **do not** run the CPU0 start script and do
not bypass the check. An active parameter after reboot is prerequisite, not
proof of a successful boot or safe cache state.

## Changes relative to r1

- Added `tools/check-active-phase9115.py` read-only diagnostic of live sysfs,
  kernel build config and optionally source/staged object.
- Start script explains stale-driver scenario and runs that diagnostic on a
  missing required parameter, then stops. It never auto-installs, reboots,
  loads/unloads modules or starts remoteproc after a missing parameter.
- Build/stage script now checks `CONFIG_OMAP_REMOTEPROC` and confirms that the
  **compiled object** (and `.ko` if modular) contains the new parameter string.
- No changes to `apply-phase9.11.5.py`, the kernel C helper, AMMU register
  writes, safety mode gates, or the preserved v5 firmware.

## Limitations

This package cannot tell which kernel image your physical Pyra booted without
its live sysfs and boot configuration. Nothing here installs the new kernel.
A full ARM kernel build and on-device execution are not performed offline.
