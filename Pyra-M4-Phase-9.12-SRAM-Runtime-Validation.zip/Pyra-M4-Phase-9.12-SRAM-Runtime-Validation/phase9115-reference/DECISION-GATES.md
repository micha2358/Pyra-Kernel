# Phase 9.11.5 decision gates

| Gate | Mechanism | Rejects |
|---|---|---|
| G-1 active driver deployment | `pyra15_boot_once` must exist in `/sys/module/omap_remoteproc/parameters` after boot | old built-in image or stale loaded module |
| G0 explicit user opt-in | `pyra15_boot_once=1`, manual start wrapper token | accidental firmware start |
| G1 platform/bootargs | `ti,omap5-ipu`, `pyra_cpu0_only`, `pyra10_ammu_probe`, no incompatible stage flags | wrong mode/processor |
| G2 one per boot | existing static atomic `pyra11_attempted` | second attempt after fault |
| G3 Reset state | `reset_control_status(CPU0)==1`, same for CPU1 | CPU already executing |
| G4 v5 load contract | ELF bootaddr `0x41`, one trace, Linux DA loader read MSP `0x1000` / PC `0x41` | different firmware |
| G5 documented PRM window | read `RSTCTRL=0x3`, log RSTST/context | cache/MMU held in reset |
| G6 exact known AMMU fingerprint | P0 `(0,0,0xB)`, P1 `(0x40000000,0x55080000,0x9)`, maintenance/config=0 | unknown firmware/bootstrap state |
| G7 controlled write | only XLTE0 `0x550809A0` → `0x55020000`, with readback and barrier | failed memory-map patch |
| G8 post-write preservation | neighboring registers unchanged, PRM unchanged, both CPUs still held | unexpected side effects |
| G9 one-way release | old CPU0-only remoteproc path after G8 returns 0 | experimental CPU1 release in helper |
| G10 actual execution | trace `M5A1 M5B2 M5D3`, rproc running, no post-start L3 fault | false positive from register status alone |

## No automatic `PASS` before hardware execution

Only source installer, artifact hash, GNU89 syntax smoke and mode-guard unit tests are assessed offline. **Hardware G5–G10 have not been run by this package authoring environment.** The absence of external L2-MMU mappings is not a reason to create synthetic `iommu_map()` entries; the local SRAM path and Linux firmware DA must remain distinct. A test may fail or hang even when all software preconditions are satisfied.
