# Pyra-M4 – Phase 9.11.5-r2: Active Kernel Verification

**r2 deployment diagnosis:** If `start-phase9115.sh` reports `active module does not expose pyra15_boot_once`, the functional M4 start did not happen. The updated source is not necessarily the active booted driver. Run `python3 tools/check-active-phase9115.py --source "$SRC" --build "$BUILD"` and read `DEPLOYMENT-FIX-r2.md` before any CPU0 start. **No kernel C changes or AMMU changes from r1.**

# Pyra-M4 – Phase 9.11.5: Reset-Sequenced AMMU Boot Validation

**Revision r1:** Installer korrigiert: der bereits durch 9.11.3-r1 ersetzte Marker `PYRA9112: STAGEB_DISABLED` wird nicht mehr fälschlich verlangt. Siehe `PATCH-FIX-r1.md`.

**Target:** DragonBox Pyra OMAP5432, Cortex-M4 **IPU CPU0**, Linux `5.6.19-pyradef-m4test` with existing kernel phases through **9.11.3-r1**. This is an **experimental, opt-in functional hardware test**, **not** a successful on-device boot claim. The original v5 Cortex-M4 boot probe is included unmodified.

> **Safe default:** no `pyra15_boot_once=1` → Phase-9.11.3 read-only mode (if `pyra13_consistency_only=1`) or start denied. All install and boot actions are separate and require explicit commands. **Never modify `m4base`**. If boot validation fails or hangs, recover using `m4base`; do not retry in the same boot.

## 1. Why phase 9.11.5 is now plausible

- TI TRM SWPU249AG §2.4/Table 2-9 (TRM p.320): at reset IPU AMMU Page 0 exposes internal L2 SRAM at M4 address **0x00000000**; bus SRAM at **0x55020000**. **0x20000000** is the Linux firmware *load DA*, not the M4 reset alias.
- TRM §3.5.6.10 (p.395–396), fig. 3-28: MMU/cache reset must be cleared and `CACHE_MMU_IPU` configured **before** CPU0 reset release; CPU1 may remain in reset.
- TRM Table 3-423 (p.596): `RM_IPU_RSTCTRL` **0x4AE06910**, bit 2 MMU/cache, bit 1 CPU1, bit 0 CPU0. Previously observed **0x00000003** means **MMU/cache not held**, **both CPUs held**.
- Phase 9.11.2 measured successful `P0_XLTE: 0 → 0x55020000 → 0` with readback and rollback, CPU0 held. Phase 9.11.3 measured `P0_ADDR=0`, `P0_XLTE=0`, `P0_POLICY=0xB`, `P1_ADDR=0x40000000`, `P1_XLTE=0x55080000`, `P1_POLICY=0x9`, control regs 0; the local SRAM vectors were read as **MSP=0x1000, PC=0x41**.

**Important limitation:** These observations do **not** prove the internal SCACHE cache-maintenance sequence required by TI, nor the real CPU0 instruction fetch. This phase deliberately does **not** fabricate an undocumented cache flush or force a new IPU warm reset. It checks observable safe conditions, performs a controlled **one-register** commit, then uses the already existing CPU0-only release path. Only actual M4-written trace markers can validate execution. See `references/RESET-EVIDENCE-AND-LIMITS.md`.

## 2. What changes

**Exactly one kernel source file:** `drivers/remoteproc/omap_remoteproc.c`:

- Adds **read-only** module parameter `omap_remoteproc.pyra15_boot_once` (default **0**).
- Retains **Phase-9.11.3** diagnostic mode and the existing older test gates, but rejects mode conflicts.
- Verifies `CPU0=1`, `CPU1=1`; `rproc->bootaddr=0x41`, one trace resource, Linux DA SRAM vector **MSP=0x1000/PC=0x41**.
- Reads PRM (`RM_IPU_RSTCTRL`, `RM_IPU_RSTST`, `RM_IPU_IPU_CONTEXT`) and demands **RSTCTRL=0x3**. **No PRM writes**.
- Reads the exact earlier-known AMMU fingerprint plus `MMUCONFIG/MAINT/MAINTST=0`; refuses unfamiliar values.
- Performs **one AMMU register change only:** `writel(0x55020000, 0x550809A0)`; verifies XLTE and all relevant neighboring controls, verifies CPU0 and CPU1 are still reset; rolls back `P0_XLTE` on any postwrite check failure.
- Only after all checks succeed returns 0 to the pre-existing remoteproc start code so that **CPU0 can be released**. It **does not release CPU1**, write external IOMMU mappings, touch `0x20000000` as an M4 fetch alias, or change the firmware.
- A kernel-static atomic latch refuses a second attempt until reboot, including a first attempt that fails a prerequisite.

**Caution:** Following a successful commit, if the existing reset-release function subsequently fails, XLTE0 might remain changed. Recovery then requires the normal safe reboot path. No automatic post-release rollback, restart or recovery is attempted. Pre-existing side effects in driver/resource preparation remain possible; only changes introduced by this phase are described here.

## 3. Offline checks BEFORE touching the kernel

```bash
cd /PFAD/ZU/Pyra-M4-Phase-9.11.5-Reset-Sequenced-AMMU-Boot-Validation
python3 -m unittest discover -s tests -v
python3 firmware-v5/tools/check_elf.py firmware-v5/build/pyra-m4-ammu-v5.elf
sha256sum firmware-v5/build/pyra-m4-ammu-v5.elf
bash -n 03-build-and-stage.sh tools/start-phase9115.sh
sh -n tools/collect-phase9115.sh
python3 -m py_compile apply-phase9.11.5.py tools/*.py
```

Expected firmware SHA256: `629cfe1c21f9a6c12f9ba75819d09a1b74f8ac2b70ae9f12511b03ec446ab04f`.

## 4. Patch and build – stages only; nothing automatically installed

On the Pyra using the **original, already patched 9.11.3-r1 kernel source**:

```bash
SRC=/mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef
python3 apply-phase9.11.5.py "$SRC" --check
python3 apply-phase9.11.5.py "$SRC" --show-diff > "$HOME/phase9115-source.diff"
python3 apply-phase9.11.5.py "$SRC" --apply
./03-build-and-stage.sh "$SRC" 2>&1 | tee "$HOME/phase9115-build-console.log"
```

If the exact 9.11.3-r1 function/guard differs, `--check` refuses patching. Do **not** bypass its checks. The builder uses the existing out-of-tree build directory and creates `stage-phase9115`; it does **not** overwrite `/boot`, `/lib/modules`, or any installed kernel. **There is no bundled new kernel image** because full cross-/native compilation against the user's configured kernel tree was not possible here. Install the staged artifacts using the **previously verified local kernel-install method**, preserving the `m4base` kernel image, DTB, modules and boot entry independently. `uname -r` remains identical to prior experiments, so verify the new `/sys/module/omap_remoteproc/parameters/pyra15_boot_once` parameter after reboot.

**Source-only rollback:**

```bash
python3 apply-phase9.11.5.py "$SRC" --revert
```

This restores **9.11.3-r1 source** exactly, not an already installed boot image. Restore installed boot files independently if needed.

## 5. First boot in read-only mode (recommended)

Before installing/using the modified kernel, keep a verified `m4base` entry. For the first boot, set **read-only diagnosis** on **only** `LABEL m4ipu`:

```bash
sudo python3 tools/set-phase9115-bootargs.py diagnose
sudo python3 tools/set-phase9115-bootargs.py check
# Inspect /boot/extlinux/user.cfg and independently verify m4base remains usable.
# Reboot MANUALLY choosing m4ipu after the correct staged kernel is installed.
```

Necessary bootargs: `omap_remoteproc.pyra_cpu0_only=1 omap_remoteproc.pyra10_ammu_probe=1 omap_remoteproc.pyra13_consistency_only=1`. No repair/commit flags. The 9.11.3 diagnostic will still stop with `-125`, without a CPU0 start, when explicitly requested by the existing firmware start command. **The new parameter's presence in sysfs** validates that the rebuilt driver is active; this alone does not validate functional M4 startup.

## 6. Arm the experimental mode (reboot required)

**Only after** verifying the patched kernel, correct DT, CPU0-only mode, unmodified v5 firmware and the independent `m4base` recovery choice:

```bash
sudo python3 tools/set-phase9115-bootargs.py arm \
    --accept-experimental-cpu0-boot --confirm-m4base-recovery
sudo python3 tools/set-phase9115-bootargs.py check
# Visually inspect m4ipu and m4base, sync, reboot manually into m4ipu.
```

Resulting mutually exclusive flags:

```text
omap_remoteproc.pyra_cpu0_only=1
omap_remoteproc.pyra10_ammu_probe=1
omap_remoteproc.pyra15_boot_once=1
```

`pyra13_consistency_only`, `pyra11_ammu_repair`, `pyra11_boot_after_repair`, and `pyra11_stage0_only` must be **unset/false**. The `omap_prm.pyra_ipu_prm_assert_quirk=1` experiment is **forbidden**.

## 7. One functional CPU0 experiment

With the new kernel running in the experimental `m4ipu` boot entry:

```bash
./firmware-v5/run-pyra.sh --verify
./firmware-v5/run-pyra.sh --probe
sudo ./tools/start-phase9115.sh BOOT-CPU0-ONCE
```

The start wrapper checks active kernel module parameters, both-mode exclusion, firmware SHA256, current `m4base` entry, and the already validated v5 ELF contract. It invokes the preserved `firmware-v5/run-pyra.sh --start OK`, which disables remoteproc auto-recovery. **No automatic restart on failure.** A hang or an L3/IOMMU fault remains possible. Do not issue the start command twice on the same boot.

When the Pyra remains responsive, collect results **before** any other experiment:

```bash
sudo ./tools/collect-phase9115.sh /home/USER/pyra-phase9115-evidence
python3 tools/analyze-phase9115.py /home/USER/pyra-phase9115-evidence
```

The collector records `dmesg`, cmdline, parameters, remoteproc status and debugfs trace (when available). The analyzer requires **all 3 M4-written markers** `M5A1`, `M5B2`, `M5D3` **and** remoteproc `running`, with no postattempt L3/IOMMU error, to report functional confirmation. A `PYRA9115: RELEASE_ALLOWED` line alone **does not prove CPU0 executed**.

**After the experiment:** disable the experimental flag and manually boot the known-good recovery entry before trying further changes:

```bash
sudo python3 tools/set-phase9115-bootargs.py disable
sudo python3 tools/set-phase9115-bootargs.py check
```

`disable` removes the Phase 9.11.5 test-specific flags from `m4ipu`; with no `pyra13_consistency_only` it fails closed. It does not update any boot files outside the chosen `APPEND` line.

## 8. What is NOT included or claimed

- No real Pyra CPU0 run or full ARM kernel build has occurred within this delivered package. Local syntax/unit tests are not substitutes for a kernel build or device test.
- No proof of the internal SCACHE cache-initialization sequence or instruction-cache visibility. `MMUCONFIG=0`, `MAINT=0`, `MAINTST=0` only indicate known register state, **not** all TI initialization requirements.
- No derivation of an external L2-MMU PTE from the Linux remoteproc DA; no `RSC_DEVMEM`, no `iommu_map`, no fabricated identity mapping.
- No forced PRM warm reset, no CPU1 release, no debug-write to SRAM, and no automatic crash recovery.
- The `m4base` installed kernel/DTB/modules must be preserved in the system; script-level preservation of its extlinux stanza alone is insufficient.

The project is self-contained for offline audit and brings forward the exact, user-supplied v5 ELF; on-device setup must use the existing, specifically patched Linux tree and established installation method.
