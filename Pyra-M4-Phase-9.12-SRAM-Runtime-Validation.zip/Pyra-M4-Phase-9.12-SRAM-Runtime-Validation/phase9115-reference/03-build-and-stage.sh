#!/usr/bin/env bash
# Build from the existing configured out-of-tree 9.11.5 Pyra build.
# NO modification to /boot or live /lib/modules.
set -euo pipefail
if (( $# < 1 || $# > 2 )); then
  echo "Usage: $0 KERNEL_SOURCE [BUILD_DIR]" >&2
  exit 2
fi
SRC=$(realpath "$1")
BUILD=$(realpath "${2:-/mnt/pyra-kernel-m4/build-pyradef10-m4}")
VER=5.6.19-pyradef-m4test
[ -f "$SRC/Makefile" ] && [ -f "$SRC/drivers/remoteproc/omap_remoteproc.c" ] || {
  echo 'FAIL: missing kernel sources'; exit 1;
}
[ -f "$BUILD/.config" ] || {
  echo "FAIL: existing kernel build configuration absent at $BUILD/.config"; exit 1;
}
# Source modifications must reach the actually compiled driver object.
MODE=$(sed -n 's/^CONFIG_OMAP_REMOTEPROC=\([ym]\)$/\1/p' "$BUILD/.config" | head -n 1)
[ "$MODE" = y ] || [ "$MODE" = m ] || {
  echo 'FAIL: CONFIG_OMAP_REMOTEPROC is not y or m; remoteproc driver is not built'; exit 1;
}
echo "CONFIG_OMAP_REMOTEPROC=$MODE"
grep -q 'PYRA_PHASE_9_11_5_RESET_SEQUENCED_AMMU_BOOT_VALIDATION' "$SRC/drivers/remoteproc/omap_remoteproc.c" || {
  echo 'FAIL: 9.11.5 kernel patch not installed in source'; exit 1;
}
export ARCH=arm LOCALVERSION=
actual=$(make -s -C "$SRC" O="$BUILD" kernelrelease)
[ "$actual" = "$VER" ] || {
  echo "FAIL: expected kernelrelease $VER, got $actual"; exit 1;
}
make -C "$SRC" O="$BUILD" -j2 zImage modules dtbs 2>&1 | tee "$BUILD/phase9115-build.log"
# Verify the generated object, not just patched sources. This is not
# a substitute for confirming which image/module the Pyra boots.
OBJ="$BUILD/drivers/remoteproc/omap_remoteproc.o"
[ -s "$OBJ" ] && LC_ALL=C grep -aFq 'pyra15_boot_once' "$OBJ" || {
  echo 'FAIL: compiled omap_remoteproc.o lacks pyra15_boot_once; STOP deployment' >&2; exit 1;
}
echo 'PASS: compiled omap_remoteproc.o contains pyra15_boot_once'
if [ "$MODE" = m ]; then
  MOD="$BUILD/drivers/remoteproc/omap_remoteproc.ko"
  [ -s "$MOD" ] && LC_ALL=C grep -aFq 'pyra15_boot_once' "$MOD" || {
    echo 'FAIL: built omap_remoteproc.ko lacks pyra15_boot_once' >&2; exit 1;
  }
  echo 'PASS: built omap_remoteproc.ko contains pyra15_boot_once'
fi
BASE='omap5-letux-cortex15-v5.3+pyra-v5.3.dtb'
M4='omap5-letux-cortex15-v5.3+pyra-v5.3-m4test.dtb'
for f in "$BUILD/arch/arm/boot/zImage" "$BUILD/arch/arm/boot/dts/$BASE" "$BUILD/arch/arm/boot/dts/$M4"; do
  [ -s "$f" ] || { echo "FAIL: missing $f"; exit 1; }
done
STAGE="$BUILD/stage-phase9115"
mkdir -p "$STAGE/boot"
make -C "$SRC" O="$BUILD" INSTALL_MOD_PATH="$STAGE" modules_install 2>&1 | tee "$BUILD/phase9115-modules-install.log"
cp "$BUILD/arch/arm/boot/zImage" "$STAGE/boot/zImage-$VER"
cp "$BUILD/arch/arm/boot/dts/$BASE" "$STAGE/boot/$BASE"
cp "$BUILD/arch/arm/boot/dts/$M4" "$STAGE/boot/$M4"
cp "$BUILD/System.map" "$STAGE/boot/System.map-$VER"
cp "$BUILD/.config" "$STAGE/boot/config-$VER"
echo "STAGED (not installed): $STAGE"
echo 'Keep m4base recovery entry unchanged. Install according to proven local kernel procedure.'

echo 'CRITICAL: STAGING DOES NOT INSTALL OR ACTIVATE anything.'
if [ "$MODE" = y ]; then
  echo 'BUILT-IN DRIVER: m4ipu must boot the staged zImage after manual verified installation.'
else
  echo 'MODULE DRIVER: install matching staged .ko/module tree and activate via a controlled reboot.'
fi
echo "Before CPU0 test: python3 $(dirname "$0")/tools/check-active-phase9115.py --build $BUILD"
