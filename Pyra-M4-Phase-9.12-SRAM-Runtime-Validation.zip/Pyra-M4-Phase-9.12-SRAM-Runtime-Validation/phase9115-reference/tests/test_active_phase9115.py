#!/usr/bin/env python3
"""Mock sysfs tests: no hardware, no module load or CPU0 release."""
import importlib.util
from pathlib import Path
import tempfile
import unittest
import lzma

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('active_phase9115', ROOT / 'tools/check-active-phase9115.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

class ActiveDeployment(unittest.TestCase):
    def fixture(self, root, builtin=True):
        (root / 'proc').mkdir()
        (root / 'proc/cmdline').write_text('root=/dev/none omap_remoteproc.pyra15_boot_once=1\n')
        (root / 'boot').mkdir()
        (root / 'boot/config-5.6.19-pyradef-m4test').write_text(
            'CONFIG_OMAP_REMOTEPROC=' + ('y' if builtin else 'm') + '\n')
        (root / 'sys/module/omap_remoteproc/parameters').mkdir(parents=True)
        return root / 'sys/module/omap_remoteproc/parameters'
    def test_old_builtin_missing_phase15_must_fail(self):
        with tempfile.TemporaryDirectory() as d:
            p = self.fixture(Path(d))
            (p/'pyra_cpu0_only').write_text('Y\n')
            (p/'pyra10_ammu_probe').write_text('Y\n')
            code, lines = mod.evaluate(Path(d), '5.6.19-pyradef-m4test')
            self.assertEqual(code, 3)
            self.assertIn('BUILT', '\n'.join(lines).upper())
            self.assertIn('pyra15_boot_once', '\n'.join(lines))
    def test_new_builtin_present_succeeds(self):
        with tempfile.TemporaryDirectory() as d:
            p = self.fixture(Path(d))
            for n in mod.REQUIRED:
                (p/n).write_text('Y\n')
            for n in mod.CONFLICT:
                (p/n).write_text('N\n')
            code, lines = mod.evaluate(Path(d), '5.6.19-pyradef-m4test')
            self.assertEqual(code, 0, '\n'.join(lines))
    def test_present_but_disabled_blocks(self):
        with tempfile.TemporaryDirectory() as d:
            p = self.fixture(Path(d))
            for n in mod.REQUIRED:
                (p/n).write_text('N\n' if n=='pyra15_boot_once' else 'Y\n')
            code, _ = mod.evaluate(Path(d), '5.6.19-pyradef-m4test')
            self.assertEqual(code, 4)
    def test_installed_stale_module_warning(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            self.fixture(root, builtin=False)
            module_dir=root/'lib/modules/5.6.19-pyradef-m4test/kernel/drivers/remoteproc'
            module_dir.mkdir(parents=True)
            (module_dir/'omap_remoteproc.ko.xz').write_bytes(lzma.compress(b'old kernel driver'))
            code, lines=mod.evaluate(root,'5.6.19-pyradef-m4test')
            self.assertEqual(code,3)
            self.assertIn('marker=no','\n'.join(lines))
    def test_build_marker_detects_stale_object(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(mod.embedded_marker(Path(d)/'no.o'), 'unreadable')
            p=Path(d)/'module.o'
            p.write_bytes(b'__param_pyra15_boot_once')
            self.assertEqual(mod.embedded_marker(p),'yes')
            p.write_bytes(b'old')
            self.assertEqual(mod.embedded_marker(p),'no')

if __name__ == '__main__': unittest.main()
