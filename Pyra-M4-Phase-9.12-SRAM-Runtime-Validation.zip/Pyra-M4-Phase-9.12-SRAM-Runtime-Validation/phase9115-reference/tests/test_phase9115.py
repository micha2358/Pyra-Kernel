#!/usr/bin/env python3
"""Offline guard, installer, ELF, and GNU89 syntax tests."""
import hashlib
import importlib.util
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]

def load(name, filename):
    spec=importlib.util.spec_from_file_location(name, ROOT/filename)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

installer=load('installer9115','apply-phase9.11.5.py')
bootargs=load('bootargs9115','tools/set-phase9115-bootargs.py')
analysis=load('analysis9115','tools/analyze-phase9115.py')

def make_old(root):
    s=root/'drivers/remoteproc/omap_remoteproc.c'
    s.parent.mkdir(parents=True)
    (root/'Makefile').write_text('VERSION = 5\n')
    # Source skeleton has exact old function, prior mode gate and markers.
    # This is NOT an emulator of actual omap_rproc_start() behavior.
    s.write_text('''/* PYRA_PHASE_9_7_CPU0_ONLY */
/* PYRA_PHASE_9_8_START_OBSERVATION */
/* PYRA_PHASE_9_11_1_TI_GATED_AMMU */
static atomic_t pyra11_attempted = ATOMIC_INIT(0);
static bool pyra13_consistency_only;
module_param_named(pyra13_consistency_only, pyra13_consistency_only, bool, 0444);
''' + installer.OLD + '''static int omap_rproc_start(struct rproc *rproc)
{
''' + installer.CALL_GUARD_OLD + '''}
''')
    return s

class Installer(unittest.TestCase):
    def test_actual_9113_replacement_removed_stageb_marker(self):
        # 9.11.2's STAGEB_DISABLED lived in the replaced AMMU function.
        # The authentic 9.11.3-r1 function contains WRITE_AND_BOOT_MODES_DISABLED.
        self.assertNotIn('PYRA9112: STAGEB_DISABLED', installer.OLD)
        self.assertIn('PYRA9113: WRITE_AND_BOOT_MODES_DISABLED', installer.OLD)
        with tempfile.TemporaryDirectory() as td:
            source = make_old(Path(td))
            self.assertNotIn('PYRA9112: STAGEB_DISABLED', source.read_text())
            result = installer.transform(source.read_bytes())
            self.assertIn(b'PYRA9115: RELEASE_ALLOWED', result)

    def test_exact_patch_and_revert(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); source=make_old(root)
            before=source.read_bytes()
            after=installer.transform(before)
            self.assertIn(b'PYRA9115: RELEASE_ALLOWED', after)
            self.assertIn(b'PYRA9113: COMPLETE', after)
            self.assertNotIn(b'reset_control_deassert(',
                             installer.HELPER.encode())
            self.assertEqual(installer.HELPER.count('writel('),2)
            for arg in ('--check','--apply'):
                subprocess.run(['python3',str(ROOT/'apply-phase9.11.5.py'),str(root),arg],check=True,
                               stdout=subprocess.DEVNULL)
            self.assertEqual(source.read_bytes(),after)
            subprocess.run(['python3',str(ROOT/'apply-phase9.11.5.py'),str(root),'--revert'],
                           check=True,stdout=subprocess.DEVNULL)
            self.assertEqual(source.read_bytes(),before)
            self.assertFalse(source.with_name(source.name+'.phase9.11.5.sha256').exists())
    def test_reject_modified_original(self):
        with tempfile.TemporaryDirectory() as td:
            s=make_old(Path(td));s.write_text(s.read_text().replace('MAINTST=%08x','MAINTST=%08X'))
            with self.assertRaisesRegex(ValueError,'byte-for-byte'):
                installer.transform(s.read_bytes())
    def test_reject_missing_existing_gate(self):
        with tempfile.TemporaryDirectory() as td:
            s=make_old(Path(td));s.write_text(s.read_text().replace('PYRA9113: MODE_CONFLICT','PYRA9113: MUTATED'))
            with self.assertRaisesRegex(ValueError,'9.11.3 start gate'):
                installer.transform(s.read_bytes())
    def test_sha_firmware_exact(self):
        p=ROOT/'firmware-v5/build/pyra-m4-ammu-v5.elf'
        self.assertEqual(hashlib.sha256(p.read_bytes()).hexdigest(),
                         '629cfe1c21f9a6c12f9ba75819d09a1b74f8ac2b70ae9f12511b03ec446ab04f')
        x=subprocess.run(['python3',str(ROOT/'firmware-v5/tools/check_elf.py'),str(p)],capture_output=True,text=True)
        self.assertEqual(x.returncode,0,x.stderr)

class Bootargs(unittest.TestCase):
    CFG='''DEFAULT m4base
LABEL m4base
  MENU LABEL Recovery
  APPEND root=/dev/mmcblk0p2 quiet
LABEL m4ipu
  MENU LABEL Experimental
  APPEND root=/dev/mmcblk0p2 omap_remoteproc.pyra_cpu0_only=1 omap_remoteproc.pyra10_ammu_probe=1 omap_remoteproc.pyra13_consistency_only=1
'''
    def test_arm_is_stanza_local(self):
        edited=bootargs.edit(self.CFG,'arm')
        self.assertEqual(self.CFG.split('LABEL m4ipu')[0], edited.split('LABEL m4ipu')[0])
        self.assertIn('omap_remoteproc.pyra15_boot_once=1',edited)
        self.assertNotIn('omap_remoteproc.pyra13_consistency_only=1',edited)
        self.assertEqual(edited,bootargs.edit(edited,'arm'))
        self.assertIn('pyra13_consistency_only=1',bootargs.edit(edited,'diagnose'))
        self.assertNotIn('pyra15_boot_once=1',bootargs.edit(edited,'disable'))
    def test_reject_without_cpu0_only(self):
        with self.assertRaises(ValueError):
            bootargs.edit(self.CFG.replace('omap_remoteproc.pyra_cpu0_only=1',''),'arm')
    def test_reject_if_m4base_missing(self):
        with self.assertRaises(ValueError):
            bootargs.edit(self.CFG.replace('LABEL m4base','LABEL oops'),'arm')

class Analysis(unittest.TestCase):
    def test_no_trace_cannot_pass(self):
        logs='\n'.join(analysis.STAGES)
        code,msg=analysis.classify(logs)
        self.assertEqual(code,1)
    def test_success(self):
        logs='\n'.join(analysis.STAGES)
        c,v=analysis.classify(logs,'M5A1\nM5B2\nM5D3\n','name=55020000.ipu\nstate=running\nfirmware=pyra-m4-ammu-v5.elf\n')
        self.assertEqual(c,0)
    def test_post_test_l3_fault_prevents_pass(self):
        logs='[ 2] L3 Custom Error\n'+'\n'.join(analysis.STAGES)+'\n[ 3] L3 Custom Error\n'
        c,v=analysis.classify(logs,'M5A1 M5B2 M5D3','state=running\nfirmware=pyra-m4-ammu-v5.elf')
        self.assertEqual(c,2)

class CSmoke(unittest.TestCase):
    def test_gnu89(self):
        if not shutil.which('gcc'):
            self.skipTest('No host gcc')
        hdr=r'''#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <errno.h>
#define __iomem
#define container_of(ptr,type,member) ((type*)((char*)(ptr)-offsetof(type,member)))
struct list_head {struct list_head *next, *prev;};
#define list_for_each_entry(pos, head, member) \
 for (pos = container_of((head)->next, __typeof__(*pos), member); \
      &pos->member != (head); \
      pos = container_of(pos->member.next, __typeof__(*pos), member))
typedef uint32_t u32; typedef uint64_t u64; typedef uint8_t u8;
typedef uint32_t dma_addr_t;
struct device { void *of_node; };
struct reset_control;
struct rproc_mem_entry { void *va; dma_addr_t dma; int len; u32 da; char name[32]; struct list_head node; };
struct rproc {bool has_iommu;void *domain;u32 bootaddr;int num_traces;struct list_head mappings,carveouts;};
struct omap_rproc {struct reset_control *reset,*cpu1_reset;struct rproc *rproc;bool cpu0_only;};
typedef struct {int x;} atomic_t;
static bool pyra11_stage0_only,pyra11_ammu_repair,pyra11_boot_after_repair,pyra13_consistency_only,pyra15_boot_once,pyra10_ammu_probe;
static atomic_t pyra11_attempted;
int atomic_cmpxchg(atomic_t*,int,int);
int reset_control_status(struct reset_control*);
void *ioremap(uintptr_t,size_t);void iounmap(void*);
u32 readl(const volatile void*);void writel(u32,volatile void*);
void wmb(void); void mb(void);
int of_device_is_compatible(void*, const char*);
void dev_err(struct device*,const char*,...);
void dev_warn(struct device*,const char*,...);
void *rproc_da_to_va(struct rproc*,u64,int);
'''
        old=installer.OLD
        snippet=old.replace('static int pyra11_snapshot_or_repair_ammu',
                            installer.HELPER+'static int pyra11_snapshot_or_repair_ammu',1)
        snippet=snippet.replace(installer.FUNC_ANCHOR,installer.FUNC_REPLACE,1)
        with tempfile.TemporaryDirectory() as td:
            source=Path(td)/'source.c';source.write_text(hdr+snippet)
            run=subprocess.run(['gcc','-std=gnu89','-fsyntax-only','-Wall','-Wextra',
                                '-Werror','-Wno-unused-function','-Wno-unused-variable',str(source)],
                                capture_output=True,text=True)
            self.assertEqual(run.returncode,0,run.stderr)

if __name__=='__main__': unittest.main(verbosity=2)
