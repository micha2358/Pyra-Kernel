#!/usr/bin/env python3
"""9.11.5 incremental kernel-source installer, ONLY from exact 9.11.3-r1.

Modifies just drivers/remoteproc/omap_remoteproc.c. The initial 9.11.3
read-only mode survives. Never installs or boots a kernel.
"""
import argparse
import difflib
import hashlib
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
REL = Path('drivers/remoteproc/omap_remoteproc.c')
START = '/* PYRA_PHASE_9_11_3_READ_ONLY_L2_AMMU\n'
END = 'static int omap_rproc_start(struct rproc *rproc)'
OLD = (ROOT / 'legacy/phase9113-kernel-function.cfrag').read_text()
HELPER = (ROOT / 'kernel/pyra15-boot-helper.cfrag').read_text()
PARAM_ANCHOR = '''static bool pyra13_consistency_only;
module_param_named(pyra13_consistency_only, pyra13_consistency_only, bool, 0444);'''
PARAM_ADD = '''

/* PYRA_PHASE_9_11_5_RESET_SEQUENCED_AMMU_BOOT_VALIDATION: explicit opt-in. */
static bool pyra15_boot_once;
module_param_named(pyra15_boot_once, pyra15_boot_once, bool, 0444);
MODULE_PARM_DESC(pyra15_boot_once,
                 "EXPERIMENTAL: one CPU0 boot after verified AMMU page0 repair");'''
CALL_GUARD_OLD = '''\t/* PYRA_PHASE_9_11_3_READ_ONLY_L2_AMMU: deny all mode conflicts
\t * before the existing Phase 9.11.1 AMMU call and CPU0 reset release.
\t */
\tif (of_device_is_compatible(dev->of_node, "ti,omap5-ipu") &&
\t    !pyra13_consistency_only) {
\t\tdev_err(dev, "PYRA9113: DIAGNOSTIC_FLAG_REQUIRED CPU0_NOT_RELEASED\\n");
\t\tret = -EPERM;
\t\tgoto disable_timers;
\t}
\tif (pyra13_consistency_only &&
\t    (!pyra10_ammu_probe || !oproc->cpu0_only ||
\t     !of_device_is_compatible(dev->of_node, "ti,omap5-ipu") ||
\t     pyra11_stage0_only || pyra11_ammu_repair ||
\t     pyra11_boot_after_repair)) {
\t\tdev_err(dev, "PYRA9113: MODE_CONFLICT CPU0_NOT_RELEASED\\n");
\t\tret = -EPERM;
\t\tgoto disable_timers;
\t}
'''
CALL_GUARD_NEW = '''\t/* PYRA_PHASE_9_11_5_RESET_SEQUENCED_AMMU_BOOT_VALIDATION
\t * The legacy read-only 9.11.3 and experimental 9.11.5 are mutually
\t * exclusive. The normal IPU path never starts accidentally.
\t */
\tif (of_device_is_compatible(dev->of_node, "ti,omap5-ipu") &&
\t    !pyra13_consistency_only && !pyra15_boot_once) {
\t\tdev_err(dev, "PYRA9115: EXPLICIT_MODE_REQUIRED CPU0_NOT_RELEASED\\n");
\t\tret = -EPERM;
\t\tgoto disable_timers;
\t}
\tif ((pyra13_consistency_only || pyra15_boot_once) &&
\t    (!pyra10_ammu_probe || !oproc->cpu0_only ||
\t     !of_device_is_compatible(dev->of_node, "ti,omap5-ipu") ||
\t     pyra11_stage0_only || pyra11_ammu_repair ||
\t     pyra11_boot_after_repair ||
\t     (pyra13_consistency_only && pyra15_boot_once))) {
\t\tdev_err(dev, "PYRA9115: MODE_CONFLICT CPU0_NOT_RELEASED\\n");
\t\tret = -EPERM;
\t\tgoto disable_timers;
\t}
'''
FUNC_ANCHOR = '''    int s0, s1, ret;

    /* Hard fail closed: remove Phase A/B write paths in this build. */'''
FUNC_REPLACE = '''    int s0, s1, ret;

    /* Explicit opt-in; legacy read-only branch remains byte-for-byte intact. */
    if (pyra15_boot_once)
        return pyra15_validate_and_commit(dev, oproc);

    /* Hard fail closed: remove Phase A/B write paths in this build. */'''


def sha(b):
    return hashlib.sha256(b).hexdigest()


def once(s, a, b, desc):
    if s.count(a) != 1:
        raise ValueError(f'{desc}: expected one exact anchor, got {s.count(a)}')
    return s.replace(a, b, 1)


def transform(data: bytes) -> bytes:
    s = data.decode('utf-8')
    if 'PYRA_PHASE_9_11_5_RESET_SEQUENCED_AMMU_BOOT_VALIDATION' in s:
        raise ValueError('9.11.5 already present; never apply twice')
    # Phase 9.11.3-r1 REPLACED the entire former 9.11.2 AMMU function.
    # Consequently the previous function-local STAGEB_DISABLED log message
    # cannot be present in the expected source. Require the 9.11.3 explicit
    # mode-denial message instead, and verify the entire 9.11.3 function
    # byte-for-byte immediately below (no weakening of source integrity).
    for mark in ('PYRA_PHASE_9_11_3_READ_ONLY_L2_AMMU',
                 'PYRA_PHASE_9_7_CPU0_ONLY', 'PYRA_PHASE_9_8_START_OBSERVATION',
                 'PYRA_PHASE_9_11_1_TI_GATED_AMMU',
                 'PYRA9113: WRITE_AND_BOOT_MODES_DISABLED'):
        if mark not in s:
            raise ValueError('Required 9.11.3-r1 marker absent: ' + mark)
    if s.count(START) != 1 or s.count(END) != 1:
        raise ValueError('9.11.3 function bounds missing/ambiguous')
    a = s.index(START)
    b = s.index(END, a)
    if s[a:b] != OLD:
        raise ValueError('9.11.3-r1 function does not match original byte-for-byte; no edit')
    # The tested 9.11.3 helper performs no MMIO writes. Keep it unchanged.
    newfn = once(OLD, FUNC_ANCHOR, FUNC_REPLACE, 'function dispatch')
    newfn = once(newfn, 'static int pyra11_snapshot_or_repair_ammu',
                 HELPER + 'static int pyra11_snapshot_or_repair_ammu', 'helper insertion')
    s = s[:a] + newfn + s[b:]
    s = once(s, PARAM_ANCHOR, PARAM_ANCHOR + PARAM_ADD, 'module parameter')
    s = once(s, CALL_GUARD_OLD, CALL_GUARD_NEW, '9.11.3 start gate')
    if 'reset_control_deassert(oproc->cpu1_reset)' not in s:
        # Kernel v5 implementation can use other reset-control mechanisms;
        # this by itself is not proof, so do NOT treat absent symbol as safe.
        # The exact old Phase 9.7 marker is verified above; check platform
        # source manually as instructed in the README before HW start.
        pass
    return s.encode('utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('kernel_source', type=Path)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--check', action='store_true')
    mode.add_argument('--apply', action='store_true')
    mode.add_argument('--revert', action='store_true')
    mode.add_argument('--show-diff', action='store_true')
    args = parser.parse_args()
    root = args.kernel_source.resolve()
    target = root / REL
    if not (root / 'Makefile').is_file() or not target.is_file():
        parser.error('Missing kernel Makefile or remoteproc source')
    backup = target.with_name(target.name + '.pre-phase9.11.5')
    stamp = target.with_name(target.name + '.phase9.11.5.sha256')
    old = target.read_bytes()
    if args.revert:
        if not backup.is_file() or not stamp.is_file():
            parser.error('9.11.5 backup/checksum absent; cannot revert')
        original = backup.read_bytes()
        if sha(old) != stamp.read_text().strip() or transform(original) != old:
            parser.error('Source modified or backup mismatch; refusing unsafe revert')
        target.write_bytes(original)
        backup.unlink()
        stamp.unlink()
        print('REVERTED 9.11.5: original 9.11.3-r1 source restored byte-for-byte')
        return
    if 'PYRA_PHASE_9_11_5_RESET_SEQUENCED_AMMU_BOOT_VALIDATION' in old.decode('utf-8'):
        if backup.is_file() and stamp.is_file() and sha(old) == stamp.read_text().strip():
            if args.apply:
                print('PASS: already installed with intact checksum')
            elif args.check:
                print('PASS: already installed with intact checksum')
            elif args.show_diff:
                print('PASS: already installed; no new diff')
            return
        parser.error('9.11.5 markers found but state corrupt; refusing changes')
    try:
        updated = transform(old)
    except (ValueError, UnicodeDecodeError) as e:
        parser.error(str(e))
    print('PASS: exact 9.11.3-r1 diagnostic helper and integration markers verified')
    print('source SHA256 before', sha(old))
    print('source SHA256 after ', sha(updated))
    if args.show_diff:
        sys.stdout.writelines(difflib.unified_diff(
            old.decode().splitlines(True), updated.decode().splitlines(True),
            fromfile='omap_remoteproc.c.9.11.3', tofile='omap_remoteproc.c.9.11.5'))
        return
    if args.check:
        return
    if backup.exists() or stamp.exists():
        parser.error('Already existing 9.11.5 backup/stamp; refusing overwrite')
    backup.write_bytes(old)
    try:
        target.write_bytes(updated)
        stamp.write_text(sha(updated) + '\n')
    except BaseException:
        target.write_bytes(old)
        backup.unlink(missing_ok=True)
        stamp.unlink(missing_ok=True)
        raise
    print('APPLIED 9.11.5 to one file. Build and staged install are separate.')


if __name__ == '__main__':
    try:
        main()
    except OSError as e:
        sys.exit('ERROR: ' + str(e))
