# Phase 9.11.5 r1 – Installer-Marker-Korrektur

**Ursache:** `apply-phase9.11.5.py` verlangte fälschlich den alten
`PYRA9112: STAGEB_DISABLED`-Marker. Dieser stand ausschließlich im
Phase-9.11.2-AMMU-Funktionsblock. Beim Übergang zu 9.11.3-r1 wurde
dieser Block vollständig durch die read-only-Funktion ersetzt und der
Marker damit absichtlich entfernt.

**Korrektur:** Der Installer verlangt nun stattdessen
`PYRA9113: WRITE_AND_BOOT_MODES_DISABLED` und weiterhin den vollständigen
bytegenauen Abgleich mit dem mitgelieferten ursprünglichen
9.11.3-r1-Funktionsblock sowie die exakten Guard-/Parameter-Anker.
Die Sicherheitsprüfung wurde nicht abgeschaltet oder gelockert.

**Umfang:** Nur Installer-Marker-Prüfung, dazugehörige Offline-Tests und
Dokumentation aktualisiert. `kernel/pyra15-boot-helper.cfrag`, Firmware-v5,
Kernelstartlogik, Bootparameter und Resetsequenz wurden **nicht** verändert.

**Auf der Pyra:** Das fehlerhafte `--check` hat keine Kernelquelle geändert.
Das bisherige Projektverzeichnis kann durch dieses r1-Archiv ersetzt werden;
die Kernelquelle muss dafür nicht auf eine frühere Phase zurückgesetzt werden.

```
python3 -m unittest discover -s tests -v
python3 apply-phase9.11.5.py "$SRC" --check
python3 apply-phase9.11.5.py "$SRC" --apply
```

Wenn `--check` danach einen anderen Fehler meldet, bitte den vollständigen
Wortlaut übermitteln. Die nächste Sicherheitsprüfung darf dann nicht blind
umgangen werden.
