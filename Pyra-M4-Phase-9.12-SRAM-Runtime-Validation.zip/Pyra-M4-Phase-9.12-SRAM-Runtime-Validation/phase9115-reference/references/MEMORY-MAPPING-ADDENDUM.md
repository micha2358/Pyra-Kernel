# Phase 9.11.4-r1 – TRM-Kapitel 2 „Memory Mapping“ (rein statisch)

**Quelle:** vom Benutzer bereitgestellte `Memory Mapping.pdf`, TI OMAP543x TRM **SWPU249AG**, Revision Dezember 2017, §2.4, **Tabelle 2-9**, PDF-Seite **18/20**, gedruckte TRM-Seite **320**. Das originale PDF wird aus urheberrechtlichen Gründen nicht im Projekt-ZIP weitergegeben. Erkenntnisse wurden mit PDF-Tabellenbild und Text verglichen.

## Neu unmittelbar dokumentiert

1. `IPU_BOOT_SPACE` **0x00000000–0x00003FFF**, **16 KiB**. Fußnote (1): *At reset, the MMU is loaded with page 0, which forces the L2 RAM to be at address 0x0.* Die **initiale Einblendung des internen L2-RAM bei Adresse 0** ist damit dokumentiert, nicht nur vermutet. Das ist eine Hardware-Beschreibung des Reset-Zustands, kein Test des realen Fetchs nach Linux-Initialisierung.
2. Dieselbe Fußnote: Seite 1 bildet die physischen Shared-Cache/MMU- und WUGEN-IPU-Register auf die **lokale Adresse 0x40000000** ab. Das passt zu `P1_ADDR=0x40000000`, `P1_XLTE=0x55080000` aus dem Messprotokoll, ohne damit den vollständigen Registerzustand des Reset-Zeitpunkts zu beweisen.
3. `RRAM_IPU` ist **0x55020000–0x5502FFFF**, **64 KiB**. Fußnote (2): Dieser Bereich ist zusätzlich **über den OCP-Slave-Port** erreichbar. Das erklärt, warum ein Linux-Treiber das RAM per physischer Systembusadresse laden kann, ohne den M4-Zugriffspfad zu demonstrieren.
4. `ROM_IPU`: **0x55000000–0x55003FFF**, 16 KiB. Der ROM-Bereich und das Boot-Fenster dürfen nicht verwechselt werden. Das TRM nennt explizit für das **Boot-Fenster** L2-RAM an Adresse null.
5. `SCACHE_MMU_IPU_CONF_REGS`: **0x55080000–0x55080FFF**, 4 KiB, enthält `0x55080800` und das Register `0x550809A0`.
6. `SCACHE_MMU_IPU_CONF_REGS` (externe/L3-Konfiguration): **0x55082000–0x55082FFF**, 4 KiB; bestätigt separate Konfigurationsregion der L3-seitigen MMU.
7. `L3_MAIN` im IPU-Adressraum umfasst grundsätzlich **0x00000000–0x54FFFFFF** (mit speziellen lokalen Überblendungen). `0x20000000` liegt darin, aber **Tabelle 2-9 definiert es nicht als native IPU-SRAM-Aliasadresse**. Die Linux-Remoteproc-DA `0x20000000` bleibt ein **Software-Ladeadressvertrag**, kein automatisch nachgewiesener M4-Reset-Fetch-Pfad.

## Korrelation mit Phase 9.11.3 und Sicherheitsgrenzen

| Sachverhalt | Quellenlage | Schluss |
|---|---|---|
| Resetadresse null blendet internen IPU-L2-RAM ein | TI §2.4 Tabelle 2-9 Fn. (1) | **Im dokumentierten Resetmodell bestätigt** |
| P0-Region `0x00000000`, XLTE-Reset `0x55020000` | TI §7.4.4 (früheres IPU-PDF) plus §2.4 | **Widerspruchsfrei zusammenpassend** |
| Linux-Ladevorgang nach `0x55020000` | TI §2.4 Fn. (2) plus Remoteproc-Log | **OCP-Zugänglichkeit erklärt, kein M4-Fetch-Beweis** |
| Beobachteter `P0_XLTE=0` / `P0_POLICY=0x0B` | Phase 9.11.3 bei ~276s nach Linux-Boot | **Nicht gleich dokumentiertem Resetzustand** |
| `P1_ADDR=0x40000000`, `P1_XLTE=0x55080000` | TI §2.4 Fn. (1) plus Phase 9.11.3 | **Plausibel, nicht als Live-Fetch belegt** |
| Externe L2-MMU-PTE für lokalen Fetch | §2.4 benennt lokale SRAM-Überblendung; kein explizites Bypass-Signal | **Noch nicht abschließend bewiesen** |

### Besonders wichtiger Interpretationsvorbehalt

Der Satz *„At reset, the MMU is loaded with page 0“* beschreibt die Initialisierung des **Boot-Mappings**, nicht zwingend einen Linux-seitig später sichtbaren, unveränderlichen Registerzustand. Gleichzeitig nennt §7.4.4 für `SMALL_POLICY` den Resetwert 0. Das könnte verschiedene Reset-Phasen, Initialisierungsschritte oder nicht ohne Weiteres vergleichbare Registerzustände betreffen. **Kein Widerspruch wird ohne zusätzliche Quellen durch Mutmaßungen aufgelöst.**

### Ergebnis für die Phase 9.11.4

Die zuvor **offene dokumentarische Frage nach dem anfänglichen M4-Adressfenster bei null ist jetzt geklärt**. Ungeklärt bleiben der **tatsächliche** Zustand beim späteren Remoteproc-Start, der Zeitpunkt/Verursacher der abweichenden AMMU-Registerwerte und der konkrete externe L2-MMU-Pfad. Der sichere Projektstatus bleibt **OFFLINE_ONLY**. Keine CPU0-Freigabe, kein AMMU-Write, keine Firmwareausführung.
