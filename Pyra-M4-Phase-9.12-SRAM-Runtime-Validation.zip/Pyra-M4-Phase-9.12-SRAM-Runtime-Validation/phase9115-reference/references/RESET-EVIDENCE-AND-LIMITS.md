# New TRM chapter 3 assessment for Phase 9.11.5

**TI OMAP543x TRM SWPU249AG, public revision December 2017, user's `Reset.pdf`.** Printed page numbers below are TI TRM page labels, not PDF pages. The PDF contents and reset-waveform images have been inspected; primary source PDFs are not redistributed.

## Directly documented

**§3.5.6.10, pp.395–396, Figure 3-28, IPU Power-On Reset Sequence.** Software first clears bit 2 `RST_IPU_MMU_CACHE` of `RM_IPU_RSTCTRL`. The PRCM releases IPU_PWRON_RST following clock/start conditions and then releases `IPU_MMU_CACHE_RST` and `IPU_RET_RST`. MPU software *must configure CACHE_MMU_IPU after it is out of reset* and initialize cache. Only then may it clear bit 0 `RST_CPU0`, causing CPU0 to begin booting. CPU1 reset is separately controlled by bit 1. The chapter does not provide an explicit evidence record of the Linux driver's full SCACHE setup.

**§3.5.6.11, pp.396–397, Figure 3-29, IPU Software Warm Reset Sequence.** TI requires the relevant CPUs in IDLE and clocks gated when doing software warm reset. It asserts MMU/cache and CPU0 reset as part of a staged sequence, and later releases them when clock and initialization sequence are complete. We do **not** initiate this reset in 9.11.5. Forcing it would also risk discarding an AMMU change performed beforehand.

**Table 3-423, p.596.** `RM_IPU_RSTCTRL` physical `0x4AE06910`, bits 2,1,0: `RST_IPU_MMU_CACHE`, `RST_CPU1`, `RST_CPU0`. Reset value 1 for each. Earlier PRM logs observed register `0x7` before MMU/cache release and `0x3` afterward, while separate reset-control APIs still reported CPU0=1 CPU1=1. This is why 9.11.5 requires **0x3** and reads both reset-control statuses.

**Table 3-425, p.597.** `RM_IPU_RSTST` at `0x4AE06914` is a write-one-to-clear log of prior reset-release events. Phase 9.11.5 reads it only, never acknowledges or changes flags.

**Table 3-427, p.598.** `RM_IPU_IPU_CONTEXT` at `0x4AE06924` indicates IPU context status. Phase 9.11.5 reads it for diagnosis only. Its mere value does not certify SCACHE initialization.

**Table 3-36, p.386.** IPU reset release depends on clock activity, reset-manager timing, and other reset conditions. Register writes alone are not proof that a reset release or first fetch occurred.

**§2.4/Table 2-9, p.320.** Boot space `0x00000000–0x00003FFF` locally aliases L2 RAM at reset, while bus RRAM `0x55020000–0x5502FFFF` is 64KiB. Separate IPU ROM `0x55000000–0x55003FFF` does not automatically imply boot from ROM. The Linux firmware DA `0x20000000` is a loader-side address in the existing driver, not a proven M4 reset alias.

## Confirmed from previous Pyra observations

- `RSTCTRL` readbacks: `0x7` at probe before IPU MMU release, `0x3` after release.
- CPU0=1 CPU1=1 in Phase 9.11.3 (while `P0_XLTE=0`, `P0_POLICY=0xB`, `MMUCONFIG/MAINT/MAINTST=0`).
- Earlier guarded Stage A write `P0_XLTE=0x55020000`, readback and rollback succeeded without CPU0 release.
- V5 firmware vector via Linux loader SRAM readback: MSP=0x00001000, Reset_PC=0x00000041. This verifies the load image, not the M4 fetch route.

## Open engineering risks

1. Why measured XLTE0 differs from TRM reset XLTE0 (`0x55020000`), and who last configured the IPU shared cache.
2. Whether the IPU SCACHE initialization and coherence conditions from §3.5.6.10 are fully met after Linux MMU attachment and firmware upload.
3. Whether P0 XLTE register readback immediately affects Cortex-M4 instruction fetch, or requires further hardware-specific cache/synchronization operations.
4. Whether existing Linux start path actually releases *only* CPU0 on this locally patched kernel. We require CPU0-only module parameter and pre-release checks but cannot test the board's real deassert sequence offline.
5. A post-commit failure inside the original `omap_rproc_start` could leave XLTE0 changed; recover via reboot instead of blindly resetting cache/MMU or retrying.

**The purpose of Phase 9.11.5 is to test #3 under narrow conditions, not to claim the preceding points have been conclusively resolved.**
