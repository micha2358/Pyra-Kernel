# Quellen- und Belegmatrix – Phase 9.11.4

Stand: 2026-10-24. Grundlage sind die vom Benutzer bereitgestellten Kapitel-PDFs des TI-TRM **SWPU249AG**, der Firmware-v5-Quellstand, der Phase-9.11.3-Kernelpatch und das Phase-9.11.3-Log vom 24.10.2026. Es wurde **kein** M4-Start durchgeführt.

> PDF-Seiten sind **1-basiert und beziehen sich auf die einzelnen hochgeladenen Kapitel-Auszüge**, nicht auf das vollständige TRM. Zusätzlich stehen die gedruckten TRM-Seiten dabei. PDF-Extracts unterliegen dem TI-Copyright und sind bewusst nicht in dieses ZIP kopiert.

## A. IPU-spezifische Fakten (direkt belegt)

| Fakt | Quelle | Einstufung |
|---|---|---|
| `SCACHE_MMU_IPU` beginnt bei **0x55080800** | `Cortex-M4 IPU Subsystem.pdf`, PDF-S. 17, TRM-S. 1428, §7.4.1 / Tab. 7-10 | DOKUMENTIERT |
| `IPU_L2_MMU` beginnt bei **0x55082000** | gleiche Quelle | DOKUMENTIERT |
| Physischer IPU-RAM-Bereich **0x55020000..0x5502FFFF** | IPU-PDF, §7.3.1, TRM-S. 1418 | DOKUMENTIERT |
| IPU besitzt **10 Small Pages** mit **4 KiB oder 16 KiB** | IPU-PDF, §7.3.4, §7.4.4, TRM-S. 1424 und 1428f | DOKUMENTIERT |
| `SMALL_ADDR_0` Reset=0; `_1` Reset=0x40000000 | IPU-PDF, PDF-S. 17, §7.4.4 | DOKUMENTIERT |
| `SMALL_XLTE_0` Reset=**0x55020000**; `_1` Reset=0x55080000 | IPU-PDF, PDF-S. 17, §7.4.4 | DOKUMENTIERT |
| `SMALL_POLICY_k` Reset=**0** für k=0..9 | IPU-PDF, PDF-S. 17, §7.4.4 | DOKUMENTIERT |
| `L2_MMU` übersetzt Zugriffe **vom IPU auf L3_MAIN** | IPU-PDF, §7.3.5, TRM-S. 1424f | DOKUMENTIERT |
| Für SCACHE_MMU_IPU-Register gilt Verweis auf DSP-Registerkapitel **mit expliziten IPU-Abweichungen** | IPU-PDF, PDF-S. 17, §7.4.4 | DOKUMENTIERT |

## A2. Neuer direkter IPU-Bootnachweis (TI Memory Mapping, §2.4)

- **`Memory Mapping.pdf`, PDF-S. 18, gedruckte TRM-S. 320, Tabelle 2-9, Fußnote (1):** Bei Reset wird IPU-L2-RAM über Seite 0 an **0x00000000** eingeblendet. Seite 1 bindet MMU- und WUGEN-Register an **0x40000000** ein.
- **Tabelle 2-9:** `IPU_BOOT_SPACE` = `0x00000000..0x00003FFF` (16 KiB), `RRAM_IPU` = `0x55020000..0x5502FFFF` (64 KiB), `ROM_IPU` = `0x55000000..0x55003FFF` (16 KiB).
- **Fußnote (2):** Die physischen IPU-Bereiche sind außerdem über den **OCP-Slave-Port** zugreifbar. Remoteproc-Laden und M4-Fetch sind deshalb separat zu bewerten.
- **Tabelle 2-9:** getrennte MMU-Konfigurationsbereiche `0x55080000..0x55080FFF` und `0x55082000..0x55082FFF`.
- Das TRM nennt `0x20000000` **nicht** als IPU-Boot-SRAM-Alias. Die externe L2-MMU wird dadurch weder als notwendig noch als unwichtig für alle Fälle nachgewiesen.
- Diese Angaben beschreiben den **Resetzustand**, nicht den später gemessenen Zustand nach Linux-Boot. Details: `references/MEMORY-MAPPING-ADDENDUM.md`.

## B. Die referenzierten Registerdefinitionen (DSP-Kapitel, mit IPU-Verweis)

| Register | Relativer Offset | Physische Adresse IPU | Referenz |
|---|---|---|---|
| `SMALL_ADDR_0` | 0x0120 | **0x55080920** | DSP-PDF §5.5.12.2 / Tab. 5-502, PDF-S. 313 |
| `SMALL_XLTE_0` | 0x01A0 | **0x550809A0** | DSP-PDF §5.5.12.2 / Tab. 5-505, PDF-S. 313 |
| `SMALL_POLICY_0` | 0x0220 | **0x55080A20** | DSP-PDF §5.5.12.2 / Tab. 5-507, PDF-S. 314 |
| `MAINT` | 0x04A8 | 0x55080CA8 | DSP-PDF §5.5.12.1 / Tab. 5-489, PDF-S. 308 |
| `MAINTST` | 0x04B4 | 0x55080CB4 | DSP-PDF §5.5.12.1 / Tab. 5-489, PDF-S. 308 |
| `MMUCONFIG` | 0x04B8 | 0x55080CB8 | DSP-PDF §5.5.12.1 / Tab. 5-489, PDF-S. 308 |

**Wichtige Präzisierung:** DSP-PDF §5.5.12.1, unter Tab. 5-489, enthält den ausdrücklichen Hinweis, dass `LARGE_XLTE_i`, `MED_XLTE_j` und `SMALL_XLTE_k` **nicht** in der DSP-SCACHE-MMU verfügbar sind, sondern **nur in der IPU-SCACHE-MMU**. Die IPU-spezifische Rolle der XLTE-Register ist damit kein bloßes Analogieschlussargument.

**Einschränkung:** Es handelt sich weiterhin um den Abgleich von zwei TRM-Kapiteln. Der absolute IPU-Registerwert ergibt sich rechnerisch aus IPU-Basis + dokumentiertem relatives Offset. Die Funktion des Start-Fetchs ist damit noch nicht bewiesen.

## C. Bitfeld `SMALL_POLICY` (DSP-Tab. 5-507, §5.5.12.2)

- Bit 0 `ENABLE`
- Bit 1 `SIZE`; IPU: 0 -> 4 KiB, 1 -> 16 KiB (IPU-PDF §7.4.4)
- Bit 3 `VOLATILE`
- Bit 4 `EXECUTE` (laut TRM: „execute only“, nicht pauschal „execute permitted“)
- Bit 5 `READ` (laut TRM: „read only“, nicht pauschal „read permitted“)
- Bit 2 ist im DSP-Kapitel **reserved**; über sein IPU-Resetverhalten darf aus der DSP-Resetspalte nichts übernommen werden.
- `SMALL_XLTE` Bit 0 ist `IGNORE` („Do not use translated address“), Tab. 5-505. In den Logs ist Bit 0 bei P0/P1 = 0.

**Dekodierung des beobachteten Zustands:**

- `P0_POLICY=0x0000000B` -> ENABLE=1, SIZE=1 (16KiB), VOLATILE=1; EXECUTE-only=0, READ-only=0.
- `P1_POLICY=0x00000009` -> ENABLE=1, SIZE=0 (4KiB), VOLATILE=1.
- Die `P0_XLTE=0`-Abbildung zeigt **keinen** SRAM-Zielwert `0x55020000`. Weder „unbrauchbar“ noch „Boot blocker“ folgt allein aus dieser Beobachtung, solange Zugriffsweg/Resetzustand ungeklärt sind.

## D. Linux-Quellcode und Firmware

- Linux-TI `drivers/remoteproc/omap_remoteproc.c`: `ipu_mems[]` verwendet `dev_addr = 0x20000000` für `l2ram`; `.da_to_va` löst die Device-Adresse über die interne `oproc->mem[]`-CPU-Abbildung auf. Sichtbarer Referenzstand: https://git.ti.com/cgit/ti-linux-kernel/ti-linux-kernel-next/tree/drivers/remoteproc/omap_remoteproc.c?id=ec115c7d941ddf771846a52184c6c673925a6113
- OMAP5-Device-Tree-Referenz: `ipu@55020000`, `reg-names = "l2ram"`, `iommus = <&mmu_ipu>`: https://kunit.googlesource.com/linux/+/refs/heads/torvalds/master/arch/arm/boot/dts/omap5.dtsi
- **Versionsvorbehalt:** Ob die **lokal gepatchte** Pyra-Kernelquelle 5.6.19 alle genannten Details enthält, prüft das beigepackte Skript mit `--kernel ...`. Aktuelle Upstream-Quellen dürfen den lokalen Branch nicht ersetzen.
- Firmware v5 ELF-Datei: ARM ELF32 little-endian; `e_entry=0x41`, PT_LOAD VMA 0x0/0x40, PADDR-Ladeadressen 0x20000000/0x20000040. `.tracebuf` 0x800, Linux-Ladeadresse 0x20000800, `.resource_table` unter 0x20001000. Das ist ein **Software-Build-/Ladeadressvertrag**; es beweist keinen erfolgreichen M4-Resetvektor-Fetch.

## E. Beobachtungen Phase 9.11.3

Aus `samples/phase9113-dmesg-focus.log`:

- `P0_ADDR=0`, `P0_XLTE=0`, `P0_POLICY=0xB`, `P1_ADDR=0x40000000`, `P1_XLTE=0x55080000`, `P1_POLICY=0x9`.
- `L2_SOFTWARE_SUMMARY count=0` **gilt ausschließlich** für `rproc->mappings`, nicht für alle möglichen Hardwareübersetzungen oder TLB-Zustände.
- `CARVEOUT_SUMMARY count=0` bezieht sich ausschließlich auf `rproc->carveouts`.
- `DA_TO_VA da0=0 da20000000=1 trace20000800=1 pointer_only=1`: Linux kann SRAM durch direkten Treiberpfad adressieren; nicht als Beweis für L2-IOMMU-Wirksamkeit interpretieren.
- `COMPLETE snapshot_known=1 reset_held=1 cpu0_not_released=1 writes=0` ist die begrenzte Messbehauptung des Phase-9.11.3-Kernels.
- Der frühe L3-Fehler liegt bei ~2,94 s; Phase-9.11.3-Diagnose bei ~276 s. Keine zeitliche Koinzidenz.

## F. Noch offen und nicht zu extrapolieren

1. **Dokumentiert:** Bootadresse 0 wird bei Reset auf IPU-L2-RAM eingeblendet (TRM §2.4, Fn. 1). **Weiter offen:** ob die spätere CPU0-Freigabe unter der gemessenen, abweichenden AMMU-Konfiguration diesen Pfad effektiv nutzt.
2. Ob ein IPU-Subsystem-Reset den AMMU-Zustand zurücksetzt und warum CPU0/CPU1-Reset=1 dies nicht bewirkte.
3. Wer vor der Phase-9.11.3-Messung P0/P1-Policies konfiguriert hat.
4. Ob ein Zugriff des M4 auf lokalen SRAM die externe L2-MMU umgeht. Das Blockdiagramm suggeriert getrennte Pfade; es ersetzt keine Zugriffsmessung.
5. Ob Verwendungen der XLTE-Werte in der Reset-Fetch-Pipeline die erforderliche Instruktionsausführung ermöglichen.

**Freigabe:** Keinerlei Kernelpatch, kein MMIO-Zugriff, keine CPU0-/CPU1-Freigabe im Rahmen 9.11.4.
