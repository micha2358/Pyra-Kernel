#!/usr/bin/env python3
"""Conservative Phase 9.11.5 results classifier; read only."""
from pathlib import Path
import argparse
import re
import sys

ERRORS = (
    'L3 Custom Error', 'L3 Standard Error', 'iommu fault',
    'Unhandled fault', 'bogus pgd', 'crashed', 'HardFault',
    'PYRA9115: ROLLBACK_FAILED', 'PYRA9115: POSTCHECK_FAILED',
)
STAGES = (
    'PYRA9115: PRE_RESET CPU0=1 CPU1=1',
    'PYRA9115: VECTORS MSP=00001000 PC=00000041',
    'PYRA9115: PRM RSTCTRL=00000003',
    'PYRA9115: COMMIT_ATTEMPT XLTE0=00000000->55020000',
    'PYRA9115: XLTE0_COMMIT_OK=1 PRM_READY=1 CPU0_HELD=1 CPU1_HELD=1',
    'PYRA9115: RELEASE_ALLOWED CPU0_ONLY',
)
MARKERS = ('M5A1', 'M5B2', 'M5D3')

def classify(log: str, trace: str = '', status: str = ''):
    present=[x for x in STAGES if x in log]
    absent=[x for x in STAGES if x not in log]
    errors=[x for x in ERRORS if x.lower() in log.lower()]
    # Earlier unrelated Linux startup L3 warnings do not invalidate this
    # experiment: compare only text *after* first experimental marker.
    first=log.find('PYRA9115: PRE_RESET')
    slice_=log[first:] if first>=0 else log
    errors=[x for x in ERRORS if x.lower() in slice_.lower()]
    if errors:
        return 2, 'FAIL/STOP: error after attempt: ' + ', '.join(errors)
    if absent:
        return 2, 'NOT_RELEASED_OR_UNCONFIRMED: missing ' + ', '.join(absent)
    # CPU0 may be released but in a HardFault loop. Only M4-written
    # markers plus running firmware count as functional confirmation.
    if 'M5F!' in trace:
        return 2, 'FAIL/STOP: firmware Fault_Handler wrote M5F!'
    if not all(m in trace for m in MARKERS):
        return 1, 'CPU0_RELEASE_ALLOWED_BUT_NO_EXECUTION_PROOF: trace markers absent/incomplete'
    if not re.search(r'\bstate=running\b',status):
        return 1, 'TRACE_PRESENT_BUT_REMOTE_STATE_UNCONFIRMED'
    if 'firmware=pyra-m4-ammu-v5.elf' not in status:
        return 1, 'TRACE_PRESENT_BUT_WRONG_FIRMWARE'
    return 0, 'FUNCTIONAL_V5_CONFIRMED: all three Cortex-M4 markers, remoteproc running, no post-test fault'

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('evidence_dir',type=Path)
    a=p.parse_args()
    folder=a.evidence_dir
    files=('dmesg-full.log','trace0.txt','remoteproc.txt')
    texts=[(folder/name).read_text(errors='replace') if (folder/name).is_file() else '' for name in files]
    if not texts[0]:
        p.error('dmesg-full.log absent or empty')
    code, verdict=classify(*texts)
    print(verdict)
    print('NOTE: Classifier cannot prove that CPU0 fetched from the intended physical address without hardware traces.')
    raise SystemExit(code)

if __name__=='__main__': main()
