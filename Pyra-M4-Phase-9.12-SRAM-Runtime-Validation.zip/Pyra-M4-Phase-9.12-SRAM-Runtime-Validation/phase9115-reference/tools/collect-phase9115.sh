#!/bin/sh
set -eu
out=${1:-"$HOME/pyra-phase9115-evidence"}
mkdir -p "$out"
sudo dmesg > "$out/dmesg-full.log"
grep -E 'PYRA9115|PYRA9113|PYRA9112|PYRA9111|PYRA99|PYRA98|omap-iommu|remoteproc|L3 (Custom|Standard) Error|bogus pgd' "$out/dmesg-full.log" > "$out/dmesg-focus.log" || true
cat /proc/cmdline > "$out/cmdline.txt"
uname -a > "$out/uname.txt"
for v in pyra_cpu0_only pyra10_ammu_probe pyra11_stage0_only pyra11_ammu_repair pyra11_boot_after_repair pyra13_consistency_only pyra15_boot_once; do
    f="/sys/module/omap_remoteproc/parameters/$v"
    if [ -r "$f" ]; then printf '%s=' "$v"; cat "$f"; fi
done > "$out/parameters.txt"
for r in /sys/class/remoteproc/remoteproc*; do
    [ -f "$r/name" ] || continue
    [ "$(cat "$r/name")" = '55020000.ipu' ] || continue
    for v in name state recovery firmware; do
       [ -r "$r/$v" ] && { printf '%s=' "$v"; cat "$r/$v"; } || true
    done
    b=$(basename "$r")
    [ -r "/sys/kernel/debug/remoteproc/$b/trace0" ] && cp "/sys/kernel/debug/remoteproc/$b/trace0" "$out/trace0.txt" || true
done > "$out/remoteproc.txt"
echo "Collected read-only evidence: $out"
