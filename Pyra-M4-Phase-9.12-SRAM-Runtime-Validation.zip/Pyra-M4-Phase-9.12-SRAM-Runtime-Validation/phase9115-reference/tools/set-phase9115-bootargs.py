#!/usr/bin/env python3
"""Change ONLY the LABEL m4ipu APPEND line. Leave m4base untouched."""
import argparse
from datetime import datetime
import os
from pathlib import Path
import re
import sys

PREFIX='omap_remoteproc.'
MODE_KEYS=('pyra11_stage0_only', 'pyra11_ammu_repair',
           'pyra11_boot_after_repair', 'pyra13_consistency_only', 'pyra15_boot_once')
MUST=(PREFIX+'pyra_cpu0_only=1', PREFIX+'pyra10_ammu_probe=1')
FORBIDDEN=('omap_prm.pyra_ipu_prm_assert_quirk=1',)

def locate(content):
    lines=content.splitlines(keepends=True)
    if sum(bool(re.match(r'^\s*LABEL\s+m4base\s*$', l, re.I)) for l in lines) != 1:
        raise ValueError('Recovery LABEL m4base missing or ambiguous')
    ids=[i for i,l in enumerate(lines) if re.match(r'^\s*LABEL\s+m4ipu\s*$', l,re.I)]
    if len(ids)!=1:
        raise ValueError('Require exactly one LABEL m4ipu')
    lo=ids[0]
    hi=next((i for i in range(lo+1,len(lines)) if re.match(r'^\s*LABEL\s+', lines[i],re.I)),len(lines))
    inds=[i for i in range(lo+1,hi) if re.match(r'^\s*APPEND\s+',lines[i],re.I)]
    if len(inds)!=1:
        raise ValueError('Require exactly one APPEND in LABEL m4ipu')
    return lines,inds[0]

def edit(content,mode):
    lines,i=locate(content)
    args=lines[i].split()[1:]
    # Bare boolean arguments are valid Linux boot arguments, but easy to
    # overlook when removing key=value forms; never silently preserve them.
    if any(PREFIX+k in args for k in MODE_KEYS):
        raise ValueError('Bare experimental mode flag detected; inspect m4ipu')
    for k in ('pyra_cpu0_only','pyra10_ammu_probe'):
        present=[x for x in args if x == PREFIX+k or x.startswith(PREFIX+k+'=')]
        if len(present)!=1 or present[0]!=PREFIX+k+'=1':
            raise ValueError('Expected exactly one '+PREFIX+k+'=1')
    if any(flag in args for flag in FORBIDDEN):
        raise ValueError('Dangerous reset quirk in m4ipu! Remove manually after review')
    if mode in ('diagnose','arm'):
        for arg in MUST:
            if arg not in args:
                raise ValueError('Missing required flag: '+arg)
    clean=[x for x in args if not any(x.startswith(PREFIX+k+'=') for k in MODE_KEYS)]
    if mode=='diagnose':
        clean.append(PREFIX+'pyra13_consistency_only=1')
    elif mode=='arm':
        clean.append(PREFIX+'pyra15_boot_once=1')
    elif mode!='disable':
        raise ValueError('Unknown mode')
    indent=re.match(r'^(\s*)',lines[i]).group(1)
    newline='\r\n' if lines[i].endswith('\r\n') else '\n'
    lines[i]=indent+'APPEND '+' '.join(clean)+newline
    return ''.join(lines)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode',choices=('check','diagnose','arm','disable'))
    p.add_argument('--config',type=Path,default=Path('/boot/extlinux/user.cfg'))
    p.add_argument('--accept-experimental-cpu0-boot',action='store_true')
    p.add_argument('--confirm-m4base-recovery',action='store_true')
    a=p.parse_args()
    old=a.config.read_text()
    lines,i=locate(old)
    if a.mode=='check':
        args=lines[i].split()[1:]
        for key in ('pyra_cpu0_only','pyra10_ammu_probe',*MODE_KEYS):
            print(f'{key} = {next((x for x in args if x.startswith(PREFIX+key+"=")),"unset")}')
        print('m4base present; this script will not edit it')
        return
    if a.mode=='arm' and not (a.accept_experimental_cpu0_boot and a.confirm_m4base_recovery):
        p.error('For arm: BOTH --accept-experimental-cpu0-boot and --confirm-m4base-recovery required')
    new=edit(old,a.mode)
    if new==old:
        print('No change'); return
    dest=a.config
    backup=dest.with_name(dest.name+'.pre-phase9115-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
    tmp=dest.with_name(dest.name+'.tmp-phase9115')
    if tmp.exists() or backup.exists():
        p.error('Temporary/backup conflict; no change')
    # Atomic replacement within the same directory, retaining m4base and
    # every other stanza verbatim. Preserve prior file permissions.
    backup.write_text(old)
    backup.chmod(0o600)
    try:
        tmp.write_text(new)
        tmp.chmod(dest.stat().st_mode & 0o777)
        os.replace(tmp,dest)
    finally:
        tmp.unlink(missing_ok=True)
    print('Updated LABEL m4ipu only:',a.mode)
    print('Backup:',backup)
    print('REBOOT is required for changes in kernel command-line options')

if __name__=='__main__':
    try: main()
    except (ValueError,OSError) as e: sys.exit('ERROR: '+str(e))
