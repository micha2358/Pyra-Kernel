#!/usr/bin/env python3
"""Read-only active omap_remoteproc / Phase 9.11.5 deployment inspection.

No module loading, reset writes, firmware starts or bootloader modifications.
"""
import argparse
import gzip
import lzma
from pathlib import Path
import platform
import re
import sys

REQUIRED = ('pyra_cpu0_only', 'pyra10_ammu_probe', 'pyra15_boot_once')
CONFLICT = ('pyra11_stage0_only', 'pyra11_ammu_repair',
            'pyra11_boot_after_repair', 'pyra13_consistency_only')
MARKER = b'pyra15_boot_once'

def read(path):
    try:
        return path.read_bytes()
    except (OSError, ValueError):
        return None

def config_mode(root, release):
    checks = [root / 'proc/config.gz', root / 'boot' / ('config-' + release),
              root / 'lib/modules' / release / 'build/.config']
    for path in checks:
        data = read(path)
        if data is None:
            continue
        try:
            if str(path).endswith('.gz'):
                data = gzip.decompress(data)
        except (OSError, EOFError):
            continue
        m = re.search(rb'^CONFIG_OMAP_REMOTEPROC=(y|m)$', data, re.M)
        if m:
            return m.group(1).decode(), str(path)
        if b'# CONFIG_OMAP_REMOTEPROC is not set' in data:
            return 'n', str(path)
    return None, None

def embedded_marker(path):
    data = read(path)
    if data is None:
        return 'unreadable'
    try:
        if path.suffix == '.xz':
            data = lzma.decompress(data)
        elif path.suffix == '.gz':
            data = gzip.decompress(data)
        elif path.suffix == '.zst':
            return 'zstd requires external decompression'
    except (OSError, EOFError, lzma.LZMAError):
        return 'decompression failed'
    return 'yes' if MARKER in data else 'no'

def evaluate(root, release, source=None, build=None):
    messages = []
    def say(line): messages.append(line)
    say('Kernel release: ' + release + '  [NOT proof of build identity]')
    cmdline = read(root / 'proc/cmdline')
    args = cmdline.decode(errors='replace').split() if cmdline else []
    active_args = [a for a in args if a.startswith('omap_remoteproc.pyra')]
    say('Live bootargs: ' + (' '.join(active_args) if active_args else '(none readable)'))
    params = root / 'sys/module/omap_remoteproc/parameters'
    names = sorted(p.name for p in params.iterdir()) if params.is_dir() else []
    say('Active parameter directory: ' + (str(params) if names else '(absent or empty)'))
    say('Active Pyra parameters: ' + (' '.join(n for n in names if n.startswith('pyra')) or '(none)'))
    missing = [n for n in REQUIRED if n not in names]
    conflicts = []
    for n in REQUIRED + CONFLICT:
        if n in names:
            data = read(params / n)
            value = data.decode(errors='replace').strip() if data is not None else '?'
            say('  ' + n + '=' + value)
            if n in REQUIRED and value not in ('Y','1'):
                conflicts.append(n + ' is not enabled')
            elif n in CONFLICT and value not in ('N','0'):
                conflicts.append(n + ' conflicts')
    if missing:
        say('MISSING live parameters: ' + ', '.join(missing))
    if conflicts:
        say('INVALID live parameter state: ' + ', '.join(conflicts))
    mode, config_file = config_mode(root, release)
    say('CONFIG_OMAP_REMOTEPROC: ' + (mode or 'unknown') + (' from ' + config_file if config_file else ''))
    if mode == 'y':
        say('Driver is built into zImage; installing a .ko cannot replace it.')
        say('Check that the m4ipu boot entry actually loads the newly staged zImage, then reboot.')
    elif mode == 'm':
        say('Driver is loadable; both the installed .ko and the loaded instance must be current.')
        moddir = root / 'lib/modules' / release
        candidates = list(moddir.glob('**/omap_remoteproc.ko*')) if moddir.is_dir() else []
        if not candidates:
            say('Installed omap_remoteproc.ko*: NOT FOUND under ' + str(moddir))
        for p in candidates[:8]:
            say('Installed module: ' + str(p) + '  marker=' + embedded_marker(p))
        say('An installed newer .ko does not replace an already loaded older module.')
    if source is not None:
        p = source / 'drivers/remoteproc/omap_remoteproc.c'
        say('Source ' + str(p) + ': marker=' + embedded_marker(p))
    if build is not None:
        obj = build / 'drivers/remoteproc/omap_remoteproc.o'
        say('Build object ' + str(obj) + ': marker=' + embedded_marker(obj))
        stage = build / 'stage-phase9115'
        for p in sorted(stage.glob('lib/modules/**/omap_remoteproc.ko*'))[:8]:
            say('Staged module ' + str(p) + ': marker=' + embedded_marker(p))
        staged_image = stage / 'boot/zImage-5.6.19-pyradef-m4test'
        say('Staged zImage exists: ' + str(staged_image.is_file()))
    if missing:
        say('RESULT: BLOCKED. New runtime driver not confirmed; CPU0 start must NOT run.')
        return 3, messages
    if conflicts:
        say('RESULT: BLOCKED. Required runtime parameter states not satisfied.')
        return 4, messages
    say('RESULT: ACTIVE FLAGS PRESENT. This is NOT proof of MMU/cache readiness or M4 execution.')
    return 0, messages

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, help='kernel source directory (optional)')
    parser.add_argument('--build', type=Path, help='out-of-tree build directory (optional)')
    parser.add_argument('--root', type=Path, default=Path('/'), help=argparse.SUPPRESS)
    parser.add_argument('--kernel-release', default=platform.uname().release, help=argparse.SUPPRESS)
    a = parser.parse_args()
    code, msgs = evaluate(a.root, a.kernel_release, a.source, a.build)
    print('\n'.join(msgs))
    sys.exit(code)

if __name__ == '__main__':
    main()
