#!/usr/bin/env bash
# Experimental one-shot CPU0 start. Does nothing without explicit acceptance.
set -euo pipefail
ROOT=$(CDPATH= cd -- "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
FWROOT="$ROOT/firmware-v5"
TOKEN=${1:-}
[ "$TOKEN" = 'BOOT-CPU0-ONCE' ] || { echo 'Usage: sudo ./tools/start-phase9115.sh BOOT-CPU0-ONCE' >&2; exit 2; }
[ "$(id -u)" = 0 ] || { echo 'ERROR: run with sudo' >&2; exit 1; }
[ "$(uname -r)" = '5.6.19-pyradef-m4test' ] || { echo 'ERROR: wrong kernel' >&2; exit 1; }
[ -f /boot/extlinux/user.cfg ] && grep -Eq '^\s*LABEL\s+m4base\s*$' /boot/extlinux/user.cfg || { echo 'ERROR: m4base recovery entry missing' >&2; exit 1; }
if ! tr ' ' '\n' < /proc/cmdline | grep -Fxq 'omap_remoteproc.pyra15_boot_once=1'; then
  echo 'ERROR: boot parameter missing. Arm it through set-phase9115-bootargs.py and reboot.' >&2; exit 1
fi
if tr ' ' '\n' < /proc/cmdline | grep -Fxq 'omap_remoteproc.pyra13_consistency_only=1'; then
  echo 'ERROR: diagnostic and boot modes conflict' >&2; exit 1
fi
for flag in pyra_cpu0_only pyra10_ammu_probe pyra15_boot_once; do
  param="/sys/module/omap_remoteproc/parameters/$flag"
  if [ ! -r "$param" ]; then
    echo "ERROR: active omap_remoteproc does not expose $flag." >&2
    echo 'The staged new kernel/driver is likely not running; uname -r is insufficient.' >&2
    echo 'Read-only deployment diagnostic:' >&2
    python3 "$ROOT/tools/check-active-phase9115.py" \
      --source /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef \
      --build /mnt/pyra-kernel-m4/build-pyradef10-m4 >&2 || true
    echo 'CPU0 remains blocked. Verify/install matching staged kernel or module, then reboot.' >&2
    exit 1
  fi
  case "$(cat "$param")" in Y|1) ;; *) echo "ERROR: inactive $flag" >&2; exit 1;; esac
done
for flag in pyra11_stage0_only pyra11_ammu_repair pyra11_boot_after_repair pyra13_consistency_only; do
  param="/sys/module/omap_remoteproc/parameters/$flag"
  [ -r "$param" ] || { echo "ERROR: missing $flag" >&2; exit 1; }
  case "$(cat "$param")" in N|0) ;; *) echo "ERROR: conflicting $flag" >&2; exit 1;; esac
done
# Original prebuilt and unmodified 9.11.2/9.11.3 firmware contract.
EXPECTED=629cfe1c21f9a6c12f9ba75819d09a1b74f8ac2b70ae9f12511b03ec446ab04f
ELF="$FWROOT/build/pyra-m4-ammu-v5.elf"
[ -f "$ELF" ] || { echo 'ERROR: missing v5 ELF' >&2; exit 1; }
CURRENT=$(sha256sum "$ELF" | cut -d' ' -f1)
[ "$CURRENT" = "$EXPECTED" ] || { echo 'ERROR: unexpected firmware SHA256' >&2; exit 1; }
python3 "$FWROOT/tools/check_elf.py" "$ELF"
LOG="$HOME/pyra-phase9115-start-$(date +%Y%m%d-%H%M%S).log"
echo "EXPERIMENTAL CPU0-ONLY one-shot; recovery disabled and no automatic retry. LOG: $LOG"
echo 'This attempts real Cortex-M4 execution on the Pyra; an IOMMU/L3 error or hang remains possible.'
(
  echo "BEGIN $(date -Is)";
  dmesg | grep -E 'PYRA99:.*RSTCTRL=|PYRA9113:|PYRA9115:' | tail -22 || true
  "$FWROOT/run-pyra.sh" --start OK
  echo 'AFTER_START';
  dmesg | grep -E 'PYRA9115:|remoteproc|L3 (Custom|Standard) Error|bogus pgd' | tail -75 || true
) 2>&1 | tee "$LOG"
