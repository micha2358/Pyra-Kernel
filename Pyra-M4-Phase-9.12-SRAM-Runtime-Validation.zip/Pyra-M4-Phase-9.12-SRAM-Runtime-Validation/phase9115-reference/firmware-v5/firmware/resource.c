/* Resource table read by Linux remoteproc, not by the M4 boot stub.
 * No RSC_DEVMEM: internal L2 local alias is not an IPU-L3 IOMMU aperture.
 */
#include <stdint.h>
#include <stddef.h>
#define RSC_TRACE 2u
#define TRACE_LOADER_DA 0x20000800u
#define TRACE_LENGTH 512u
struct __attribute__((packed)) fw_rsc_trace {
    uint32_t type, da, len, reserved;
    char name[32];
};
struct __attribute__((packed)) table {
    uint32_t version, num, reserved[2], offset[1];
    struct fw_rsc_trace trace;
};
_Static_assert(offsetof(struct table, trace) == 20, "table offset must be 20");
_Static_assert(sizeof(struct fw_rsc_trace) == 48, "trace ABI mismatch");
_Static_assert(sizeof(struct table) == 68, "table ABI mismatch");
__attribute__((used, section(".resource_table"), aligned(4)))
const struct table resources = {
    .version = 1, .num = 1, .reserved = {0, 0}, .offset = {20},
    .trace = {RSC_TRACE, TRACE_LOADER_DA, TRACE_LENGTH, 0, "pyra_m4_v5_asm"}
};
/* Linux zero-initializes this NOLOAD ELF segment before the reset is released.
 * M4 sees these same bytes via initial AMMU local address 0x00000800.
 */
__attribute__((used, aligned(4), section(".tracebuf")))
volatile uint8_t trace_data[TRACE_LENGTH];
