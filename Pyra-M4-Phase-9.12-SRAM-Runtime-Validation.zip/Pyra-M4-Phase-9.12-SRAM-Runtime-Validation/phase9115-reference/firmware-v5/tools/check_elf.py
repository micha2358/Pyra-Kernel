#!/usr/bin/env python3
"""Fail-closed offline validator for one-page local-AMMU Cortex-M4 boot probe v5."""
from pathlib import Path
import struct
import sys

BASE = 0x20000000
END = BASE + 0x10000
RSC_ADDR = BASE + 0x1000


def unpack(data, fmt, off):
    return struct.unpack_from(fmt, data, off)


def require(condition, explanation):
    if not condition:
        raise ValueError(explanation)


def check(path):
    raw = Path(path).read_bytes()
    require(len(raw) >= 52 and raw[:7] == b'\x7fELF\x01\x01\x01', 'ELF32 little-endian expected')
    kind, machine = unpack(raw, '<HH', 16)
    require((kind, machine) == (2, 40), 'expected ET_EXEC ARM')
    entry, phoff, shoff = unpack(raw, '<III', 24)
    phsize, phcount = unpack(raw, '<HH', 42)
    shsize, shcount, stridx = unpack(raw, '<HHH', 46)
    require(phsize == 32 and shsize == 40 and phcount > 0 and 0 < shcount < 100 and stridx < shcount, 'unexpected ELF tables')
    require(phoff + phsize * phcount <= len(raw) and shoff + shsize * shcount <= len(raw), 'truncated ELF')
    ph = [unpack(raw, '<8I', phoff + i * phsize) for i in range(phcount)]
    loads = [x for x in ph if x[0] == 1]
    require(len(loads) == 5, f'expected five PT_LOAD segments, got {len(loads)}')
    intervals = []
    for typ, offset, va, pa, filesz, memsz, flags, align in loads:
        require(filesz <= memsz and memsz > 0 and offset + filesz <= len(raw), 'malformed LOAD')
        require(BASE <= pa < END and pa + memsz <= END, f'LOAD outside SRAM DA: {pa:#x}')
        if pa < RSC_ADDR:
            require(pa + memsz <= RSC_ADDR and va == pa - BASE, f'local alias / Linux L2 DA mismatch: {va:#x}/{pa:#x}')
        else:
            require(pa == RSC_ADDR and va == RSC_ADDR, 'unexpected segment beyond 4KiB')
        intervals.append((pa, pa + memsz))
    for i, (a, b) in enumerate(intervals):
        for c, d in intervals[i+1:]:
            require(b <= c or d <= a, 'overlapping SRAM LOAD segments')

    headers = [unpack(raw, '<10I', shoff+i*shsize) for i in range(shcount)]
    strtab = headers[stridx]
    require(strtab[4] + strtab[5] <= len(raw), 'truncated section names')
    names = raw[strtab[4]:strtab[4]+strtab[5]]
    sec = {}
    for sh in headers:
        start = sh[0]
        if start >= len(names):
            continue
        stop = names.find(b'\0', start)
        require(stop >= 0, 'malformed name string')
        sec[names[start:stop].decode('ascii')] = sh
    expected = {'.vectors', '.text', '.tracebuf', '.stack', '.resource_table'}
    require(expected.issubset(sec), 'missing expected sections')
    require(set(n for n, s in sec.items() if s[2] & 2) == expected, 'unexpected allocatable section')
    vec, code, trace, stack, res = (sec[name] for name in ('.vectors','.text','.tracebuf','.stack','.resource_table'))
    for name, (vma, size, stype) in {
        '.vectors':(0, 0x40, 1), '.tracebuf':(0x800, 0x200, 8),
        '.stack':(0xC00, 0x400, 8), '.resource_table':(RSC_ADDR, 0x44, 1),
    }.items():
        s = sec[name]
        require((s[3],s[5],s[1]) == (vma,size,stype), f'{name} placement/type/size invalid')
    require(code[3] == 0x40 and 0 < code[5] <= 0x7c0 and (code[2] & 4), 'bad .text')
    require(entry == 0x41, f'bad ELF entry {entry:#x}')
    require(vec[4] + vec[5] <= len(raw) and res[4]+res[5] <= len(raw), 'truncated section')
    vectors = unpack(raw, '<16I', vec[4])
    require(vectors[0] == 0x1000 and vectors[1] == 0x41, 'invalid MSP/reset vectors')
    require(vectors[3] & 1 and 0x40 <= (vectors[3] & ~1) < 0x800, 'invalid HardFault vector')
    require(all((x == 0 or x == vectors[3]) for x in vectors[2:] if x != vectors[1]), 'unexpected other vector entries')
    # Resource header has ONE offset (not two), and exactly ONE RSC_TRACE.
    ver, num, reserved0, reserved1, offset = unpack(raw,'<5I',res[4])
    require((ver,num,reserved0,reserved1,offset)==(1,1,0,0,20), 'invalid resource-table header or unexpected resources')
    rtype, da, size, rsv = unpack(raw,'<4I',res[4]+20)
    name = raw[res[4]+36:res[4]+68]
    require((rtype,da,size,rsv)==(2,BASE+0x800,512,0), 'unexpected resource type/trace address')
    require(name.startswith(b'pyra_m4_v5_asm\0'), 'resource name mismatch')
    # Inspect complete load images: page 0 must NOT include a Linux IOMMU mapping or external PA.
    for segment in loads:
        _, offset, va, pa, filesz, memsz, flags, _ = segment
        if pa == BASE:
            require((va,filesz,memsz)==(0,64,64), 'vector segment differs')
        if pa == BASE+0x40:
            require(va==0x40 and filesz==code[5] and filesz<0x200, 'code segment unexpectedly large')
        if pa == BASE+0x800:
            require(filesz==0 and memsz==512, 'trace must be NOLOAD / zero-on-load')
        if pa == BASE+0xc00:
            require(filesz==0 and memsz==1024, 'stack must be NOLOAD')
    print('PASS: ARM Thumb ELF, reset PC=0x41; no external LOAD segments')
    print('PASS: internal AMMU execution VMA=0x00000000; Linux loading DA=0x20000000')
    print('PASS: local trace VMA=0x00000800, Linux RSC_TRACE DA=0x20000800')
    print('PASS: exactly one resource (TRACE); zero DEVMEM / CARVEOUT / VDEV')
    print('PASS: code, trace, stack all in first 4KiB; no DDR mappings')
    print('NOTE: static checks do NOT prove that the M4 boot path works on hardware')


if __name__ == '__main__':
    if len(sys.argv) != 2:
        sys.exit('Usage: check_elf.py firmware.elf')
    try:
        check(sys.argv[1])
    except (ValueError,OSError,struct.error,UnicodeDecodeError) as exc:
        sys.exit('FAIL: ' + str(exc))
