#!/usr/bin/env python3
"""Check unique v5 M4-generated markers at exact offsets in raw remoteproc trace."""
from pathlib import Path
import sys

if len(sys.argv) != 2:
    sys.exit('Usage: check_trace.py /sys/kernel/debug/remoteproc/remoteprocN/trace0')
try:
    content = Path(sys.argv[1]).read_bytes()
except OSError as exc:
    sys.exit(f'NOT VERIFIED: failed to read trace0: {exc}')

print(f'Trace bytes read: {len(content)}')
print('Trace bytes [0:48]:',content[:48].hex(' '))
if content[24:29] == b'M5F!\n':
    print('FAIL: M4 fault-handler marker M5F! observed.')
    sys.exit(2)
for offset, expected in ((0,b'M5A1\n'),(5,b'M5B2\n'),(10,b'M5D3\n')):
    if content[offset:offset+len(expected)] != expected:
        print(f'NOT VERIFIED: missing marker {expected!r} at byte {offset}')
        sys.exit(2)
print('PASS: M4 wrote A1/B2/D3 into local SRAM; host can read them through Linux L2 alias.')
print('PASS: register-only check completed; C runtime, DDR, IPU external MMIO untested.')
