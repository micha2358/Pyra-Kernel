#!/bin/sh
# DragonBox Pyra Cortex-M4 local AMMU boot probe v5; one-shot, no auto-recovery.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
FW='pyra-m4-ammu-v5.elf'
ELF="$ROOT/build/$FW"
DST="/lib/firmware/$FW"
VER='5.6.19-pyradef-m4test'
DT='/proc/device-tree/ocp/ipu@55020000'

fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
need_root() { [ "$(id -u)" -eq 0 ] || fail 'Use sudo.'; }
find_ipu() {
    for r in /sys/class/remoteproc/remoteproc*; do
        [ -r "$r/name" ] || continue
        [ "$(cat "$r/name")" = '55020000.ipu' ] || continue
        printf '%s\n' "$r"
        return 0
    done
    return 1
}
check_env() {
    [ "$(uname -r)" = "$VER" ] || fail "Expected kernel $VER"
    [ -d "$DT" ] || fail 'Enabled m4ipu DT node not found; use the m4ipu boot entry.'
    tr '\000' '\n' < "$DT/compatible" | grep -Fxq 'ti,omap5-ipu' || fail 'IPU compatible mismatch'
    [ -r "$DT/status" ] || fail 'IPU DT status missing'
    [ "$(tr -d '\000' < "$DT/status")" = okay ] || fail 'IPU DT status is not okay'
    find_ipu >/dev/null || fail 'No 55020000.ipu remoteproc'
}
verify() {
    [ -s "$ELF" ] || fail "Firmware missing: $ELF"
    python3 "$ROOT/tools/check_elf.py" "$ELF"
}
install_fw() {
    need_root
    verify
    if [ -e "$DST" ]; then
        cmp -s "$ELF" "$DST" || fail "Firmware differs from $DST; refusing to overwrite"
        printf 'Firmware already installed and identical: %s\n' "$DST"
    else
        install -m 0644 "$ELF" "$DST"
        cmp -s "$ELF" "$DST" || fail 'Firmware copy mismatch'
        printf 'Installed firmware: %s\n' "$DST"
    fi
}
mount_debugfs() {
    if ! grep -Eq '^[^ ]+ /sys/kernel/debug debugfs ' /proc/mounts; then
        mount -t debugfs debugfs /sys/kernel/debug || fail 'Cannot mount debugfs'
    fi
}
debug_dir() {
    r=$(find_ipu) || return 1
    printf '/sys/kernel/debug/remoteproc/%s\n' "$(basename "$r")"
}
probe() {
    check_env
    r=$(find_ipu)
    printf 'Kernel: %s\nIPU: %s\nState: %s\nFirmware: %s\n' "$(uname -r)" "$(cat "$r/name")" "$(cat "$r/state")" "$(cat "$r/firmware")"
    echo 'NOTE: rproc registration does not demonstrate M4 execution.'
}
status() {
    r=$(find_ipu) || fail 'No IPU remoteproc'
    st=$(cat "$r/state")
    active=$(cat "$r/firmware")
    printf 'IPU: %s\nState: %s\nFirmware: %s\n' "$(cat "$r/name")" "$st" "$active"
    db=$(debug_dir)
    if [ -r "$db/recovery" ]; then
        printf 'Automatic recovery: %s\n' "$(cat "$db/recovery")"
    else
        echo 'Automatic recovery: unknown'
    fi
    if [ "$st" = crashed ]; then
        echo 'CRASHED: save dmesg, do not repeat the start without a controlled reboot.'
        return 2
    fi
    [ "$st" = running ] || { echo 'NOT VERIFIED: M4 not running'; return 2; }
    [ "$active" = "$FW" ] || { echo 'NOT VERIFIED: another firmware is active'; return 2; }
    [ -r "$db/trace0" ] || { echo 'NOT VERIFIED: debugfs trace0 absent'; return 2; }
    python3 "$ROOT/tools/check_trace.py" "$db/trace0"
}
start_once() {
    need_root
    [ "${2:-}" = OK ] || fail 'Explicit consent required: sudo ./run-pyra.sh --start OK'
    check_env
    r=$(find_ipu)
    [ "$(cat "$r/state")" = offline ] || fail 'IPU must be offline; stop v4 safely or reboot first'
    install_fw
    mount_debugfs
    db=$(debug_dir)
    [ -w "$db/recovery" ] || fail 'Recovery debugfs control unavailable; refusing start'
    printf 'disabled\n' > "$db/recovery"
    [ "$(cat "$db/recovery")" = disabled ] || fail 'Failed to disable recovery'
    echo 'Remoteproc recovery disabled (until changed or rebooted).'
    echo 'EXPERIMENTAL: no auto-restart; M4 may still cause an IOMMU fault or L3 bus error.'
    echo 'One attempt only. Stop/reboot if hardware behaves unexpectedly.'
    printf '%s\n' "$FW" > "$r/firmware"
    printf 'start\n' > "$r/state"
    sleep 1
    status || {
        echo 'UNVERIFIED: preserve dmesg, do not repeat starts blindly.' >&2
        exit 1
    }
}
stop_test() {
    need_root
    r=$(find_ipu) || fail 'IPU missing'
    [ "$(cat "$r/firmware")" = "$FW" ] || fail 'Refusing to stop a different firmware'
    [ "$(cat "$r/state")" = running ] || fail 'State is not running; do not auto-recover crashed firmware'
    printf 'stop\n' > "$r/state"
    printf 'State: %s\n' "$(cat "$r/state")"
    echo 'Recovery remains disabled; reboot resets test environment.'
}
case "${1:---probe}" in
    --probe) probe ;;
    --verify) verify ;;
    --install) install_fw ;;
    --status) status ;;
    --start) start_once "$@" ;;
    --stop) stop_test ;;
    *) echo 'Usage: ./run-pyra.sh [--probe|--verify|--install|--status|--start OK|--stop]' >&2; exit 2 ;;
esac
