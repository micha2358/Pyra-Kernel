# DragonBox Pyra — Cortex-M4 AMMU-local boot probe v5

**Phase 9.5, diagnostic firmware only.** This release does **not** alter Linux, the DTB, the PowerVR graphics libraries, MMC/F2FS, or the installed v3/v4 firmware files.

Target: OMAP5432 IPU on the DragonBox Pyra, Linux `5.6.19-pyradef-m4test` including the Phase-9.3 `omap_reset_deassert()` atomic-poll fix, and the enabled `m4ipu` Device Tree. The firmware boots through `/sys/class/remoteproc/remoteprocN` as `pyra-m4-ammu-v5.elf`.

## 1. Why a different experiment is needed

* **v3:** Without an explicit IOMMU mapping, the hardware logged `iommu fault: da 0x0`, and the Linux trace stayed empty.
* **v4:** A resource-table `RSC_DEVMEM` mapped IPU IOVA `0x0` to **physical** `0x55020000` (4 KiB). The IOMMU zero fault disappeared from the captured excerpt, **but** the L3 interconnect logged `MASTER DucatiM3 TARGET GPMC (Read Link): At Address: 0x55020000` and no valid trace marker appeared.
* **v5:** Remove `RSC_DEVMEM` entirely. Eliminate any C-generated reads, stack usage or implicit accesses to external memory. Test the **reset-time internal AMMU alias only**, with 140 bytes of Thumb instructions (0x8c) and an on-chip 512-byte trace buffer.

**What is corrected:** The earlier conflation of an M4-local **AMMU alias** and an external **IOMMU mapping**. A Linux physical address used to load the on-chip SRAM is not automatically a valid target for an M4-originated external L3 transaction. **What is not established yet:** That the installed Linux remoteproc reset sequence actually allows Cortex-M4 to execute through that local alias on this Pyra. v5 is a *discriminating diagnostic*, not a guaranteed functional firmware fix.

## 2. Three distinct address spaces

| Purpose | Address | Actor / path |
|---|---|---|
| M4 reset vectors + startup code | `0x00000000` .. `0x000000CB` | **M4-local**, reset-time AMMU alias. No deliberate L3 bus access |
| M4 early trace | `0x00000800` .. `0x000009FF` | M4-local alias; writes only using Thumb `strb` |
| Linux firmware-loader view of vectors | `0x20000000` | Linux remoteproc internal RAM **device address**, `p_paddr` |
| Linux view of early trace | `0x20000800` | `RSC_TRACE` device address, translated by OMAP rproc's L2 RAM `da_to_va()` |
| Linux CPU / physical L2 SRAM start | `0x55020000` | L2 SRAM physical address in OMAP5 DT; **not** mapped into M4-IOMMU in v5 |
| Resource table | `0x20001000` | Linux only; Cortex-M4 instructions never access it |

TI documentation describes a reset-time **4 KiB** AMMU alias `0x0` to physical L2 SRAM and a distinct IPU MMU for L3_MAIN transactions. The Linux OMAP remoteproc driver defines the local L2 RAM loader device address as `0x20000000`. A Linux `PT_LOAD.p_paddr` or `RSC_TRACE.da` is **not** necessarily the executable M4 address.

**Do not re-add v4's `RSC_DEVMEM(0, 0x55020000)`** without understanding the L3 error. In v5 the resource table contains **one resource only**, `RSC_TRACE`.

## 3. What the Cortex-M4 is instructed to do

The reset vector points to Thumb entry `0x00000041`, using the initial stack pointer `0x00001000`; **the program executes no push/pop, bl, C calls or stack accesses**. It uses only registers, an internal AMMU alias buffer at `0x800`, barriers and `wfi`.

Three markers are written, in sequence, to the 512-byte internal SRAM trace buffer:

```
M5A1
M5B2
M5D3
```

* `M5A1`: first writes after reset.
* `M5B2`: register-only XOR check (`0x1357 ^ 0x0101 == 0x1256`) succeeded.
* `M5D3`: final marker before the idle loop.

`M5F!` in byte range 24..28 marks a fall-through to the fault handler, **if the CPU can still execute the handler and access local SRAM**. A hardware bus error can prevent even that handler from running; lack of a fault marker does not imply no fault.

The markers must be checked at **exact byte offsets** (0, 5, 10) rather than searching the trace stream. This avoids mistaking stale or partial bytes for a completed test. The ELF declares `.tracebuf` `NOBITS/NOLOAD` and Linux remoteproc's ELF loader is expected to initialize that area when loading it.

## 4. First run on the DragonBox Pyra

**First, end v4 (if it is still `running`) using v4's own script, or reboot into `m4ipu` so remoteproc is `offline`.** Do not forcibly start v5 over v4, and do not attempt a new start while remoteproc is in `crashed` state.

```sh
unzip Pyra-OMAP5-M4-AMMU-Boot-Probe-v5.zip
cd Pyra-OMAP5-M4-AMMU-Boot-Probe-v5

./run-pyra.sh --verify
./run-pyra.sh --probe
cat /sys/class/remoteproc/remoteproc0/state
```

The reported state **must** be `offline`. Then perform **one controlled experiment**:

```sh
sudo ./run-pyra.sh --install
sudo ./run-pyra.sh --start OK 2>&1 | tee pyra-m4-v5-first-run.log
```

The script refuses to start if the IPU is not `offline`. It requires a writable debugfs `recovery` knob, sets it to `disabled` **before** the reset is released, and never automatically retries. A `running` state alone is not accepted as success.

Collect all diagnostics:

```sh
sudo ./run-pyra.sh --status 2>&1 | tee pyra-m4-v5-status.log
sudo dmesg -T | grep -Ei -C 4 'remoteproc|omap-rproc|iommu|55020000|Ducati|L3 Standard Error|GPMC|crash|fault|scheduling while atomic' \
  | tee pyra-m4-v5-dmesg.log
```

**Pass requires** all three unique M5 markers in the expected offsets, showing that the M4 reached its final WFI loop. A partial marker/fault is diagnostic information, not a pass. `running` with no marker is **NOT VERIFIED**.

After collecting logs, if state is `running` and v5 is still active:

```sh
sudo ./run-pyra.sh --stop
```

If the device is `crashed`, do **not** repeat `start`; save the logs and make a controlled reboot instead. A new L3/GPMC error means the problem persists upstream of the now-minimal code or in the local alias/boot path. This can hang the handheld; use the experimental SD setup and preserve the original boot entry.

## 5. Build / verification

A prebuilt ELF is included; cross-compilation on the Pyra itself is **not** required.

```sh
make USE_CLANG=1 verify    # Clang + LLD
# or
make verify                # validates prebuilt ELF without rebuilding
```

If `arm-none-eabi-gcc` is installed, `make clean && make` also works. The static validator checks all five PT_LOAD segments, the 4 KiB reset alias, the Thumb entry and initial MSP, the one-entry resource table, the trace and stack positions, and the absence of any external-memory load segments or IOMMU `RSC_DEVMEM` resources. The actual startup assembler was also reviewed using `llvm-objdump -d` for absolute accesses (only stores into M4 local `0x800`).

## 6. Interpretation / next branch

| Hardware observation | Implication | Next engineering action |
|---|---|---|
| `M5A1`, `M5B2`, `M5D3`, no kernel faults | Minimal local-M4 path works | Add controlled C/stack experiment; do not assume external IOMMU is fixed |
| `M5A1` but no `M5D3` | M4 began running | Investigate local SRAM visibility, exceptions or instruction errors |
| `iommu fault da 0x0` before marker | Zero access still traverses IOMMU or reset startup fails | Inspect AMMU/reset defaults, iommu routing, IPU reset ordering in kernel |
| `L3 ... at 0x55020000` persists | External bus routing remains suspect | Recheck peripheral path/AMMU and ensure no other firmware/agent touched IPU |
| `running`, trace empty, no faults | No proof of CPU execution | Inspect trace loader mapping and reset release; do not assume success |

### References

1. TI, *Running TI-RTOS on the ARM Cortex-M4 Processor*, slides 6, 10, 11: reset-time L2 SRAM AMMU alias, separate IPU MMU for accesses to L3_MAIN. https://software-dl.ti.com/public/hpmp/software/running_rtos_on_cortex_m4/presentation_content/external_files/Running_RTOS_on_Cortex_M4_SLIDES.pdf
2. Linux OMAP remoteproc, `drivers/remoteproc/omap_remoteproc.c`: `ipu_mems` with `l2ram` `dev_addr = 0x20000000`, and internal RAM `.da_to_va` loader mapping. https://git.ti.com/cgit/ti-linux-kernel/ti-linux-kernel-next/tree/drivers/remoteproc/omap_remoteproc.c?id=ec115c7d941ddf771846a52184c6c673925a6113
3. OMAP5 Device Tree, `ipu@55020000` `reg = <0x55020000 0x10000>` and `reg-names = "l2ram"`. https://code.googlesource.com/linux/torvalds/linux/+/3c8f504b3a486e4e984ac8dc619eba3afa24cec4/arch/arm/boot/dts/omap5.dtsi

Hardware behavior is inferred from the v3/v4 logs previously supplied by the user. The v5 firmware has been **compiled and statically checked but not yet executed** on the actual hardware.
