#!/bin/sh
# Read-only evidence collection; no firmware start, stop, or reset action.
set -eu
[ "$(id -u)" -eq 0 ] || { echo 'Run with sudo' >&2; exit 1; }
OUT=${1:-"$HOME/pyra-phase912-evidence-$(date +%Y%m%d-%H%M%S)"}
[ ! -e "$OUT" ] || { echo "Refusing to overwrite $OUT" >&2; exit 1; }
umask 077
mkdir -p "$OUT"
dmesg > "$OUT/dmesg.log"
cat /proc/cmdline > "$OUT/cmdline.txt"
uname -a > "$OUT/uname.txt"
for f in /sys/module/omap_remoteproc/parameters/pyra*; do
  [ -r "$f" ] || continue
  printf '%s = %s\n' "$(basename "$f")" "$(cat "$f")" >> "$OUT/parameters.txt"
done
for r in /sys/class/remoteproc/remoteproc*; do
  [ -r "$r/name" ] || continue
  [ "$(cat "$r/name")" = '55020000.ipu' ] || continue
  cat "$r/name" > "$OUT/remoteproc-name.txt"
  cat "$r/state" > "$OUT/remoteproc-state.txt"
  cat "$r/firmware" > "$OUT/remoteproc-firmware.txt"
  debug="/sys/kernel/debug/remoteproc/$(basename "$r")"
  if [ -r "$debug/recovery" ]; then cat "$debug/recovery" > "$OUT/recovery.txt"; fi
  if [ -r "$debug/trace0" ]; then
    for i in 1 2 3 4; do
      cat "$debug/trace0" > "$OUT/trace-$i.txt"
      [ "$i" = 4 ] || sleep 1
    done
  fi
done
if [ -f /lib/firmware/pyra-m4-sram-v12.elf ]; then
  sha256sum /lib/firmware/pyra-m4-sram-v12.elf > "$OUT/firmware-sha256.txt"
fi
echo "Evidence stored: $OUT"
echo 'No changes were made to the running remoteproc.'
