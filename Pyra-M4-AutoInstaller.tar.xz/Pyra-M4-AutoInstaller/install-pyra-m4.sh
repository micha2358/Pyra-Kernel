#!/bin/sh
# DragonBox Pyra M4: additive, rollback-aware installer.
export PATH="/usr/local/sbin:/usr/sbin:/sbin:$PATH"
set -eu
cd -- "$(dirname -- "$(readlink -f -- "$0")")"
exec python3 ./installer.py "$@"
