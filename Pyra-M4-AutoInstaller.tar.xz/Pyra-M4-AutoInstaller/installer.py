#!/usr/bin/env python3
"""Fail-closed, additive DragonBox Pyra kernel installer (Python 3.9+)."""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

KREL = '5.6.19-pyradef-m4test-m4clean'
DTB_SOURCE = 'omap5-letux-cortex15-v5.3+pyra-v5.3-m4test.dtb'
DTB_INSTALLED = 'omap5-letux-cortex15-v5.3+pyra-v5.3-m4clean.dtb'
ENTRY_LABEL = 'pyra-m4clean'
EXPERIMENTAL = ('omap_remoteproc.pyra98_diag', 'omap_remoteproc.pyra10_ammu_probe',
                'omap_remoteproc.pyra11_stage0_only', 'omap_remoteproc.pyra11_ammu_repair',
                'omap_remoteproc.pyra11_boot_after_repair',
                'omap_remoteproc.pyra13_consistency_only',
                'omap_remoteproc.pyra15_boot_once', 'omap_iommu.pyra98_debug')

class InstallError(Exception):
    pass

def require(cond, msg):
    if not cond:
        raise InstallError(msg)

def checksum(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):
            h.update(block)
    return h.hexdigest()

def verify_payload(base):
    manifest=base/'SHA256SUMS'
    require(manifest.is_file(),'SHA256SUMS missing')
    count=0
    for line in manifest.read_text().splitlines():
        require(re.fullmatch(r'[0-9a-f]{64}  payload/[A-Za-z0-9_.+/-]+',line) is not None,
                'Invalid checksum manifest line')
        sha, rel=line.split('  ',1)
        path=base/rel
        require(path.is_file() and not path.is_symlink(),f'Missing/unsafe payload file: {rel}')
        require(checksum(path)==sha,f'SHA256 mismatch: {rel}')
        count+=1
    require(count>=900,f'Unexpectedly incomplete payload ({count} files)')
    boot=base/'payload/boot'
    modules=base/'payload/lib/modules'/KREL
    for f in (boot/f'vmlinuz-{KREL}',boot/f'config-{KREL}',boot/f'System.map-{KREL}',boot/DTB_SOURCE):
        require(f.is_file(),f'Missing: {f}')
    require((modules/'modules.dep').is_file(),'Missing module dependency index')
    require((modules/'kernel/drivers/gpu/drm/pvrsgx/1.14.3699939/eurasia_km/pvrsrvkm_omap5_sgx544_116.ko').is_file(),
            'Native OMAP5 PowerVR module missing')
    cfg=(boot/f'config-{KREL}').read_text()
    for opt in ('CONFIG_OMAP_REMOTEPROC=y','CONFIG_MAILBOX=y','CONFIG_OMAP2PLUS_MBOX=y',
                'CONFIG_OMAP_IOMMU=y','CONFIG_PVRSGX_1_14_3699939=y'):
        require(opt in cfg,f'Kernel config missing {opt}')
    dtb=(boot/DTB_SOURCE).read_bytes()
    require(dtb[:4]==b'\xd0\x0d\xfe\xed','Invalid flattened device-tree magic')
    require(b'goldelico,lc15-v5.3' in dtb and b'ti,omap5' in dtb, 'Staged DTB is not for Pyra V5.3')
    pvr=(modules/'kernel/drivers/gpu/drm/pvrsgx/1.14.3699939/eurasia_km/pvrsrvkm_omap5_sgx544_116.ko').read_bytes()
    require(pvr[:4]==b'\x7fELF' and pvr[18:20]==b'\x28\x00', 'PowerVR kernel module is not ARM ELF')
    require(('vermagic='+KREL+' ').encode() in pvr, 'PowerVR module vermagic does not match kernel release')
    require((boot/f'vmlinuz-{KREL}').stat().st_size>1000000,'Kernel image suspiciously small')
    return count

def read_board_compatible(root):
    p=root/'proc/device-tree/compatible'
    if not p.exists():p=root/'sys/firmware/devicetree/base/compatible'
    require(p.is_file(),'Cannot read board compatible string; aborting')
    c=p.read_bytes().lower()
    require(b'goldelico,lc15-v5.3' in c and b'ti,omap5' in c,
            f'Hardware is not recognized as DragonBox Pyra / OMAP5: {c[:150]!r}')
    return c

def parse_extlinux(data):
    lines=data.splitlines(keepends=True)
    entries=[];current=None;default=None
    for line in lines:
        m=re.match(r'^\s*DEFAULT\s+(\S+)',line,re.I)
        if m:default=m.group(1)
        m=re.match(r'^\s*LABEL\s+(\S+)',line,re.I)
        if m:
            if current:entries.append(current)
            current={'label':m.group(1),'lines':[line]}
        elif current:
            current['lines'].append(line)
    if current:entries.append(current)
    return entries,default

def field(entry,key):
    vals=[]
    for line in entry['lines']:
        m=re.match(r'^\s*'+re.escape(key)+r'\s+(.*?)\s*$',line,re.I)
        if m:vals.append(m.group(1))
    return vals[-1] if vals else None

def included_config_names(text):
    """Accept simple, local extlinux INCLUDE directives only."""
    found=[]
    for line in text.splitlines():
        m=re.match(r'^\s*(?:INCLUDE|SOURCE)\s+(\S+)\s*(?:#.*)?$',line,re.I)
        if not m:continue
        name=m.group(1)
        require(re.fullmatch(r'[A-Za-z0-9_.-]+\.cfg',name) is not None,
                f'Unsupported extlinux include path: {name!r}')
        require(name not in found,f'Duplicate extlinux include: {name}')
        found.append(name)
    return found

def choose_config(root,explicit):
    """Return (writable config, all visible entries, effective DEFAULT).

    On Pyra, extlinux.conf is generated and includes linux.cfg + user.cfg.
    Only user.cfg may be modified. A generated extlinux.conf is never edited.
    """
    base=root/'boot/extlinux'
    conf=base/'extlinux.conf'
    user=base/'user.cfg'
    if explicit:
        target=Path(explicit)
        require(target.is_absolute(),'--boot-config must be absolute')
        if root!=Path('/'):
            target=root/target.relative_to('/')
        require(target.is_file(),f'Boot configuration missing: {target}')
        require(not target.is_symlink(),'Refusing symlinked boot config')
        # Even an explicit user.cfg must be paired with the included linux.cfg
        # when the generated extlinux.conf uses INCLUDE.
        if target not in (conf,user):
            if conf.is_file() and included_config_names(conf.read_text(errors='replace')):
                raise InstallError('Generated extlinux.conf uses INCLUDE; only its included user.cfg is writable')
            data=target.read_text(errors='replace')
            entries,default=parse_extlinux(data)
            require(entries,f'No entries in explicitly selected config: {target}')
            return target,entries,default
    else:
        target=None
    if conf.is_file():
        require(not conf.is_symlink(),'Refusing symlinked extlinux.conf')
        content=conf.read_text(errors='replace')
        main_entries,default=parse_extlinux(content)
        includes=included_config_names(content)
        if includes:
            entries=list(main_entries)
            for name in includes:
                inc=base/name
                require(inc.is_file() and not inc.is_symlink(),
                        f'Included extlinux config missing/unsafe: {inc}')
                inc_entries,_=parse_extlinux(inc.read_text(errors='replace'))
                entries.extend(inc_entries)
            labels=[e['label'] for e in entries]
            require(len(labels)==len(set(labels)),
                    'Duplicate LABEL across included extlinux configurations')
            if 'user.cfg' in includes and (target is None or target==user):
                require(user.is_file() and not user.is_symlink(),
                        'Included user.cfg missing/unsafe')
                require(entries,'No boot entries in extlinux.conf or its included files')
                return user,entries,default
            if target==conf:
                raise InstallError('extlinux.conf is generated; use its included user.cfg, not --boot-config extlinux.conf')
            raise InstallError('Extlinux uses INCLUDE but no writable user.cfg is included; refusing to edit generated files')
        if target==user:
            raise InstallError('user.cfg is not included by extlinux.conf; refusing to write an inactive boot entry')
        if main_entries:
            return conf,main_entries,default
    if user.is_file() and not user.is_symlink():
        entries,default=parse_extlinux(user.read_text(errors='replace'))
        if entries:return user,entries,default
    raise InstallError('No supported extlinux boot entries found. No boot configuration changed.')

def choose_entry(entries,default,requested):
    if requested:
        matching=[e for e in entries if e['label']==requested]
        require(len(matching)==1,f'--clone-label {requested!r} not found uniquely')
        chosen=matching[0]
    else:
        eligible=[e for e in entries if (field(e,'LINUX') or field(e,'KERNEL')) and
                  (field(e,'FDT') or field(e,'DEVICETREE') or field(e,'FDTDIR'))]
        if default:
            matching=[e for e in eligible if e['label']==default]
            chosen=matching[0] if len(matching)==1 else None
        else:chosen=None
        if chosen is None and len(eligible)==1:chosen=eligible[0]
        require(chosen is not None,'Ambiguous boot entries. Specify --clone-label LABEL explicitly')
    require(field(chosen,'LINUX') or field(chosen,'KERNEL'),'Selected entry lacks kernel path')
    require(field(chosen,'FDT') or field(chosen,'DEVICETREE') or field(chosen,'FDTDIR'),
            'Selected entry lacks FDT/DEVICETREE/FDTDIR')
    require(field(chosen,'APPEND') is not None,'Selected entry lacks APPEND; cannot safely preserve root/console arguments')
    return chosen

def existing_loader_path(root,loader_path):
    require(loader_path.startswith('/') and not any(x in ('.','..') for x in loader_path.split('/')),
            f'Unsupported bootloader path: {loader_path!r}')
    rel=loader_path.lstrip('/')
    candidates=[root/'boot'/rel,root/rel]
    found=[]
    for p in candidates:
        if p.is_file() and p not in found:found.append(p)
    require(found,f'Cannot find referenced boot file {loader_path!r} under {root}/boot or {root}')
    if len(found)>1 and found[0].resolve()!=found[1].resolve():
        raise InstallError(f'Ambiguous physical boot path for {loader_path!r}: {found}')
    result=found[0]
    # Only write to boot partition, not arbitrary root directories.
    require(result.resolve().is_relative_to((root/'boot').resolve()),
            f'Boot file {result} is outside /boot; unsupported layout')
    return result

def existing_loader_dir(root,loader_dir):
    require(loader_dir.startswith('/') and not any(x in ('.','..') for x in loader_dir.split('/')),
            f'Unsupported FDTDIR path: {loader_dir!r}')
    rel=loader_dir.lstrip('/')
    candidates=[root/'boot'/rel,root/rel]
    found=[p for p in candidates if p.is_dir()]
    require(found,f'Cannot find referenced FDTDIR {loader_dir!r}')
    if len(found)>1 and found[0].resolve()!=found[1].resolve():
        raise InstallError(f'Ambiguous physical FDTDIR: {found}')
    require(found[0].resolve().is_relative_to((root/'boot').resolve()),
            'FDTDIR is outside /boot; unsupported')
    return found[0]

def new_loader_path(old,new_name):
    return str(Path(old).parent/new_name)

def replace_or_add(line,key,value):
    m=re.match(r'^(\s*)'+re.escape(key)+r'(\s+)',line,re.I)
    if not m:return None
    return m.group(1)+key+m.group(2)+value+'\n'

def make_entry(entry):
    kkey='LINUX' if field(entry,'LINUX') else 'KERNEL'
    fkey='FDT' if field(entry,'FDT') else ('DEVICETREE' if field(entry,'DEVICETREE') else 'FDTDIR')
    old_kernel=field(entry,kkey)
    old_fdt=field(entry,fkey)
    old_initrd=field(entry,'INITRD')
    require(old_kernel and old_fdt,'Missing kernel/FDT')
    require(not old_initrd or (len(old_initrd.split())==1 and ',' not in old_initrd),
            'Multiple INITRD images not supported')
    rawargs=field(entry,'APPEND')
    args=rawargs.split()
    require(any(x.startswith('root=') for x in args) or any('bootargs' in x for x in args),
            'APPEND does not contain root= or bootargs variable; refuse to guess root device')
    args=[x for x in args if x.split('=',1)[0] not in EXPERIMENTAL and
          x.split('=',1)[0]!='omap_remoteproc.pyra_cpu0_only']
    args=['omap_prm.pyra_ipu_prm_assert_quirk=0' if x.startswith('omap_prm.pyra_ipu_prm_assert_quirk=') else x for x in args]
    args.append('omap_remoteproc.pyra_cpu0_only=1')
    out=[]
    for line in entry['lines']:
        if re.match(r'^\s*LABEL\s+',line,re.I):
            out.append(replace_or_add(line,'LABEL',ENTRY_LABEL));continue
        if re.match(r'^\s*(?:MENU\s+DEFAULT|DEFAULT)\b',line,re.I):continue
        if re.match(r'^\s*MENU\s+LABEL\b',line,re.I):
            out.append(re.sub(r'^(\s*MENU\s+LABEL\s+).*$',r'\1Pyra M4 Letux Cleanup (test)',line.rstrip('\n'),flags=re.I)+'\n');continue
        if re.match(r'^\s*'+kkey+r'\s+',line,re.I):
            out.append(replace_or_add(line,kkey,new_loader_path(old_kernel,f'vmlinuz-{KREL}')));continue
        if re.match(r'^\s*'+fkey+r'\s+',line,re.I):
            # FDTDIR is a directory from which U-Boot selects a board-specific
            # DTB. For the M4 test, use the verified explicit Pyra DTB instead.
            dtb_loader=(str(Path(old_fdt)/DTB_INSTALLED) if fkey=='FDTDIR'
                        else new_loader_path(old_fdt,DTB_INSTALLED))
            if fkey=='FDTDIR':
                out.append(re.match(r'^(\s*)',line).group(1)+'FDT '+dtb_loader+'\n')
            else:
                out.append(replace_or_add(line,fkey,dtb_loader))
            continue
        if re.match(r'^\s*INITRD\s+',line,re.I):
            out.append(replace_or_add(line,'INITRD',new_loader_path(old_initrd,f'initrd.img-{KREL}')));continue
        if re.match(r'^\s*APPEND\s+',line,re.I):
            out.append(replace_or_add(line,'APPEND',' '.join(args)));continue
        out.append(line)
    return ''.join(out),old_kernel,old_fdt,old_initrd,fkey

def run(args):
    p=argparse.ArgumentParser(description='Install staged Pyra M4 kernel, DTB and modules without replacing default boot entry')
    p.add_argument('--dry-run',action='store_true',help='Verify payload and show installation plan; do not write')
    p.add_argument('--yes',action='store_true',help='Confirm installation non-interactively')
    p.add_argument('--boot-config',help='Absolute path to active extlinux config')
    p.add_argument('--clone-label',help='Boot entry to clone (default: DEFAULT or sole eligible entry)')
    p.add_argument('--test-root',help=argparse.SUPPRESS)
    a=p.parse_args(args)
    base=Path(__file__).resolve().parent
    root=Path(a.test_root).resolve() if a.test_root else Path('/')
    testmode=a.test_root is not None
    if testmode and os.environ.get('PYRA_INSTALLER_TEST_MODE')!='1':
        raise InstallError('--test-root is reserved for the bundled offline test suite')
    print('[1/6] Verifying SHA-256 manifest, kernel config, DTB and PowerVR module ...',flush=True)
    n=verify_payload(base)
    print(f'PASS: {n} staged files verified')
    if not testmode:
        require(os.uname().machine.startswith('arm'),'Installer must run on ARM Pyra, not x86_64')
    read_board_compatible(root)
    config,entries,default=choose_config(root,a.boot_config)
    require(not config.is_symlink(),'Refusing symlinked boot config')
    content=config.read_text()
    require(not any(e['label']==ENTRY_LABEL for e in entries),
            f'Boot label {ENTRY_LABEL!r} already exists; refusing to modify')
    chosen=choose_entry(entries,default,a.clone_label)
    new_stanza,kernel_loader,fdt_loader,initrd_loader,fdt_key=make_entry(chosen)
    kernel_old=existing_loader_path(root,kernel_loader)
    dtb_parent=(existing_loader_dir(root,fdt_loader) if fdt_key=='FDTDIR'
                else existing_loader_path(root,fdt_loader).parent)
    kernel_target=kernel_old.parent/f'vmlinuz-{KREL}'
    dtb_target=dtb_parent/DTB_INSTALLED
    map_target=kernel_old.parent/f'System.map-{KREL}'
    cfg_target=kernel_old.parent/f'config-{KREL}'
    initrd_target=existing_loader_path(root,initrd_loader).parent/f'initrd.img-{KREL}' if initrd_loader else None
    modules_target=root/'lib/modules'/KREL
    alltargets=[kernel_target,dtb_target,map_target,cfg_target,modules_target]
    if initrd_target:alltargets.append(initrd_target)
    for f in alltargets:
        require(not f.exists() and not f.is_symlink(),f'Destination already exists: {f}; no overwrite allowed')
    require((root/'lib/modules').is_dir(),'Missing /lib/modules directory')
    if initrd_target and not testmode:
        require(shutil.which('update-initramfs') is not None,'Existing boot entry uses INITRD but update-initramfs is unavailable')
    if not testmode:
        require(shutil.which('depmod') is not None,'depmod is missing')
    require(default!=ENTRY_LABEL,'New entry must not be default')
    print('[2/6] Installation plan:')
    print(f'  Board: DragonBox Pyra / OMAP5\n  Writable boot config: {config}\n  Clone: {chosen["label"]}\n  New entry: {ENTRY_LABEL} (DEFAULT {default or "not specified"} unchanged)')
    print(f'  Kernel: {kernel_target}\n  DTB: {dtb_target}\n  Modules: {modules_target} (946 .ko)')
    if initrd_target:print(f'  Initramfs: {initrd_target} (generated locally)')
    print('  PowerVR: 1.14.3699939 OMAP5 kernel module included; userspace not modified')
    print('  Existing kernel, DTB, modules and boot menu entries will not be overwritten.')
    if a.dry_run:
        print('PASS: dry-run complete. No files changed.')
        return 0
    require(os.geteuid()==0 or testmode,'Run with sudo (or use --dry-run)')
    if not a.yes:
        require(sys.stdin.isatty(),'Interactive confirmation required; pass --yes if you reviewed --dry-run')
        answer=input('Type INSTALL to proceed: ')
        require(answer=='INSTALL','Installation cancelled')
    created=[];backup=None;config_written=False
    try:
        print('[3/6] Installing modules into new kernel release directory ...',flush=True)
        # copytree creates destination; rollback removes it on error.
        created.append(modules_target)
        shutil.copytree(base/'payload/lib/modules'/KREL,modules_target,symlinks=False)
        if testmode:
            # Offline fixture: no host depmod on fake ARM filesystem.
            pass
        else:
            subprocess.run(['depmod','-a',KREL],check=True)
        print('[4/6] Installing kernel, DTB, System.map and config ...',flush=True)
        for src,dest in ((base/'payload/boot'/f'vmlinuz-{KREL}',kernel_target),
                         (base/'payload/boot'/DTB_SOURCE,dtb_target),
                         (base/'payload/boot'/f'System.map-{KREL}',map_target),
                         (base/'payload/boot'/f'config-{KREL}',cfg_target)):
            created.append(dest)
            # Exclusive creation: never replace existing files.
            with src.open('rb') as fsrc, dest.open('xb') as fdst:
                shutil.copyfileobj(fsrc,fdst,1024*1024)
                fdst.flush();os.fsync(fdst.fileno())
            dest.chmod(0o644)
            require(checksum(src)==checksum(dest),f'Installed file checksum differs: {dest}')
        if initrd_target:
            print('[5/6] Creating kernel-specific initramfs ...',flush=True)
            created.append(initrd_target)
            if testmode:
                initrd_target.write_bytes(b'TEST INITRAMFS')
            else:
                subprocess.run(['update-initramfs','-c','-k',KREL,'-b',str(initrd_target.parent)],check=True)
            require(initrd_target.is_file() and initrd_target.stat().st_size>0,'Initramfs was not generated')
        print('[6/6] Backing up and atomically extending extlinux configuration ...',flush=True)
        backup=config.with_name(config.name+'.pre-'+ENTRY_LABEL+'-'+dt.datetime.now().strftime('%Y%m%d-%H%M%S'))
        require(not backup.exists(),'Backup filename already exists')
        shutil.copy2(config,backup)
        new_content=content.rstrip('\n')+'\n\n# Pyra M4 Letux cleanup: additive boot entry; default unchanged\n'+new_stanza.rstrip('\n')+'\n'
        fd,temp=tempfile.mkstemp(prefix='.pyra-m4-extlinux-',dir=str(config.parent))
        try:
            with os.fdopen(fd,'w') as f:
                f.write(new_content);f.flush();os.fsync(f.fileno())
            os.chmod(temp,config.stat().st_mode & 0o777)
            require(config.read_text()==content,'Boot config changed concurrently; aborting')
            os.replace(temp,config)
            config_written=True
        finally:
            if os.path.exists(temp):os.unlink(temp)
        if not testmode:subprocess.run(['sync'],check=True)
        print('\nPASS: Kernel, M4 DTB and modules installed; new boot entry '+ENTRY_LABEL)
        print('DEFAULT boot entry unchanged. Select '+ENTRY_LABEL+' manually in the boot menu.')
        print('Backup: '+str(backup))
        print('After reboot: uname -r; check /sys/class/remoteproc/remoteproc*/state and dmesg.')
        return 0
    except Exception:
        if config_written and backup and backup.is_file():
            shutil.copy2(backup,config)
        for path in reversed(created):
            if path.is_dir() and not path.is_symlink():shutil.rmtree(path)
            elif path.exists() or path.is_symlink():path.unlink()
        print('ERROR: installation failed; new files rolled back; existing boot entries preserved.',file=sys.stderr)
        raise

def main():
    try:return run(sys.argv[1:])
    except (InstallError, OSError, subprocess.CalledProcessError) as e:
        print('ERROR:',e,file=sys.stderr)
        return 1

if __name__=='__main__':sys.exit(main())
