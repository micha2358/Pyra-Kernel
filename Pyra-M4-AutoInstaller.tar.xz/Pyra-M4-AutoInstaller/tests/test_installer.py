import importlib.util
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('installer',ROOT/'installer.py')
i=importlib.util.module_from_spec(spec)
spec.loader.exec_module(i)

class InstallerTests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory()
        self.root=Path(self.t.name)
        for d in ('boot/extlinux','lib/modules','proc/device-tree'):
            (self.root/d).mkdir(parents=True,exist_ok=True)
        (self.root/'proc/device-tree/compatible').write_bytes(b'goldelico,lc15-v5.3\0goldelico,lc15\0ti,omap5\0')
        (self.root/'boot/vmlinuz-stock').write_bytes(b'STOCK KERNEL')
        (self.root/'boot/stock-pyra.dtb').write_bytes(b'STOCK DTB')
        self.cfg=self.root/'boot/extlinux/extlinux.conf'
        self.cfg.write_text('DEFAULT stock\nTIMEOUT 60\nLABEL stock\n MENU LABEL Debian Pyra original\n LINUX /vmlinuz-stock\n FDT /stock-pyra.dtb\n APPEND root=PARTUUID=1234 console=ttyO2,1500000n8 omap_remoteproc.pyra15_boot_once=1\n')
        self.orig=self.cfg.read_text()
    def tearDown(self):self.t.cleanup()
    def test_parse_and_new_entry(self):
        entries,default=i.parse_extlinux(self.orig)
        self.assertEqual(default,'stock')
        entry,_,_,_,_=i.make_entry(entries[0])
        self.assertIn('LABEL pyra-m4clean',entry)
        self.assertIn('root=PARTUUID=1234',entry)
        self.assertIn('omap_remoteproc.pyra_cpu0_only=1',entry)
        self.assertNotIn('pyra15_boot_once',entry)
        self.assertNotIn('MENU DEFAULT',entry)
    def test_payload(self):
        self.assertEqual(i.verify_payload(ROOT),964)
    def test_dry_run(self):
        with patch.dict(os.environ,{'PYRA_INSTALLER_TEST_MODE':'1'}):
            self.assertEqual(i.run(['--test-root',str(self.root),'--dry-run']),0)
        self.assertEqual(self.cfg.read_text(),self.orig)
        self.assertFalse((self.root/'lib/modules'/i.KREL).exists())
    def test_install_and_no_overwrite(self):
        with patch.dict(os.environ,{'PYRA_INSTALLER_TEST_MODE':'1'}):
            self.assertEqual(i.run(['--test-root',str(self.root),'--yes']),0)
            self.assertTrue((self.root/'lib/modules'/i.KREL/'kernel/drivers/gpu/drm/pvrsgx/1.14.3699939/eurasia_km/pvrsrvkm_omap5_sgx544_116.ko').exists())
            self.assertEqual((self.root/'boot/vmlinuz-stock').read_bytes(),b'STOCK KERNEL')
            self.assertIn('DEFAULT stock',self.cfg.read_text())
            self.assertIn('LABEL pyra-m4clean',self.cfg.read_text())
            with self.assertRaises(i.InstallError):i.run(['--test-root',str(self.root),'--yes'])
    def test_initramfs_fixture(self):
        (self.root/'boot/initrd-stock').write_bytes(b'OLD INITRD')
        self.cfg.write_text(self.orig+'')
        self.cfg.write_text(self.cfg.read_text().replace(' FDT /stock-pyra.dtb\n',' FDT /stock-pyra.dtb\n INITRD /initrd-stock\n'))
        with patch.dict(os.environ,{'PYRA_INSTALLER_TEST_MODE':'1'}):
            self.assertEqual(i.run(['--test-root',str(self.root),'--yes']),0)
        self.assertTrue((self.root/'boot'/f'initrd.img-{i.KREL}').is_file())
        self.assertIn('INITRD /initrd.img-'+i.KREL,self.cfg.read_text())
        self.assertEqual((self.root/'boot/initrd-stock').read_bytes(),b'OLD INITRD')
    def test_ambiguous_clone(self):
        self.cfg.write_text(self.orig.replace('DEFAULT stock\n','')+'LABEL backup\n LINUX /vmlinuz-stock\n FDT /stock-pyra.dtb\n APPEND root=PARTUUID=1234\n')
        with patch.dict(os.environ,{'PYRA_INSTALLER_TEST_MODE':'1'}):
            with self.assertRaises(i.InstallError):i.run(['--test-root',str(self.root),'--dry-run'])
    def configure_real_pyra_includes(self, fdtdir=False):
        self.cfg.write_text('## automatically generated; do not edit\nmenu title Extlinux Boot Menu\ntimeout 30\ndefault l0\n\ninclude linux.cfg\ninclude user.cfg\n')
        (self.root/'boot/extlinux/user.cfg').write_text('')
        fdtline=' FDTDIR /dtbs\n' if fdtdir else ' FDT /stock-pyra.dtb\n'
        if fdtdir:
            (self.root/'boot/dtbs').mkdir(exist_ok=True)
        (self.root/'boot/extlinux/linux.cfg').write_text(
            'LABEL l0\n MENU LABEL Debian Linux stock\n LINUX /vmlinuz-stock\n'+fdtline+
            ' APPEND root=PARTUUID=1234 console=ttyO2,1500000n8\n'
            'LABEL l1\n MENU LABEL Debian rescue\n LINUX /vmlinuz-stock\n'+fdtline+
            ' APPEND root=PARTUUID=1234 console=tty0\n')

    def test_pyra_split_config_dry_run(self):
        self.configure_real_pyra_includes()
        conf=self.cfg.read_bytes()
        linux=(self.root/'boot/extlinux/linux.cfg').read_bytes()
        with patch.dict(os.environ,{'PYRA_INSTALLER_TEST_MODE':'1'}):
            self.assertEqual(i.run(['--test-root',str(self.root),'--dry-run']),0)
        self.assertEqual(self.cfg.read_bytes(),conf)
        self.assertEqual((self.root/'boot/extlinux/linux.cfg').read_bytes(),linux)
        self.assertEqual((self.root/'boot/extlinux/user.cfg').read_text(),'')

    def test_pyra_split_config_install_writes_only_user(self):
        self.configure_real_pyra_includes()
        conf=self.cfg.read_bytes()
        linux=(self.root/'boot/extlinux/linux.cfg').read_bytes()
        with patch.dict(os.environ,{'PYRA_INSTALLER_TEST_MODE':'1'}):
            self.assertEqual(i.run(['--test-root',str(self.root),'--yes']),0)
        user=(self.root/'boot/extlinux/user.cfg').read_text()
        self.assertIn('LABEL pyra-m4clean',user)
        self.assertIn('root=PARTUUID=1234',user)
        self.assertIn('omap_remoteproc.pyra_cpu0_only=1',user)
        self.assertIn('FDT /'+i.DTB_INSTALLED,user)
        self.assertEqual(self.cfg.read_bytes(),conf)
        self.assertEqual((self.root/'boot/extlinux/linux.cfg').read_bytes(),linux)
        self.assertEqual(sum(x.startswith('LABEL ') for x in (self.root/'boot/extlinux/linux.cfg').read_text().splitlines()),2)
        self.assertEqual(len(list((self.root/'boot/extlinux').glob('user.cfg.pre-pyra-m4clean-*'))),1)

    def test_pyra_split_config_fdtdir(self):
        self.configure_real_pyra_includes(fdtdir=True)
        with patch.dict(os.environ,{'PYRA_INSTALLER_TEST_MODE':'1'}):
            self.assertEqual(i.run(['--test-root',str(self.root),'--yes']),0)
        user=(self.root/'boot/extlinux/user.cfg').read_text()
        self.assertIn('FDT /dtbs/'+i.DTB_INSTALLED,user)
        self.assertNotIn('FDTDIR',user)
        self.assertTrue((self.root/'boot/dtbs'/i.DTB_INSTALLED).is_file())

    def test_pyra_split_config_label_collision(self):
        self.configure_real_pyra_includes()
        p=self.root/'boot/extlinux/linux.cfg'
        p.write_text(p.read_text()+'LABEL pyra-m4clean\n LINUX /vmlinuz-stock\n FDT /stock-pyra.dtb\n APPEND root=PARTUUID=1234\n')
        with patch.dict(os.environ,{'PYRA_INSTALLER_TEST_MODE':'1'}):
            with self.assertRaises(i.InstallError):
                i.run(['--test-root',str(self.root),'--dry-run'])

    def test_reject_editing_generated_linux_cfg(self):
        self.configure_real_pyra_includes()
        with patch.dict(os.environ,{'PYRA_INSTALLER_TEST_MODE':'1'}):
            with self.assertRaises(i.InstallError):
                i.run(['--test-root',str(self.root),'--dry-run',
                       '--boot-config','/boot/extlinux/linux.cfg'])

    def test_pyra_split_config_user_not_included(self):
        self.configure_real_pyra_includes()
        self.cfg.write_text(self.cfg.read_text().replace('include user.cfg\n',''))
        with patch.dict(os.environ,{'PYRA_INSTALLER_TEST_MODE':'1'}):
            with self.assertRaises(i.InstallError):
                i.run(['--test-root',str(self.root),'--dry-run'])

    def test_hardware_rejection(self):
        (self.root/'proc/device-tree/compatible').write_bytes(b'raspberrypi\0')
        with patch.dict(os.environ,{'PYRA_INSTALLER_TEST_MODE':'1'}):
            with self.assertRaises(i.InstallError):i.run(['--test-root',str(self.root),'--dry-run'])

if __name__=='__main__':unittest.main()
