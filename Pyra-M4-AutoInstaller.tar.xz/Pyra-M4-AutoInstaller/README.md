# Pyra M4 v6 – Automatische Kernelinstallation

Dieses Paket wurde **aus den bereits kompilierten Staging-Dateien** des bereitgestellten Archivs `Pyra-Kernel-M4-v6.tar.xz` erstellt. Es ist **kein Kernel-Build** erforderlich. Der Installer wurde offline mit einem simulierten Boot-Dateisystem getestet, **nicht auf einer echten Pyra gebootet**.

## Enthalten

- `payload/boot/vmlinuz-5.6.19-pyradef-m4test-m4clean` – ARMv7-zImage
- `payload/boot/omap5-letux-cortex15-v5.3+pyra-v5.3-m4test.dtb` – M4-fähiger Pyra-V5.3-Device-Tree
- `payload/boot/config-*` und `System.map-*`
- `payload/lib/modules/5.6.19-pyradef-m4test-m4clean/` – 946 Kernelmodule, einschließlich `pvrsrvkm_omap5_sgx544_116.ko` für PowerVR 1.14.3699939
- `SHA256SUMS` – Prüfsummen aller 964 übernommenen Staging-Dateien
- `install-pyra-m4.sh` / `installer.py` – sichere, additive Installation

**Nicht enthalten:** Kernelquellcode, zusätzliche Firmware für den M4, PowerVR-Userspace-Bibliotheken, ein vorgefertigtes Initramfs. Falls der vorhandene Boot-Eintrag ein Initramfs verwendet, erzeugt der Installer es mit `update-initramfs` auf der Pyra neu.

## Voraussetzungen

- DragonBox Pyra **Hardware V5.3**, ARMv7, OMAP5; eine andere Revision wird nicht stillschweigend akzeptiert.
- Debian-System mit Python 3, `depmod`, funktionierender `/boot`-Einbindung und Extlinux-Bootkonfiguration (`/boot/extlinux/extlinux.conf` mit `include linux.cfg` und `include user.cfg` (auch klassische Konfigurationen ohne INCLUDE werden unterstützt)).
- Ein vorhandener, funktionsfähiger Boot-Eintrag mit explizitem Kernelpfad, `FDT`/`DEVICETREE`/`FDTDIR` und `APPEND` einschließlich `root=` oder `bootargs`.
- Genügend freier Speicherplatz auf `/boot` und der Rootpartition. Das Modulverzeichnis benötigt ca. 44 MB plus Metadaten; das Kernelimage ca. 7 MB. Bei bestehendem Initramfs kommt dessen Größe hinzu.
- Für Initramfs-basierte Systeme `update-initramfs` (Paket `initramfs-tools`).

## Verwendung

1. Archiv auf die neue Pyra übertragen und entpacken:

   ```sh
   tar -xJf Pyra-M4-v6-AutoInstaller.tar.xz
   cd Pyra-M4-v6-AutoInstaller
   ```

2. **Trockenlauf**, ohne Dateien zu verändern:

   ```sh
   ./install-pyra-m4.sh --dry-run
   ```

3. Nach Prüfung der ausgegebenen Pfade **installieren**:

   ```sh
   sudo ./install-pyra-m4.sh --yes 2>&1 | tee pyra-m4-install.log
   ```

   Ohne `--yes` fragt der Installer interaktiv nach `INSTALL`.

4. Die Bootkonfiguration prüfen:

   ```sh
   grep -nE 'DEFAULT|INCLUDE|LABEL|LINUX|KERNEL|FDT|INITRD|APPEND' /boot/extlinux/extlinux.conf
   grep -nE 'DEFAULT|LABEL|LINUX|KERNEL|FDT|INITRD|APPEND' /boot/extlinux/linux.cfg
   grep -nE 'DEFAULT|LABEL|LINUX|KERNEL|FDT|INITRD|APPEND' /boot/extlinux/user.cfg
   ```

5. Neustart und **neuen Eintrag `pyra-m4clean` manuell auswählen**. Der Installer ändert **nicht** den `DEFAULT`-Eintrag und startet **nicht** selbst neu.

6. Nach dem Neustart prüfen:

   ```sh
   uname -r
   test "$(uname -r)" = '5.6.19-pyradef-m4test-m4clean' && echo 'PASS: neuer Kernel aktiv'
   cat /proc/cmdline
   ls /lib/modules/$(uname -r)/kernel/drivers/gpu/drm/pvrsgx/1.14.3699939/eurasia_km/
   dmesg | grep -Ei 'remoteproc|iommu|prm|pvr|sgx|error|fault'
   ```

## Weitere Optionen

```sh
./install-pyra-m4.sh --help
./install-pyra-m4.sh --dry-run --clone-label DEIN_BISHERIGER_EINTRAG
sudo ./install-pyra-m4.sh --yes --clone-label DEIN_BISHERIGER_EINTRAG
sudo ./install-pyra-m4.sh --yes --boot-config /boot/extlinux/user.cfg
```

Bei einer aufgeteilten Pyra-Konfiguration liest der Installer `DEFAULT l0` aus `extlinux.conf`, übernimmt die passende `LABEL l0`-Vorlage aus `linux.cfg` und schreibt **nur** den neuen Eintrag nach `user.cfg`. `extlinux.conf` und `linux.cfg` bleiben bytegenau unverändert. Ein vorhandenes `FDTDIR` wird im neuen Eintrag durch einen expliziten `FDT`-Pfad auf die M4-DTB ersetzt.

Wenn die Konfiguration mehrere mögliche Boot-Einträge ohne eindeutig auflösbaren `DEFAULT` enthält, verweigert der Installer die automatische Auswahl und verlangt `--clone-label`.

## Schutzmechanismen

- SHA-256-Prüfung **vor** der Installation aller 964 Dateien.
- Prüfung von Pyra-V5.3-Hardware, M4-/Mailbox-/IOMMU-Kerneloptionen, ARM-PowerVR-Modul und Modul-Vermagic.
- Neue, getrennte Dateinamen für Kernel und DTB sowie neues `/lib/modules/5.6.19-pyradef-m4test-m4clean`.
- Keine Überschreibung vorhandener Kerneldateien oder Modulverzeichnisse.
- Vor Änderung der Bootkonfiguration wird eine datierte Sicherheitskopie erstellt.
- Der vorhandene Bootmenüeintrag wird **geklont**, mit M4-Device-Tree versehen und um `omap_remoteproc.pyra_cpu0_only=1` ergänzt. Alte M4-Diagnoseparameter werden nur im **neuen** Eintrag entfernt.
- Das bisherige Bootmenü, `DEFAULT` und PowerVR-Userspace-Bibliotheken bleiben unverändert.
- Bei normalen Fehlern während der Installation werden die neu erstellten Dateien entfernt; bei Stromausfall kann eine manuelle Bereinigung nötig sein. Die Bootkonfiguration wird erst ganz zuletzt geändert.

## Rückfall und Deinstallation

Bei einem Bootfehler im Bootmenü den **bisherigen Standardkernel** auswählen. Die Originaldateien bleiben vorhanden.

Für eine spätere Deinstallation zuerst die Sicherung der Bootkonfiguration identifizieren (Ausgabe `Backup:` beim Installieren). Nach Prüfung des Inhalts kannst du den neuen `LABEL pyra-m4clean`-Abschnitt aus der Extlinux-Konfiguration entfernen oder die Sicherung wiederherstellen. Danach (während der alte Kernel läuft) optional die neuen Dateien `vmlinuz-*m4clean`, `System.map-*m4clean`, `config-*m4clean`, `*m4clean.dtb`, `initrd.img-*m4clean` und `/lib/modules/5.6.19-pyradef-m4test-m4clean` entfernen. **Nicht** die alten Kernel- oder DTB-Dateien löschen.

## Einschränkungen

Der Installer unterstützt sowohl klassische Extlinux-Konfigurationen als auch die Pyra-Struktur mit `extlinux.conf` → `linux.cfg` + `user.cfg`. Andere Bootmethoden, nicht eindeutig zuordenbare Bootpfade oder fehlende Device-Tree-Angaben führen zu einem sicheren Abbruch statt zu einer geratenen Installation. Das ist bei einer neuen Pyra mit unbekanntem Bootlayout beabsichtigt.

Die aufgeteilte Konfiguration wurde anhand der gemeldeten Dateistruktur simuliert; der tatsächliche Inhalt der `linux.cfg` wurde noch nicht übermittelt. Deshalb ist der `--dry-run` auf der Pyra weiterhin zwingend.

Die erfolgreiche Installation beweist nicht, dass Kernel, Display, Audio, PowerVR oder M4-Firmware auf der Zielhardware fehlerfrei laufen. Ein funktionierender Recovery-Kernel sollte verfügbar bleiben.
