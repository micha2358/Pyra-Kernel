cmd_block/blk-mq-pci.o := gcc -Wp,-MD,block/.blk-mq-pci.o.d -nostdinc -isystem /usr/lib/gcc/arm-linux-gnueabihf/12/include -I/mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include -I./arch/arm/include/generated -I/mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include -I./include -I/mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/uapi -I./arch/arm/include/generated/uapi -I/mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi -I./include/generated/uapi -include /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/kconfig.h -include /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/compiler_types.h -D__KERNEL__ -mlittle-endian -Wall -Wundef -Werror=strict-prototypes -Wno-trigraphs -fno-strict-aliasing -fno-common -fshort-wchar -fno-PIE -Werror=implicit-function-declaration -Werror=implicit-int -Wno-format-security -std=gnu89 -msoft-float -fno-dwarf2-cfi-asm -fno-ipa-sra -mabi=aapcs-linux -mfpu=vfp -funwind-tables -marm -Wa,-mno-warn-deprecated -D__LINUX_ARM_ARCH__=7 -march=armv7-a -Wa,-march=armv7-a -Uarm -fno-delete-null-pointer-checks -Wno-frame-address -Wno-format-truncation -Wno-format-overflow -Wno-address-of-packed-member -O2 -fno-allow-store-data-races -Wframe-larger-than=1024 -fstack-protector-strong -Wno-unused-but-set-variable -Wimplicit-fallthrough -Wno-unused-const-variable -fomit-frame-pointer -fno-var-tracking-assignments -Wdeclaration-after-statement -Wvla -Wno-pointer-sign -Wno-stringop-truncation -Wno-zero-length-bounds -Wno-array-bounds -Wno-stringop-overflow -Wno-restrict -Wno-maybe-uninitialized -fno-strict-overflow -fno-merge-all-constants -fmerge-constants -fno-stack-check -fconserve-stack -Werror=date-time -Werror=incompatible-pointer-types -Werror=designated-init -fmacro-prefix-map=/mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/= -Wno-packed-not-aligned -I /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/block -I ./block    -DKBUILD_MODFILE='"block/blk-mq-pci"' -DKBUILD_BASENAME='"blk_mq_pci"' -DKBUILD_MODNAME='"blk_mq_pci"' -c -o block/blk-mq-pci.o /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/block/blk-mq-pci.c

source_block/blk-mq-pci.o := /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/block/blk-mq-pci.c

deps_block/blk-mq-pci.o := \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/kconfig.h \
    $(wildcard include/config/cpu/big/endian.h) \
    $(wildcard include/config/booger.h) \
    $(wildcard include/config/foo.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/compiler_types.h \
    $(wildcard include/config/have/arch/compiler/h.h) \
    $(wildcard include/config/enable/must/check.h) \
    $(wildcard include/config/optimize/inlining.h) \
    $(wildcard include/config/cc/has/asm/inline.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/compiler_attributes.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/compiler-gcc.h \
    $(wildcard include/config/retpoline.h) \
    $(wildcard include/config/arch/use/builtin/bswap.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/kobject.h \
    $(wildcard include/config/uevent/helper.h) \
    $(wildcard include/config/debug/kobject/release.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/types.h \
    $(wildcard include/config/have/uid16.h) \
    $(wildcard include/config/uid16.h) \
    $(wildcard include/config/arch/dma/addr/t/64bit.h) \
    $(wildcard include/config/phys/addr/t/64bit.h) \
    $(wildcard include/config/64bit.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/uapi/asm/types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/int-ll64.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/asm-generic/int-ll64.h \
  arch/arm/include/generated/uapi/asm/bitsperlong.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitsperlong.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/asm-generic/bitsperlong.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/posix_types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/stddef.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/stddef.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/compiler_types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/uapi/asm/posix_types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/asm-generic/posix_types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/list.h \
    $(wildcard include/config/debug/list.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/poison.h \
    $(wildcard include/config/illegal/pointer/value.h) \
    $(wildcard include/config/page/poisoning/zero.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/const.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/const.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/kernel.h \
    $(wildcard include/config/preempt/voluntary.h) \
    $(wildcard include/config/debug/atomic/sleep.h) \
    $(wildcard include/config/mmu.h) \
    $(wildcard include/config/prove/locking.h) \
    $(wildcard include/config/panic/timeout.h) \
    $(wildcard include/config/tracing.h) \
    $(wildcard include/config/ftrace/mcount/record.h) \
  /usr/lib/gcc/arm-linux-gnueabihf/12/include/stdarg.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/limits.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/limits.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/linkage.h \
    $(wildcard include/config/x86.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/stringify.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/export.h \
    $(wildcard include/config/modversions.h) \
    $(wildcard include/config/module/rel/crcs.h) \
    $(wildcard include/config/have/arch/prel32/relocations.h) \
    $(wildcard include/config/modules.h) \
    $(wildcard include/config/trim/unused/ksyms.h) \
    $(wildcard include/config/unused/symbols.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/linkage.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/compiler.h \
    $(wildcard include/config/trace/branch/profiling.h) \
    $(wildcard include/config/profile/all/branches.h) \
    $(wildcard include/config/stack/validation.h) \
    $(wildcard include/config/kasan.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/barrier.h \
    $(wildcard include/config/cpu/32v6k.h) \
    $(wildcard include/config/thumb2/kernel.h) \
    $(wildcard include/config/cpu/xsc3.h) \
    $(wildcard include/config/cpu/fa526.h) \
    $(wildcard include/config/arm/heavy/mb.h) \
    $(wildcard include/config/arm/dma/mem/bufferable.h) \
    $(wildcard include/config/smp.h) \
    $(wildcard include/config/cpu/spectre.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/barrier.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/kasan-checks.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/bitops.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/bits.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/bitops.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/irqflags.h \
    $(wildcard include/config/trace/irqflags.h) \
    $(wildcard include/config/irqsoff/tracer.h) \
    $(wildcard include/config/preempt/tracer.h) \
    $(wildcard include/config/trace/irqflags/support.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/typecheck.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/irqflags.h \
    $(wildcard include/config/cpu/v7m.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/ptrace.h \
    $(wildcard include/config/arm/thumb.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/uapi/asm/ptrace.h \
    $(wildcard include/config/cpu/endian/be8.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/hwcap.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/uapi/asm/hwcap.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/irqflags.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/non-atomic.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/builtin-__fls.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/builtin-__ffs.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/builtin-fls.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/builtin-ffs.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/ffz.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/fls64.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/sched.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/hweight.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/arch_hweight.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/const_hweight.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/lock.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/atomic.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/atomic.h \
    $(wildcard include/config/generic/atomic64.h) \
    $(wildcard include/config/arm/lpae.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/prefetch.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/processor.h \
    $(wildcard include/config/have/hw/breakpoint.h) \
    $(wildcard include/config/binfmt/elf/fdpic.h) \
    $(wildcard include/config/arm/errata/754327.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/hw_breakpoint.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/unified.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/cache.h \
    $(wildcard include/config/arm/l1/cache/shift.h) \
    $(wildcard include/config/aeabi.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/cmpxchg.h \
    $(wildcard include/config/cpu/sa1100.h) \
    $(wildcard include/config/cpu/sa110.h) \
    $(wildcard include/config/cpu/v6.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/cmpxchg-local.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/atomic-fallback.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/atomic-long.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/find.h \
    $(wildcard include/config/generic/find/first/bit.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/le.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/uapi/asm/byteorder.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/byteorder/little_endian.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/byteorder/little_endian.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/swab.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/swab.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/swab.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/uapi/asm/swab.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/byteorder/generic.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/ext2-atomic-setbit.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/log2.h \
    $(wildcard include/config/arch/has/ilog2/u32.h) \
    $(wildcard include/config/arch/has/ilog2/u64.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/printk.h \
    $(wildcard include/config/message/loglevel/default.h) \
    $(wildcard include/config/console/loglevel/default.h) \
    $(wildcard include/config/console/loglevel/quiet.h) \
    $(wildcard include/config/early/printk.h) \
    $(wildcard include/config/printk/nmi.h) \
    $(wildcard include/config/printk.h) \
    $(wildcard include/config/dynamic/debug.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/init.h \
    $(wildcard include/config/strict/kernel/rwx.h) \
    $(wildcard include/config/strict/module/rwx.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/kern_levels.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/cache.h \
    $(wildcard include/config/arch/has/cache/line/size.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/kernel.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/sysinfo.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/dynamic_debug.h \
    $(wildcard include/config/jump/label.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/jump_label.h \
    $(wildcard include/config/have/arch/jump/label/relative.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/jump_label.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/build_bug.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/div64.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/compiler.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/div64.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/sysfs.h \
    $(wildcard include/config/debug/lock/alloc.h) \
    $(wildcard include/config/sysfs.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/kernfs.h \
    $(wildcard include/config/kernfs.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/err.h \
  arch/arm/include/generated/uapi/asm/errno.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/asm-generic/errno.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/asm-generic/errno-base.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/mutex.h \
    $(wildcard include/config/mutex/spin/on/owner.h) \
    $(wildcard include/config/debug/mutexes.h) \
  arch/arm/include/generated/asm/current.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/current.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/thread_info.h \
    $(wildcard include/config/thread/info/in/task.h) \
    $(wildcard include/config/have/arch/within/stack/frames.h) \
    $(wildcard include/config/hardened/usercopy.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/bug.h \
    $(wildcard include/config/generic/bug.h) \
    $(wildcard include/config/bug/on/data/corruption.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/bug.h \
    $(wildcard include/config/debug/bugverbose.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/opcodes.h \
    $(wildcard include/config/cpu/endian/be32.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bug.h \
    $(wildcard include/config/bug.h) \
    $(wildcard include/config/generic/bug/relative/pointers.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/restart_block.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/time64.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/math64.h \
    $(wildcard include/config/arch/supports/int128.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/time.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/time_types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/thread_info.h \
    $(wildcard include/config/stackprotector/per/task.h) \
    $(wildcard include/config/crunch.h) \
    $(wildcard include/config/arm/thumbee.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/fpstate.h \
    $(wildcard include/config/vfpv3.h) \
    $(wildcard include/config/iwmmxt.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/page.h \
    $(wildcard include/config/cpu/copy/v4wt.h) \
    $(wildcard include/config/cpu/copy/v4wb.h) \
    $(wildcard include/config/cpu/copy/feroceon.h) \
    $(wildcard include/config/cpu/copy/fa.h) \
    $(wildcard include/config/cpu/xscale.h) \
    $(wildcard include/config/cpu/copy/v6.h) \
    $(wildcard include/config/kuser/helpers.h) \
    $(wildcard include/config/have/arch/pfn/valid.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/glue.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/pgtable-3level-types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/memory.h \
    $(wildcard include/config/need/mach/memory/h.h) \
    $(wildcard include/config/page/offset.h) \
    $(wildcard include/config/highmem.h) \
    $(wildcard include/config/dram/base.h) \
    $(wildcard include/config/dram/size.h) \
    $(wildcard include/config/xip/kernel.h) \
    $(wildcard include/config/have/tcm.h) \
    $(wildcard include/config/arm/patch/phys/virt.h) \
    $(wildcard include/config/phys/offset.h) \
    $(wildcard include/config/xip/phys/addr.h) \
    $(wildcard include/config/debug/virtual.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/sizes.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/memory_model.h \
    $(wildcard include/config/flatmem.h) \
    $(wildcard include/config/discontigmem.h) \
    $(wildcard include/config/sparsemem/vmemmap.h) \
    $(wildcard include/config/sparsemem.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/pfn.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/getorder.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/spinlock_types.h \
    $(wildcard include/config/debug/spinlock.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/spinlock_types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/lockdep.h \
    $(wildcard include/config/lockdep.h) \
    $(wildcard include/config/lock/stat.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/rwlock_types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/osq_lock.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/debug_locks.h \
    $(wildcard include/config/debug/locking/api/selftests.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/idr.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/radix-tree.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/preempt.h \
    $(wildcard include/config/preempt/count.h) \
    $(wildcard include/config/debug/preempt.h) \
    $(wildcard include/config/trace/preempt/toggle.h) \
    $(wildcard include/config/preemption.h) \
    $(wildcard include/config/preempt/notifiers.h) \
  arch/arm/include/generated/asm/preempt.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/preempt.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/rcupdate.h \
    $(wildcard include/config/preempt/rcu.h) \
    $(wildcard include/config/rcu/stall/common.h) \
    $(wildcard include/config/no/hz/full.h) \
    $(wildcard include/config/rcu/nocb/cpu.h) \
    $(wildcard include/config/tasks/rcu.h) \
    $(wildcard include/config/tree/rcu.h) \
    $(wildcard include/config/tiny/rcu.h) \
    $(wildcard include/config/debug/objects/rcu/head.h) \
    $(wildcard include/config/hotplug/cpu.h) \
    $(wildcard include/config/prove/rcu.h) \
    $(wildcard include/config/rcu/boost.h) \
    $(wildcard include/config/arch/weak/release/acquire.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/bottom_half.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/cpumask.h \
    $(wildcard include/config/cpumask/offstack.h) \
    $(wildcard include/config/debug/per/cpu/maps.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/threads.h \
    $(wildcard include/config/nr/cpus.h) \
    $(wildcard include/config/base/small.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/bitmap.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/string.h \
    $(wildcard include/config/binary/printf.h) \
    $(wildcard include/config/fortify/source.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/string.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/string.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/rcutree.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/spinlock.h \
  arch/arm/include/generated/asm/mmiowb.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/mmiowb.h \
    $(wildcard include/config/mmiowb.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/spinlock.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/rwlock.h \
    $(wildcard include/config/preempt.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/spinlock_api_smp.h \
    $(wildcard include/config/inline/spin/lock.h) \
    $(wildcard include/config/inline/spin/lock/bh.h) \
    $(wildcard include/config/inline/spin/lock/irq.h) \
    $(wildcard include/config/inline/spin/lock/irqsave.h) \
    $(wildcard include/config/inline/spin/trylock.h) \
    $(wildcard include/config/inline/spin/trylock/bh.h) \
    $(wildcard include/config/uninline/spin/unlock.h) \
    $(wildcard include/config/inline/spin/unlock/bh.h) \
    $(wildcard include/config/inline/spin/unlock/irq.h) \
    $(wildcard include/config/inline/spin/unlock/irqrestore.h) \
    $(wildcard include/config/generic/lockbreak.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/rwlock_api_smp.h \
    $(wildcard include/config/inline/read/lock.h) \
    $(wildcard include/config/inline/write/lock.h) \
    $(wildcard include/config/inline/read/lock/bh.h) \
    $(wildcard include/config/inline/write/lock/bh.h) \
    $(wildcard include/config/inline/read/lock/irq.h) \
    $(wildcard include/config/inline/write/lock/irq.h) \
    $(wildcard include/config/inline/read/lock/irqsave.h) \
    $(wildcard include/config/inline/write/lock/irqsave.h) \
    $(wildcard include/config/inline/read/trylock.h) \
    $(wildcard include/config/inline/write/trylock.h) \
    $(wildcard include/config/inline/read/unlock.h) \
    $(wildcard include/config/inline/write/unlock.h) \
    $(wildcard include/config/inline/read/unlock/bh.h) \
    $(wildcard include/config/inline/write/unlock/bh.h) \
    $(wildcard include/config/inline/read/unlock/irq.h) \
    $(wildcard include/config/inline/write/unlock/irq.h) \
    $(wildcard include/config/inline/read/unlock/irqrestore.h) \
    $(wildcard include/config/inline/write/unlock/irqrestore.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/xarray.h \
    $(wildcard include/config/xarray/multi.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/gfp.h \
    $(wildcard include/config/zone/dma.h) \
    $(wildcard include/config/zone/dma32.h) \
    $(wildcard include/config/zone/device.h) \
    $(wildcard include/config/numa.h) \
    $(wildcard include/config/pm/sleep.h) \
    $(wildcard include/config/contig/alloc.h) \
    $(wildcard include/config/cma.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/mmdebug.h \
    $(wildcard include/config/debug/vm.h) \
    $(wildcard include/config/debug/vm/pgflags.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/mmzone.h \
    $(wildcard include/config/force/max/zoneorder.h) \
    $(wildcard include/config/memory/isolation.h) \
    $(wildcard include/config/shuffle/page/allocator.h) \
    $(wildcard include/config/zsmalloc.h) \
    $(wildcard include/config/memcg.h) \
    $(wildcard include/config/memory/hotplug.h) \
    $(wildcard include/config/compaction.h) \
    $(wildcard include/config/transparent/hugepage.h) \
    $(wildcard include/config/flat/node/mem/map.h) \
    $(wildcard include/config/page/extension.h) \
    $(wildcard include/config/deferred/struct/page/init.h) \
    $(wildcard include/config/have/memory/present.h) \
    $(wildcard include/config/have/memoryless/nodes.h) \
    $(wildcard include/config/have/memblock/node/map.h) \
    $(wildcard include/config/need/multiple/nodes.h) \
    $(wildcard include/config/have/arch/early/pfn/to/nid.h) \
    $(wildcard include/config/sparsemem/extreme.h) \
    $(wildcard include/config/memory/hotremove.h) \
    $(wildcard include/config/holes/in/zone.h) \
    $(wildcard include/config/arch/has/holes/memorymodel.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/wait.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/wait.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/numa.h \
    $(wildcard include/config/nodes/shift.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/seqlock.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/nodemask.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/pageblock-flags.h \
    $(wildcard include/config/hugetlb/page.h) \
    $(wildcard include/config/hugetlb/page/size/variable.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/page-flags-layout.h \
    $(wildcard include/config/numa/balancing.h) \
    $(wildcard include/config/kasan/sw/tags.h) \
  include/generated/bounds.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/mm_types.h \
    $(wildcard include/config/have/aligned/struct/page.h) \
    $(wildcard include/config/userfaultfd.h) \
    $(wildcard include/config/swap.h) \
    $(wildcard include/config/have/arch/compat/mmap/bases.h) \
    $(wildcard include/config/membarrier.h) \
    $(wildcard include/config/aio.h) \
    $(wildcard include/config/mmu/notifier.h) \
    $(wildcard include/config/arch/want/batched/unmap/tlb/flush.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/mm_types_task.h \
    $(wildcard include/config/split/ptlock/cpus.h) \
    $(wildcard include/config/arch/enable/split/pmd/ptlock.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/auxvec.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/auxvec.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/auxvec.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/uapi/asm/auxvec.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/rbtree.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/rwsem.h \
    $(wildcard include/config/rwsem/spin/on/owner.h) \
    $(wildcard include/config/debug/rwsems.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/completion.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/uprobes.h \
    $(wildcard include/config/uprobes.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/errno.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/errno.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/workqueue.h \
    $(wildcard include/config/debug/objects/work.h) \
    $(wildcard include/config/freezer.h) \
    $(wildcard include/config/wq/watchdog.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/timer.h \
    $(wildcard include/config/debug/objects/timers.h) \
    $(wildcard include/config/preempt/rt.h) \
    $(wildcard include/config/no/hz/common.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/ktime.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/time.h \
    $(wildcard include/config/arch/uses/gettimeoffset.h) \
    $(wildcard include/config/posix/timers.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/time32.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/timex.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/timex.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/param.h \
  arch/arm/include/generated/uapi/asm/param.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/param.h \
    $(wildcard include/config/hz.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/asm-generic/param.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/timex.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/jiffies.h \
  include/generated/timeconst.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/timekeeping.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/timekeeping32.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/debugobjects.h \
    $(wildcard include/config/debug/objects.h) \
    $(wildcard include/config/debug/objects/free.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/mmu.h \
    $(wildcard include/config/cpu/has/asid.h) \
    $(wildcard include/config/vdso.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/page-flags.h \
    $(wildcard include/config/arch/uses/pg/uncached.h) \
    $(wildcard include/config/memory/failure.h) \
    $(wildcard include/config/idle/page/tracking.h) \
    $(wildcard include/config/thp/swap.h) \
    $(wildcard include/config/ksm.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/memory_hotplug.h \
    $(wildcard include/config/arch/has/add/pages.h) \
    $(wildcard include/config/have/arch/nodedata/extension.h) \
    $(wildcard include/config/have/bootmem/info/node.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/notifier.h \
    $(wildcard include/config/tree/srcu.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/srcu.h \
    $(wildcard include/config/tiny/srcu.h) \
    $(wildcard include/config/srcu.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/rcu_segcblist.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/srcutree.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/rcu_node_tree.h \
    $(wildcard include/config/rcu/fanout.h) \
    $(wildcard include/config/rcu/fanout/leaf.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/topology.h \
    $(wildcard include/config/use/percpu/numa/node/id.h) \
    $(wildcard include/config/sched/smt.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/arch_topology.h \
    $(wildcard include/config/generic/arch/topology.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/percpu.h \
    $(wildcard include/config/need/per/cpu/embed/first/chunk.h) \
    $(wildcard include/config/need/per/cpu/page/first/chunk.h) \
    $(wildcard include/config/have/setup/per/cpu/area.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/smp.h \
    $(wildcard include/config/up/late/init.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/llist.h \
    $(wildcard include/config/arch/have/nmi/safe/cmpxchg.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/smp.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/percpu.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/percpu.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/percpu-defs.h \
    $(wildcard include/config/debug/force/weak/per/cpu.h) \
    $(wildcard include/config/amd/mem/encrypt.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/topology.h \
    $(wildcard include/config/arm/cpu/topology.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/topology.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/kconfig.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/uidgid.h \
    $(wildcard include/config/multiuser.h) \
    $(wildcard include/config/user/ns.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/highuid.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/kobject_ns.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/stat.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/uapi/asm/stat.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/stat.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/kref.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/refcount.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/blkdev.h \
    $(wildcard include/config/block.h) \
    $(wildcard include/config/blk/rq/alloc/time.h) \
    $(wildcard include/config/blk/wbt.h) \
    $(wildcard include/config/blk/dev/integrity.h) \
    $(wildcard include/config/blk/dev/zoned.h) \
    $(wildcard include/config/pm.h) \
    $(wildcard include/config/blk/cgroup.h) \
    $(wildcard include/config/blk/dev/io/trace.h) \
    $(wildcard include/config/blk/dev/bsg.h) \
    $(wildcard include/config/blk/dev/throttling.h) \
    $(wildcard include/config/blk/debug/fs.h) \
    $(wildcard include/config/compat.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/sched.h \
    $(wildcard include/config/virt/cpu/accounting/native.h) \
    $(wildcard include/config/sched/info.h) \
    $(wildcard include/config/schedstats.h) \
    $(wildcard include/config/fair/group/sched.h) \
    $(wildcard include/config/rt/group/sched.h) \
    $(wildcard include/config/uclamp/task.h) \
    $(wildcard include/config/uclamp/buckets/count.h) \
    $(wildcard include/config/cgroup/sched.h) \
    $(wildcard include/config/psi.h) \
    $(wildcard include/config/compat/brk.h) \
    $(wildcard include/config/cgroups.h) \
    $(wildcard include/config/stackprotector.h) \
    $(wildcard include/config/arch/has/scaled/cputime.h) \
    $(wildcard include/config/virt/cpu/accounting/gen.h) \
    $(wildcard include/config/posix/cputimers.h) \
    $(wildcard include/config/keys.h) \
    $(wildcard include/config/sysvipc.h) \
    $(wildcard include/config/detect/hung/task.h) \
    $(wildcard include/config/audit.h) \
    $(wildcard include/config/auditsyscall.h) \
    $(wildcard include/config/rt/mutexes.h) \
    $(wildcard include/config/ubsan.h) \
    $(wildcard include/config/task/xacct.h) \
    $(wildcard include/config/cpusets.h) \
    $(wildcard include/config/x86/cpu/resctrl.h) \
    $(wildcard include/config/futex.h) \
    $(wildcard include/config/perf/events.h) \
    $(wildcard include/config/rseq.h) \
    $(wildcard include/config/task/delay/acct.h) \
    $(wildcard include/config/fault/injection.h) \
    $(wildcard include/config/latencytop.h) \
    $(wildcard include/config/function/graph/tracer.h) \
    $(wildcard include/config/kcov.h) \
    $(wildcard include/config/bcache.h) \
    $(wildcard include/config/vmap/stack.h) \
    $(wildcard include/config/livepatch.h) \
    $(wildcard include/config/security.h) \
    $(wildcard include/config/gcc/plugin/stackleak.h) \
    $(wildcard include/config/arch/task/struct/on/stack.h) \
    $(wildcard include/config/debug/rseq.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/sched.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/pid.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/rculist.h \
    $(wildcard include/config/prove/rcu/list.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/sem.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/sem.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/ipc.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/rhashtable-types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/ipc.h \
  arch/arm/include/generated/uapi/asm/ipcbuf.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/asm-generic/ipcbuf.h \
  arch/arm/include/generated/uapi/asm/sembuf.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/asm-generic/sembuf.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/shm.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/shm.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/asm-generic/hugetlb_encode.h \
  arch/arm/include/generated/uapi/asm/shmbuf.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/asm-generic/shmbuf.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/shmparam.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/kcov.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/kcov.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/plist.h \
    $(wildcard include/config/debug/plist.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/hrtimer.h \
    $(wildcard include/config/high/res/timers.h) \
    $(wildcard include/config/time/low/res.h) \
    $(wildcard include/config/timerfd.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/hrtimer_defs.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/timerqueue.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/seccomp.h \
    $(wildcard include/config/seccomp.h) \
    $(wildcard include/config/have/arch/seccomp/filter.h) \
    $(wildcard include/config/seccomp/filter.h) \
    $(wildcard include/config/checkpoint/restore.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/seccomp.h \
  arch/arm/include/generated/asm/seccomp.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/seccomp.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/unistd.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/unistd.h \
    $(wildcard include/config/oabi/compat.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/uapi/asm/unistd.h \
  arch/arm/include/generated/uapi/asm/unistd-eabi.h \
  arch/arm/include/generated/uapi/asm/unistd-common.h \
  arch/arm/include/generated/asm/unistd-nr.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/resource.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/resource.h \
  arch/arm/include/generated/uapi/asm/resource.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/resource.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/asm-generic/resource.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/latencytop.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/sched/prio.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/sched/types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/signal_types.h \
    $(wildcard include/config/old/sigaction.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/signal.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/signal.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/uapi/asm/signal.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/asm-generic/signal-defs.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/uapi/asm/sigcontext.h \
  arch/arm/include/generated/uapi/asm/siginfo.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/asm-generic/siginfo.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/task_io_accounting.h \
    $(wildcard include/config/task/io/accounting.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/posix-timers.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/alarmtimer.h \
    $(wildcard include/config/rtc/class.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/rseq.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/sched/clock.h \
    $(wildcard include/config/have/unstable/sched/clock.h) \
    $(wildcard include/config/irq/time/accounting.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/major.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/genhd.h \
    $(wildcard include/config/fail/make/request.h) \
    $(wildcard include/config/solaris/x86/partition.h) \
    $(wildcard include/config/bsd/disklabel.h) \
    $(wildcard include/config/unixware/disklabel.h) \
    $(wildcard include/config/minix/subpartition.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/kdev_t.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/kdev_t.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/slab.h \
    $(wildcard include/config/debug/slab.h) \
    $(wildcard include/config/failslab.h) \
    $(wildcard include/config/memcg/kmem.h) \
    $(wildcard include/config/have/hardened/usercopy/allocator.h) \
    $(wildcard include/config/slab.h) \
    $(wildcard include/config/slub.h) \
    $(wildcard include/config/slob.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/overflow.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/percpu-refcount.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/kasan.h \
    $(wildcard include/config/kasan/vmalloc.h) \
    $(wildcard include/config/kasan/generic.h) \
    $(wildcard include/config/kasan/inline.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/uuid.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/uuid.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/blk_types.h \
    $(wildcard include/config/alpha.h) \
    $(wildcard include/config/blk/cgroup/iocost.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/bvec.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/mm.h \
    $(wildcard include/config/sysctl.h) \
    $(wildcard include/config/have/arch/mmap/rnd/bits.h) \
    $(wildcard include/config/have/arch/mmap/rnd/compat/bits.h) \
    $(wildcard include/config/mem/soft/dirty.h) \
    $(wildcard include/config/arch/uses/high/vma/flags.h) \
    $(wildcard include/config/arch/has/pkeys.h) \
    $(wildcard include/config/ppc.h) \
    $(wildcard include/config/parisc.h) \
    $(wildcard include/config/ia64.h) \
    $(wildcard include/config/sparc64.h) \
    $(wildcard include/config/x86/intel/mpx.h) \
    $(wildcard include/config/stack/growsup.h) \
    $(wildcard include/config/shmem.h) \
    $(wildcard include/config/dev/pagemap/ops.h) \
    $(wildcard include/config/device/private.h) \
    $(wildcard include/config/pci/p2pdma.h) \
    $(wildcard include/config/arch/has/pte/devmap.h) \
    $(wildcard include/config/debug/vm/rb.h) \
    $(wildcard include/config/page/poisoning.h) \
    $(wildcard include/config/init/on/alloc/default/on.h) \
    $(wildcard include/config/init/on/free/default/on.h) \
    $(wildcard include/config/debug/pagealloc.h) \
    $(wildcard include/config/arch/has/set/direct/map.h) \
    $(wildcard include/config/hibernation.h) \
    $(wildcard include/config/hugetlbfs.h) \
    $(wildcard include/config/mapping/dirty/helpers.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/range.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/bit_spinlock.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/shrinker.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/page_ext.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/stacktrace.h \
    $(wildcard include/config/stacktrace.h) \
    $(wildcard include/config/arch/stackwalk.h) \
    $(wildcard include/config/have/reliable/stacktrace.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/stackdepot.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/page_ref.h \
    $(wildcard include/config/debug/page/ref.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/tracepoint-defs.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/static_key.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/memremap.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/ioport.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/pgtable.h \
    $(wildcard include/config/highpte.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/proc-fns.h \
    $(wildcard include/config/big/little.h) \
    $(wildcard include/config/harden/branch/predictor.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/glue-proc.h \
    $(wildcard include/config/cpu/arm7tdmi.h) \
    $(wildcard include/config/cpu/arm720t.h) \
    $(wildcard include/config/cpu/arm740t.h) \
    $(wildcard include/config/cpu/arm9tdmi.h) \
    $(wildcard include/config/cpu/arm920t.h) \
    $(wildcard include/config/cpu/arm922t.h) \
    $(wildcard include/config/cpu/arm925t.h) \
    $(wildcard include/config/cpu/arm926t.h) \
    $(wildcard include/config/cpu/arm940t.h) \
    $(wildcard include/config/cpu/arm946e.h) \
    $(wildcard include/config/cpu/arm1020.h) \
    $(wildcard include/config/cpu/arm1020e.h) \
    $(wildcard include/config/cpu/arm1022.h) \
    $(wildcard include/config/cpu/arm1026.h) \
    $(wildcard include/config/cpu/mohawk.h) \
    $(wildcard include/config/cpu/feroceon.h) \
    $(wildcard include/config/cpu/v6k.h) \
    $(wildcard include/config/cpu/pj4b.h) \
    $(wildcard include/config/cpu/v7.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/pgtable-nopud.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/pgtable-nop4d-hack.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/5level-fixup.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/pgtable-hwdef.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/pgtable-3level-hwdef.h \
    $(wildcard include/config/vmsplit/2g.h) \
    $(wildcard include/config/vmsplit/3g.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/tlbflush.h \
    $(wildcard include/config/smp/on/up.h) \
    $(wildcard include/config/cpu/tlb/v4wt.h) \
    $(wildcard include/config/cpu/tlb/fa.h) \
    $(wildcard include/config/cpu/tlb/v4wbi.h) \
    $(wildcard include/config/cpu/tlb/feroceon.h) \
    $(wildcard include/config/cpu/tlb/v4wb.h) \
    $(wildcard include/config/cpu/tlb/v6.h) \
    $(wildcard include/config/cpu/tlb/v7.h) \
    $(wildcard include/config/arm/errata/720789.h) \
    $(wildcard include/config/arm/errata/798181.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/pgtable-3level.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/pgtable.h \
    $(wildcard include/config/pgtable/levels.h) \
    $(wildcard include/config/have/arch/transparent/hugepage/pud.h) \
    $(wildcard include/config/have/arch/soft/dirty.h) \
    $(wildcard include/config/arch/enable/thp/migration.h) \
    $(wildcard include/config/have/arch/huge/vmap.h) \
    $(wildcard include/config/x86/espfix64.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/huge_mm.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/sched/coredump.h \
    $(wildcard include/config/core/dump/default/elf/headers.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/fs.h \
    $(wildcard include/config/read/only/thp/for/fs.h) \
    $(wildcard include/config/fs/posix/acl.h) \
    $(wildcard include/config/cgroup/writeback.h) \
    $(wildcard include/config/ima.h) \
    $(wildcard include/config/file/locking.h) \
    $(wildcard include/config/fsnotify.h) \
    $(wildcard include/config/fs/encryption.h) \
    $(wildcard include/config/fs/verity.h) \
    $(wildcard include/config/epoll.h) \
    $(wildcard include/config/quota.h) \
    $(wildcard include/config/fs/dax.h) \
    $(wildcard include/config/mandatory/file/locking.h) \
    $(wildcard include/config/migration.h) \
    $(wildcard include/config/io/uring.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/wait_bit.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/dcache.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/rculist_bl.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/list_bl.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/lockref.h \
    $(wildcard include/config/arch/use/cmpxchg/lockref.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/stringhash.h \
    $(wildcard include/config/dcache/word/access.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/hash.h \
    $(wildcard include/config/have/arch/hash.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/path.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/list_lru.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/capability.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/capability.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/semaphore.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/fcntl.h \
    $(wildcard include/config/arch/32bit/off/t.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/fcntl.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/uapi/asm/fcntl.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/asm-generic/fcntl.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/openat2.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/fiemap.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/migrate_mode.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/percpu-rwsem.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/rcuwait.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/rcu_sync.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/delayed_call.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/errseq.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/ioprio.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/sched/rt.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/iocontext.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/fs_types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/fs.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/ioctl.h \
  arch/arm/include/generated/uapi/asm/ioctl.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/ioctl.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/asm-generic/ioctl.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/quota.h \
    $(wildcard include/config/quota/netlink/interface.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/percpu_counter.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/dqblk_xfs.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/dqblk_v1.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/dqblk_v2.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/dqblk_qtree.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/projid.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/quota.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/nfs_fs_i.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/vmstat.h \
    $(wildcard include/config/vm/event/counters.h) \
    $(wildcard include/config/debug/tlbflush.h) \
    $(wildcard include/config/debug/vm/vmacache.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/vm_event_item.h \
    $(wildcard include/config/memory/balloon.h) \
    $(wildcard include/config/balloon/compaction.h) \
  arch/arm/include/generated/asm/local.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/local.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/device.h \
    $(wildcard include/config/debug/devres.h) \
    $(wildcard include/config/generic/msi/irq/domain.h) \
    $(wildcard include/config/pinctrl.h) \
    $(wildcard include/config/generic/msi/irq.h) \
    $(wildcard include/config/dma/declare/coherent.h) \
    $(wildcard include/config/dma/cma.h) \
    $(wildcard include/config/arch/has/sync/dma/for/device.h) \
    $(wildcard include/config/arch/has/sync/dma/for/cpu.h) \
    $(wildcard include/config/arch/has/sync/dma/for/cpu/all.h) \
    $(wildcard include/config/of.h) \
    $(wildcard include/config/devtmpfs.h) \
    $(wildcard include/config/sysfs/deprecated.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/dev_printk.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/ratelimit.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/klist.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/pm.h \
    $(wildcard include/config/vt/console/sleep.h) \
    $(wildcard include/config/pm/clk.h) \
    $(wildcard include/config/pm/generic/domains.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/device/bus.h \
    $(wildcard include/config/acpi.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/device/class.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/device/driver.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/device.h \
    $(wildcard include/config/dmabounce.h) \
    $(wildcard include/config/iommu/api.h) \
    $(wildcard include/config/arm/dma/use/iommu.h) \
    $(wildcard include/config/arch/omap.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/pm_wakeup.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/pagemap.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/highmem.h \
    $(wildcard include/config/x86/32.h) \
    $(wildcard include/config/debug/highmem.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/uaccess.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/uaccess.h \
    $(wildcard include/config/cpu/sw/domain/pan.h) \
    $(wildcard include/config/cpu/use/domains.h) \
    $(wildcard include/config/uaccess/with/memcpy.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/domain.h \
    $(wildcard include/config/io/36.h) \
    $(wildcard include/config/cpu/cp15/mmu.h) \
  arch/arm/include/generated/asm/extable.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/extable.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/hardirq.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/ftrace_irq.h \
    $(wildcard include/config/ftrace/nmi/enter.h) \
    $(wildcard include/config/hwlat/tracer.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/vtime.h \
    $(wildcard include/config/virt/cpu/accounting.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/context_tracking_state.h \
    $(wildcard include/config/context/tracking.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/hardirq.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/irq.h \
    $(wildcard include/config/sparse/irq.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/irq_cpustat.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/cacheflush.h \
    $(wildcard include/config/arm/errata/411920.h) \
    $(wildcard include/config/cpu/cache/vipt.h) \
    $(wildcard include/config/outer/cache.h) \
    $(wildcard include/config/frame/pointer.h) \
    $(wildcard include/config/cpu/icache/mismatch/workaround.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/glue-cache.h \
    $(wildcard include/config/cpu/cache/v4.h) \
    $(wildcard include/config/cpu/cache/v4wb.h) \
    $(wildcard include/config/cache/b15/rac.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/cachetype.h \
    $(wildcard include/config/cpu/cache/vivt.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/outercache.h \
    $(wildcard include/config/outer/cache/sync.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/kmap_types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/highmem.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/hugetlb_inline.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/backing-dev-defs.h \
    $(wildcard include/config/debug/fs.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/flex_proportions.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/mempool.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/bio.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/bsg.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/bsg.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/scatterlist.h \
    $(wildcard include/config/need/sg/dma/length.h) \
    $(wildcard include/config/debug/sg.h) \
    $(wildcard include/config/sgl/alloc.h) \
    $(wildcard include/config/arch/no/sg/chain.h) \
    $(wildcard include/config/sg/pool.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/io.h \
    $(wildcard include/config/pci.h) \
    $(wildcard include/config/need/mach/io/h.h) \
    $(wildcard include/config/pcmcia/soc/common.h) \
    $(wildcard include/config/isa.h) \
    $(wildcard include/config/pccard.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/pci_iomap.h \
    $(wildcard include/config/no/generic/pci/ioport/map.h) \
    $(wildcard include/config/generic/pci/iomap.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/io.h \
    $(wildcard include/config/generic/iomap.h) \
    $(wildcard include/config/generic/ioremap.h) \
    $(wildcard include/config/has/ioport/map.h) \
    $(wildcard include/config/virt/to/bus.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/logic_pio.h \
    $(wildcard include/config/indirect/pio.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/fwnode.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/vmalloc.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/vmalloc.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/blkzoned.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/elevator.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/hashtable.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/blk-mq.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/sbitmap.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/blk-mq-pci.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/pci.h \
    $(wildcard include/config/pci/iov.h) \
    $(wildcard include/config/pcieaer.h) \
    $(wildcard include/config/pcieaspm.h) \
    $(wildcard include/config/hotplug/pci/pcie.h) \
    $(wildcard include/config/pcie/ptm.h) \
    $(wildcard include/config/pci/msi.h) \
    $(wildcard include/config/pci/ats.h) \
    $(wildcard include/config/pci/pri.h) \
    $(wildcard include/config/pci/pasid.h) \
    $(wildcard include/config/pci/domains/generic.h) \
    $(wildcard include/config/pcieportbus.h) \
    $(wildcard include/config/pci/domains.h) \
    $(wildcard include/config/pci/quirks.h) \
    $(wildcard include/config/hibernate/callbacks.h) \
    $(wildcard include/config/pci/mmconfig.h) \
    $(wildcard include/config/acpi/mcfg.h) \
    $(wildcard include/config/hotplug/pci.h) \
    $(wildcard include/config/eeh.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/mod_devicetable.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/interrupt.h \
    $(wildcard include/config/irq/forced/threading.h) \
    $(wildcard include/config/generic/irq/probe.h) \
    $(wildcard include/config/proc/fs.h) \
    $(wildcard include/config/irq/timings.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/irqreturn.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/irqnr.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/irqnr.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/sections.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/sections.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/io.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/resource_ext.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/pci.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/pci_regs.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/pci_ids.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/dmapool.h \
    $(wildcard include/config/has/dma.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/pci.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/mach/pci.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/pci-dma-compat.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/dma-mapping.h \
    $(wildcard include/config/swiotlb.h) \
    $(wildcard include/config/arch/has/setup/dma/ops.h) \
    $(wildcard include/config/arch/has/teardown/dma/ops.h) \
    $(wildcard include/config/need/dma/map/state.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/dma-debug.h \
    $(wildcard include/config/dma/api/debug.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/dma-direction.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/mem_encrypt.h \
    $(wildcard include/config/arch/has/mem/encrypt.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/dma-mapping.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/xen/xen.h \
    $(wildcard include/config/xen.h) \
    $(wildcard include/config/xen/pvh.h) \
    $(wildcard include/config/xen/dom0.h) \
    $(wildcard include/config/xen/balloon.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/xen/interface/hvm/start_info.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/xen/hypervisor.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/xen/arm/hypervisor.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/module.h \
    $(wildcard include/config/modules/tree/lookup.h) \
    $(wildcard include/config/module/sig.h) \
    $(wildcard include/config/kallsyms.h) \
    $(wildcard include/config/tracepoints.h) \
    $(wildcard include/config/bpf/events.h) \
    $(wildcard include/config/event/tracing.h) \
    $(wildcard include/config/module/unload.h) \
    $(wildcard include/config/constructors.h) \
    $(wildcard include/config/function/error/injection.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/kmod.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/umh.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/sysctl.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/sysctl.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/elf.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/elf.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/vdso_datapage.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/vdso/datapage.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/user.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/elf.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/elf-em.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/moduleparam.h \
    $(wildcard include/config/ppc64.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/rbtree_latch.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/error-injection.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/error-injection.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/module.h \
    $(wildcard include/config/arm/unwind.h) \
    $(wildcard include/config/arm/module/plts.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/module.h \
    $(wildcard include/config/have/mod/arch/specific.h) \
    $(wildcard include/config/modules/use/elf/rel.h) \
    $(wildcard include/config/modules/use/elf/rela.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/block/blk-mq.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/block/blk-stat.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/block/blk-mq-tag.h \

block/blk-mq-pci.o: $(deps_block/blk-mq-pci.o)

$(deps_block/blk-mq-pci.o):
