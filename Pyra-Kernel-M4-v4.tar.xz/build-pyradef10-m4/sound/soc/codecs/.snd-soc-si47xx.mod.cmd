cmd_sound/soc/codecs/snd-soc-si47xx.mod := { echo  sound/soc/codecs/si47xx.o; echo; } > sound/soc/codecs/snd-soc-si47xx.mod
