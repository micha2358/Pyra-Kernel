cmd_sound/soc/codecs/snd-soc-ts3a225e.o := ld -EL   -r -o sound/soc/codecs/snd-soc-ts3a225e.o sound/soc/codecs/ts3a225e.o
