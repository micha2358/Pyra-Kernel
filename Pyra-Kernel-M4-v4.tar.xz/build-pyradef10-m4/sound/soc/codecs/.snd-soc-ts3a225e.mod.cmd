cmd_sound/soc/codecs/snd-soc-ts3a225e.mod := { echo  sound/soc/codecs/ts3a225e.o; echo; } > sound/soc/codecs/snd-soc-ts3a225e.mod
