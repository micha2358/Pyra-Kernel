cmd_sound/soc/codecs/snd-soc-twl6040.mod := { echo  sound/soc/codecs/twl6040.o; echo; } > sound/soc/codecs/snd-soc-twl6040.mod
