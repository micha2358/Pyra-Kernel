cmd_sound/soc/codecs/snd-soc-w2cbw003-bt.o := ld -EL   -r -o sound/soc/codecs/snd-soc-w2cbw003-bt.o sound/soc/codecs/w2cbw003-bt.o
