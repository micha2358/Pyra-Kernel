#include <linux/build-salt.h>
#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(.gnu.linkonce.this_module) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

MODULE_INFO(intree, "Y");

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

MODULE_INFO(depends, "");

MODULE_ALIAS("of:N*T*Cwi2wi,w2cbw003-codec");
MODULE_ALIAS("of:N*T*Cwi2wi,w2cbw003-codecC*");
MODULE_ALIAS("of:N*T*Cti,wl1835-codec");
MODULE_ALIAS("of:N*T*Cti,wl1835-codecC*");
MODULE_ALIAS("of:N*T*Cti,wl1837-codec");
MODULE_ALIAS("of:N*T*Cti,wl1837-codecC*");

MODULE_INFO(srcversion, "28DC843B63E4E4B978D1439");
