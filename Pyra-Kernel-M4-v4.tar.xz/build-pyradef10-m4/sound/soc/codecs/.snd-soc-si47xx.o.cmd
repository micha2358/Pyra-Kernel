cmd_sound/soc/codecs/snd-soc-si47xx.o := ld -EL   -r -o sound/soc/codecs/snd-soc-si47xx.o sound/soc/codecs/si47xx.o
