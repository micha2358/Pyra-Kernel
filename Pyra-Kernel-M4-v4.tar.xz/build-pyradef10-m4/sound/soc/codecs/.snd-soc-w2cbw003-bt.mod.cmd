cmd_sound/soc/codecs/snd-soc-w2cbw003-bt.mod := { echo  sound/soc/codecs/w2cbw003-bt.o; echo; } > sound/soc/codecs/snd-soc-w2cbw003-bt.mod
