cmd_sound/soc/codecs/snd-soc-ts3a227e.o := ld -EL   -r -o sound/soc/codecs/snd-soc-ts3a227e.o sound/soc/codecs/ts3a227e.o
