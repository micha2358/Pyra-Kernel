cmd_sound/soc/codecs/built-in.a := rm -f sound/soc/codecs/built-in.a; ar cDPrST sound/soc/codecs/built-in.a sound/soc/codecs/gtm601.o
