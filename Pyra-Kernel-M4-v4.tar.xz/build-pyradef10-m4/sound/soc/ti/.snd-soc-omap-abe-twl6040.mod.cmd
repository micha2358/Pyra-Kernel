cmd_sound/soc/ti/snd-soc-omap-abe-twl6040.mod := { echo  sound/soc/ti/omap-abe-twl6040.o; echo; } > sound/soc/ti/snd-soc-omap-abe-twl6040.mod
