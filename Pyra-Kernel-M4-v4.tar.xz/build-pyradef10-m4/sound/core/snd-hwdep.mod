sound/core/hwdep.o

