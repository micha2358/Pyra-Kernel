cmd_lib/ts_kmp.ko := ld -r -EL --build-id  -T /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/scripts/module-common.lds -o lib/ts_kmp.ko lib/ts_kmp.o lib/ts_kmp.mod.o;  true
