cmd_lib/bcd.o := gcc -Wp,-MD,lib/.bcd.o.d -nostdinc -isystem /usr/lib/gcc/arm-linux-gnueabihf/12/include -I/mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include -I./arch/arm/include/generated -I/mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include -I./include -I/mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/uapi -I./arch/arm/include/generated/uapi -I/mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi -I./include/generated/uapi -include /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/kconfig.h -include /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/compiler_types.h -D__KERNEL__ -mlittle-endian -Wall -Wundef -Werror=strict-prototypes -Wno-trigraphs -fno-strict-aliasing -fno-common -fshort-wchar -fno-PIE -Werror=implicit-function-declaration -Werror=implicit-int -Wno-format-security -std=gnu89 -msoft-float -fno-dwarf2-cfi-asm -fno-ipa-sra -mabi=aapcs-linux -mfpu=vfp -funwind-tables -marm -Wa,-mno-warn-deprecated -D__LINUX_ARM_ARCH__=7 -march=armv7-a -Wa,-march=armv7-a -Uarm -fno-delete-null-pointer-checks -Wno-frame-address -Wno-format-truncation -Wno-format-overflow -Wno-address-of-packed-member -O2 -fno-allow-store-data-races -Wframe-larger-than=1024 -fstack-protector-strong -Wno-unused-but-set-variable -Wimplicit-fallthrough -Wno-unused-const-variable -fomit-frame-pointer -fno-var-tracking-assignments -Wdeclaration-after-statement -Wvla -Wno-pointer-sign -Wno-stringop-truncation -Wno-zero-length-bounds -Wno-array-bounds -Wno-stringop-overflow -Wno-restrict -Wno-maybe-uninitialized -fno-strict-overflow -fno-merge-all-constants -fmerge-constants -fno-stack-check -fconserve-stack -Werror=date-time -Werror=incompatible-pointer-types -Werror=designated-init -fmacro-prefix-map=/mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/= -Wno-packed-not-aligned -I /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/lib -I ./lib    -DKBUILD_MODFILE='"lib/bcd"' -DKBUILD_BASENAME='"bcd"' -DKBUILD_MODNAME='"bcd"' -c -o lib/bcd.o /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/lib/bcd.c

source_lib/bcd.o := /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/lib/bcd.c

deps_lib/bcd.o := \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/kconfig.h \
    $(wildcard include/config/cpu/big/endian.h) \
    $(wildcard include/config/booger.h) \
    $(wildcard include/config/foo.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/compiler_types.h \
    $(wildcard include/config/have/arch/compiler/h.h) \
    $(wildcard include/config/enable/must/check.h) \
    $(wildcard include/config/optimize/inlining.h) \
    $(wildcard include/config/cc/has/asm/inline.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/compiler_attributes.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/compiler-gcc.h \
    $(wildcard include/config/retpoline.h) \
    $(wildcard include/config/arch/use/builtin/bswap.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/bcd.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/compiler.h \
    $(wildcard include/config/trace/branch/profiling.h) \
    $(wildcard include/config/profile/all/branches.h) \
    $(wildcard include/config/stack/validation.h) \
    $(wildcard include/config/kasan.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/compiler_types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/uapi/asm/types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/int-ll64.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/asm-generic/int-ll64.h \
  arch/arm/include/generated/uapi/asm/bitsperlong.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitsperlong.h \
    $(wildcard include/config/64bit.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/asm-generic/bitsperlong.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/posix_types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/stddef.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/stddef.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/uapi/asm/posix_types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/asm-generic/posix_types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/barrier.h \
    $(wildcard include/config/cpu/32v6k.h) \
    $(wildcard include/config/thumb2/kernel.h) \
    $(wildcard include/config/cpu/xsc3.h) \
    $(wildcard include/config/cpu/fa526.h) \
    $(wildcard include/config/arm/heavy/mb.h) \
    $(wildcard include/config/arm/dma/mem/bufferable.h) \
    $(wildcard include/config/smp.h) \
    $(wildcard include/config/cpu/spectre.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/barrier.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/kasan-checks.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/types.h \
    $(wildcard include/config/have/uid16.h) \
    $(wildcard include/config/uid16.h) \
    $(wildcard include/config/arch/dma/addr/t/64bit.h) \
    $(wildcard include/config/phys/addr/t/64bit.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/export.h \
    $(wildcard include/config/modversions.h) \
    $(wildcard include/config/module/rel/crcs.h) \
    $(wildcard include/config/have/arch/prel32/relocations.h) \
    $(wildcard include/config/modules.h) \
    $(wildcard include/config/trim/unused/ksyms.h) \
    $(wildcard include/config/unused/symbols.h) \

lib/bcd.o: $(deps_lib/bcd.o)

$(deps_lib/bcd.o):
