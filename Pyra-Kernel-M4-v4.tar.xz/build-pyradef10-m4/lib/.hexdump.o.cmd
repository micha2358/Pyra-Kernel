cmd_lib/hexdump.o := gcc -Wp,-MD,lib/.hexdump.o.d -nostdinc -isystem /usr/lib/gcc/arm-linux-gnueabihf/12/include -I/mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include -I./arch/arm/include/generated -I/mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include -I./include -I/mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/uapi -I./arch/arm/include/generated/uapi -I/mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi -I./include/generated/uapi -include /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/kconfig.h -include /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/compiler_types.h -D__KERNEL__ -mlittle-endian -Wall -Wundef -Werror=strict-prototypes -Wno-trigraphs -fno-strict-aliasing -fno-common -fshort-wchar -fno-PIE -Werror=implicit-function-declaration -Werror=implicit-int -Wno-format-security -std=gnu89 -msoft-float -fno-dwarf2-cfi-asm -fno-ipa-sra -mabi=aapcs-linux -mfpu=vfp -funwind-tables -marm -Wa,-mno-warn-deprecated -D__LINUX_ARM_ARCH__=7 -march=armv7-a -Wa,-march=armv7-a -Uarm -fno-delete-null-pointer-checks -Wno-frame-address -Wno-format-truncation -Wno-format-overflow -Wno-address-of-packed-member -O2 -fno-allow-store-data-races -Wframe-larger-than=1024 -fstack-protector-strong -Wno-unused-but-set-variable -Wimplicit-fallthrough -Wno-unused-const-variable -fomit-frame-pointer -fno-var-tracking-assignments -Wdeclaration-after-statement -Wvla -Wno-pointer-sign -Wno-stringop-truncation -Wno-zero-length-bounds -Wno-array-bounds -Wno-stringop-overflow -Wno-restrict -Wno-maybe-uninitialized -fno-strict-overflow -fno-merge-all-constants -fmerge-constants -fno-stack-check -fconserve-stack -Werror=date-time -Werror=incompatible-pointer-types -Werror=designated-init -fmacro-prefix-map=/mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/= -Wno-packed-not-aligned -I /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/lib -I ./lib    -DKBUILD_MODFILE='"lib/hexdump"' -DKBUILD_BASENAME='"hexdump"' -DKBUILD_MODNAME='"hexdump"' -c -o lib/hexdump.o /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/lib/hexdump.c

source_lib/hexdump.o := /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/lib/hexdump.c

deps_lib/hexdump.o := \
    $(wildcard include/config/printk.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/kconfig.h \
    $(wildcard include/config/cpu/big/endian.h) \
    $(wildcard include/config/booger.h) \
    $(wildcard include/config/foo.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/compiler_types.h \
    $(wildcard include/config/have/arch/compiler/h.h) \
    $(wildcard include/config/enable/must/check.h) \
    $(wildcard include/config/optimize/inlining.h) \
    $(wildcard include/config/cc/has/asm/inline.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/compiler_attributes.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/compiler-gcc.h \
    $(wildcard include/config/retpoline.h) \
    $(wildcard include/config/arch/use/builtin/bswap.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/types.h \
    $(wildcard include/config/have/uid16.h) \
    $(wildcard include/config/uid16.h) \
    $(wildcard include/config/arch/dma/addr/t/64bit.h) \
    $(wildcard include/config/phys/addr/t/64bit.h) \
    $(wildcard include/config/64bit.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/uapi/asm/types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/int-ll64.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/asm-generic/int-ll64.h \
  arch/arm/include/generated/uapi/asm/bitsperlong.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitsperlong.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/asm-generic/bitsperlong.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/posix_types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/stddef.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/stddef.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/compiler_types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/uapi/asm/posix_types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/asm-generic/posix_types.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/ctype.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/errno.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/errno.h \
  arch/arm/include/generated/uapi/asm/errno.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/asm-generic/errno.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/asm-generic/errno-base.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/kernel.h \
    $(wildcard include/config/preempt/voluntary.h) \
    $(wildcard include/config/debug/atomic/sleep.h) \
    $(wildcard include/config/mmu.h) \
    $(wildcard include/config/prove/locking.h) \
    $(wildcard include/config/panic/timeout.h) \
    $(wildcard include/config/tracing.h) \
    $(wildcard include/config/ftrace/mcount/record.h) \
  /usr/lib/gcc/arm-linux-gnueabihf/12/include/stdarg.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/limits.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/limits.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/linkage.h \
    $(wildcard include/config/x86.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/stringify.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/export.h \
    $(wildcard include/config/modversions.h) \
    $(wildcard include/config/module/rel/crcs.h) \
    $(wildcard include/config/have/arch/prel32/relocations.h) \
    $(wildcard include/config/modules.h) \
    $(wildcard include/config/trim/unused/ksyms.h) \
    $(wildcard include/config/unused/symbols.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/linkage.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/compiler.h \
    $(wildcard include/config/trace/branch/profiling.h) \
    $(wildcard include/config/profile/all/branches.h) \
    $(wildcard include/config/stack/validation.h) \
    $(wildcard include/config/kasan.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/barrier.h \
    $(wildcard include/config/cpu/32v6k.h) \
    $(wildcard include/config/thumb2/kernel.h) \
    $(wildcard include/config/cpu/xsc3.h) \
    $(wildcard include/config/cpu/fa526.h) \
    $(wildcard include/config/arm/heavy/mb.h) \
    $(wildcard include/config/arm/dma/mem/bufferable.h) \
    $(wildcard include/config/smp.h) \
    $(wildcard include/config/cpu/spectre.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/barrier.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/kasan-checks.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/bitops.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/bits.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/const.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/const.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/bitops.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/irqflags.h \
    $(wildcard include/config/trace/irqflags.h) \
    $(wildcard include/config/irqsoff/tracer.h) \
    $(wildcard include/config/preempt/tracer.h) \
    $(wildcard include/config/trace/irqflags/support.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/typecheck.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/irqflags.h \
    $(wildcard include/config/cpu/v7m.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/ptrace.h \
    $(wildcard include/config/arm/thumb.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/uapi/asm/ptrace.h \
    $(wildcard include/config/cpu/endian/be8.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/hwcap.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/uapi/asm/hwcap.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/irqflags.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/non-atomic.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/builtin-__fls.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/builtin-__ffs.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/builtin-fls.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/builtin-ffs.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/ffz.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/fls64.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/sched.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/hweight.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/arch_hweight.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/const_hweight.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/lock.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/atomic.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/atomic.h \
    $(wildcard include/config/generic/atomic64.h) \
    $(wildcard include/config/arm/lpae.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/prefetch.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/processor.h \
    $(wildcard include/config/have/hw/breakpoint.h) \
    $(wildcard include/config/binfmt/elf/fdpic.h) \
    $(wildcard include/config/arm/errata/754327.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/hw_breakpoint.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/unified.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/cache.h \
    $(wildcard include/config/arm/l1/cache/shift.h) \
    $(wildcard include/config/aeabi.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/cmpxchg.h \
    $(wildcard include/config/cpu/sa1100.h) \
    $(wildcard include/config/cpu/sa110.h) \
    $(wildcard include/config/cpu/v6.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/cmpxchg-local.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/atomic-fallback.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/atomic-long.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/find.h \
    $(wildcard include/config/generic/find/first/bit.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/le.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/uapi/asm/byteorder.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/byteorder/little_endian.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/byteorder/little_endian.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/swab.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/swab.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/swab.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/uapi/asm/swab.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/byteorder/generic.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/bitops/ext2-atomic-setbit.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/log2.h \
    $(wildcard include/config/arch/has/ilog2/u32.h) \
    $(wildcard include/config/arch/has/ilog2/u64.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/printk.h \
    $(wildcard include/config/message/loglevel/default.h) \
    $(wildcard include/config/console/loglevel/default.h) \
    $(wildcard include/config/console/loglevel/quiet.h) \
    $(wildcard include/config/early/printk.h) \
    $(wildcard include/config/printk/nmi.h) \
    $(wildcard include/config/dynamic/debug.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/init.h \
    $(wildcard include/config/strict/kernel/rwx.h) \
    $(wildcard include/config/strict/module/rwx.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/kern_levels.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/cache.h \
    $(wildcard include/config/arch/has/cache/line/size.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/kernel.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/uapi/linux/sysinfo.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/dynamic_debug.h \
    $(wildcard include/config/jump/label.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/jump_label.h \
    $(wildcard include/config/have/arch/jump/label/relative.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/jump_label.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/build_bug.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/div64.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/compiler.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/asm-generic/div64.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/arch/arm/include/asm/unaligned.h \
    $(wildcard include/config/have/efficient/unaligned/access.h) \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/unaligned/le_struct.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/unaligned/packed_struct.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/unaligned/be_byteshift.h \
  /mnt/pyra-kernel-m4/pyra-kernel-m4-source/linux-5.6.19-pyradef/include/linux/unaligned/generic.h \

lib/hexdump.o: $(deps_lib/hexdump.o)

$(deps_lib/hexdump.o):
