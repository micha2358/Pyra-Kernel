	.arch armv7-a
	.fpu softvfp
	.eabi_attribute 20, 1	@ Tag_ABI_FP_denormal
	.eabi_attribute 21, 1	@ Tag_ABI_FP_exceptions
	.eabi_attribute 23, 3	@ Tag_ABI_FP_number_model
	.eabi_attribute 24, 1	@ Tag_ABI_align8_needed
	.eabi_attribute 25, 1	@ Tag_ABI_align8_preserved
	.eabi_attribute 26, 2	@ Tag_ABI_enum_size
	.eabi_attribute 30, 2	@ Tag_ABI_optimization_goals
	.eabi_attribute 34, 1	@ Tag_CPU_unaligned_access
	.eabi_attribute 18, 2	@ Tag_ABI_PCS_wchar_t
	.file	"bounds.c"
@ GNU C89 (Debian 12.2.0-14+deb12u1) version 12.2.0 (arm-linux-gnueabihf)
@	compiled by GNU C version 12.2.0, GMP version 6.2.1, MPFR version 4.2.0, MPC version 1.3.1, isl version isl-0.25-GMP

@ GGC heuristics: --param ggc-min-expand=100 --param ggc-min-heapsize=131072
@ options passed: -mlittle-endian -mfloat-abi=soft -mabi=aapcs-linux -mfpu=vfp -marm -mtls-dialect=gnu -march=armv7-a -O2 -std=gnu90 -fno-strict-aliasing -fno-common -fshort-wchar -fno-PIE -fno-dwarf2-cfi-asm -fno-ipa-sra -funwind-tables -fno-delete-null-pointer-checks -fno-allow-store-data-races -fstack-protector-strong -fomit-frame-pointer -fno-strict-overflow -fno-merge-all-constants -fmerge-constants -fstack-check=no -fconserve-stack
	.text
	.syntax divided
	.syntax unified
	.arm
	.syntax unified
	.section	.text.startup,"ax",%progbits
	.align	2
	.global	main
	.syntax unified
	.arm
	.type	main, %function
main:
	.fnstart
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 0, uses_anonymous_args = 0
	@ link register save eliminated.
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/kernel/bounds.c:19: 	DEFINE(NR_PAGEFLAGS, __NR_PAGEFLAGS);
	.syntax divided
@ 19 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/kernel/bounds.c" 1
	
.ascii "->NR_PAGEFLAGS #22 __NR_PAGEFLAGS"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/kernel/bounds.c:20: 	DEFINE(MAX_NR_ZONES, __MAX_NR_ZONES);
@ 20 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/kernel/bounds.c" 1
	
.ascii "->MAX_NR_ZONES #4 __MAX_NR_ZONES"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/kernel/bounds.c:22: 	DEFINE(NR_CPUS_BITS, ilog2(CONFIG_NR_CPUS));
@ 22 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/kernel/bounds.c" 1
	
.ascii "->NR_CPUS_BITS #2 ilog2(CONFIG_NR_CPUS)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/kernel/bounds.c:24: 	DEFINE(SPINLOCK_SIZE, sizeof(spinlock_t));
@ 24 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/kernel/bounds.c" 1
	
.ascii "->SPINLOCK_SIZE #4 sizeof(spinlock_t)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/kernel/bounds.c:28: }
	.arm
	.syntax unified
	mov	r0, #0	@,
	bx	lr	@
	.fnend
	.size	main, .-main
	.ident	"GCC: (Debian 12.2.0-14+deb12u1) 12.2.0"
	.section	.note.GNU-stack,"",%progbits
