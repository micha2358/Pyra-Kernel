cmd_scripts/kconfig/lexer.lex.c := flex -oscripts/kconfig/lexer.lex.c -L /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/scripts/kconfig/lexer.l
