cmd_scripts/dtc/dtc-lexer.lex.c := flex -oscripts/dtc/dtc-lexer.lex.c -L /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/scripts/dtc/dtc-lexer.l
