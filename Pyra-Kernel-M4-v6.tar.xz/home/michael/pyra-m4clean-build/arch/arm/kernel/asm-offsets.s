	.arch armv7-a
	.fpu softvfp
	.eabi_attribute 20, 1	@ Tag_ABI_FP_denormal
	.eabi_attribute 21, 1	@ Tag_ABI_FP_exceptions
	.eabi_attribute 23, 3	@ Tag_ABI_FP_number_model
	.eabi_attribute 24, 1	@ Tag_ABI_align8_needed
	.eabi_attribute 25, 1	@ Tag_ABI_align8_preserved
	.eabi_attribute 26, 2	@ Tag_ABI_enum_size
	.eabi_attribute 30, 2	@ Tag_ABI_optimization_goals
	.eabi_attribute 34, 1	@ Tag_CPU_unaligned_access
	.eabi_attribute 18, 2	@ Tag_ABI_PCS_wchar_t
	.file	"asm-offsets.c"
@ GNU C89 (Debian 12.2.0-14+deb12u1) version 12.2.0 (arm-linux-gnueabihf)
@	compiled by GNU C version 12.2.0, GMP version 6.2.1, MPFR version 4.2.0, MPC version 1.3.1, isl version isl-0.25-GMP

@ GGC heuristics: --param ggc-min-expand=100 --param ggc-min-heapsize=131072
@ options passed: -mlittle-endian -mfloat-abi=soft -mabi=aapcs-linux -mfpu=vfp -marm -mtls-dialect=gnu -march=armv7-a -O2 -std=gnu90 -fno-strict-aliasing -fno-common -fshort-wchar -fno-PIE -fno-dwarf2-cfi-asm -fno-ipa-sra -funwind-tables -fno-delete-null-pointer-checks -fno-allow-store-data-races -fstack-protector-strong -fomit-frame-pointer -fno-strict-overflow -fno-merge-all-constants -fmerge-constants -fstack-check=no -fconserve-stack
	.text
	.syntax divided
	.syntax unified
	.arm
	.syntax unified
	.section	.text.startup,"ax",%progbits
	.align	2
	.global	main
	.syntax unified
	.arm
	.type	main, %function
main:
	.fnstart
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 0, uses_anonymous_args = 0
	@ link register save eliminated.
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:49:   DEFINE(TSK_ACTIVE_MM,		offsetof(struct task_struct, active_mm));
	.syntax divided
@ 49 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->TSK_ACTIVE_MM #628 offsetof(struct task_struct, active_mm)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:51:   DEFINE(TSK_STACK_CANARY,	offsetof(struct task_struct, stack_canary));
@ 51 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->TSK_STACK_CANARY #760 offsetof(struct task_struct, stack_canary)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:53:   BLANK();
@ 53 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->"
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:54:   DEFINE(TI_FLAGS,		offsetof(struct thread_info, flags));
@ 54 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->TI_FLAGS #0 offsetof(struct thread_info, flags)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:55:   DEFINE(TI_PREEMPT,		offsetof(struct thread_info, preempt_count));
@ 55 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->TI_PREEMPT #4 offsetof(struct thread_info, preempt_count)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:56:   DEFINE(TI_ADDR_LIMIT,		offsetof(struct thread_info, addr_limit));
@ 56 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->TI_ADDR_LIMIT #8 offsetof(struct thread_info, addr_limit)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:57:   DEFINE(TI_TASK,		offsetof(struct thread_info, task));
@ 57 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->TI_TASK #12 offsetof(struct thread_info, task)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:58:   DEFINE(TI_CPU,		offsetof(struct thread_info, cpu));
@ 58 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->TI_CPU #16 offsetof(struct thread_info, cpu)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:59:   DEFINE(TI_CPU_DOMAIN,		offsetof(struct thread_info, cpu_domain));
@ 59 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->TI_CPU_DOMAIN #20 offsetof(struct thread_info, cpu_domain)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:60:   DEFINE(TI_CPU_SAVE,		offsetof(struct thread_info, cpu_context));
@ 60 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->TI_CPU_SAVE #24 offsetof(struct thread_info, cpu_context)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:61:   DEFINE(TI_USED_CP,		offsetof(struct thread_info, used_cp));
@ 61 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->TI_USED_CP #76 offsetof(struct thread_info, used_cp)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:62:   DEFINE(TI_TP_VALUE,		offsetof(struct thread_info, tp_value));
@ 62 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->TI_TP_VALUE #92 offsetof(struct thread_info, tp_value)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:63:   DEFINE(TI_FPSTATE,		offsetof(struct thread_info, fpstate));
@ 63 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->TI_FPSTATE #104 offsetof(struct thread_info, fpstate)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:65:   DEFINE(TI_VFPSTATE,		offsetof(struct thread_info, vfpstate));
@ 65 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->TI_VFPSTATE #248 offsetof(struct thread_info, vfpstate)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:67:   DEFINE(VFP_CPU,		offsetof(union vfp_state, hard.cpu));
@ 67 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->VFP_CPU #272 offsetof(union vfp_state, hard.cpu)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:71:   DEFINE(TI_THUMBEE_STATE,	offsetof(struct thread_info, thumbee_state));
@ 71 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->TI_THUMBEE_STATE #528 offsetof(struct thread_info, thumbee_state)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:82:   DEFINE(THREAD_SZ_ORDER,	THREAD_SIZE_ORDER);
@ 82 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->THREAD_SZ_ORDER #1 THREAD_SIZE_ORDER"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:83:   BLANK();
@ 83 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->"
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:84:   DEFINE(S_R0,			offsetof(struct pt_regs, ARM_r0));
@ 84 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->S_R0 #0 offsetof(struct pt_regs, ARM_r0)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:85:   DEFINE(S_R1,			offsetof(struct pt_regs, ARM_r1));
@ 85 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->S_R1 #4 offsetof(struct pt_regs, ARM_r1)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:86:   DEFINE(S_R2,			offsetof(struct pt_regs, ARM_r2));
@ 86 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->S_R2 #8 offsetof(struct pt_regs, ARM_r2)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:87:   DEFINE(S_R3,			offsetof(struct pt_regs, ARM_r3));
@ 87 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->S_R3 #12 offsetof(struct pt_regs, ARM_r3)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:88:   DEFINE(S_R4,			offsetof(struct pt_regs, ARM_r4));
@ 88 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->S_R4 #16 offsetof(struct pt_regs, ARM_r4)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:89:   DEFINE(S_R5,			offsetof(struct pt_regs, ARM_r5));
@ 89 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->S_R5 #20 offsetof(struct pt_regs, ARM_r5)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:90:   DEFINE(S_R6,			offsetof(struct pt_regs, ARM_r6));
@ 90 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->S_R6 #24 offsetof(struct pt_regs, ARM_r6)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:91:   DEFINE(S_R7,			offsetof(struct pt_regs, ARM_r7));
@ 91 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->S_R7 #28 offsetof(struct pt_regs, ARM_r7)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:92:   DEFINE(S_R8,			offsetof(struct pt_regs, ARM_r8));
@ 92 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->S_R8 #32 offsetof(struct pt_regs, ARM_r8)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:93:   DEFINE(S_R9,			offsetof(struct pt_regs, ARM_r9));
@ 93 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->S_R9 #36 offsetof(struct pt_regs, ARM_r9)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:94:   DEFINE(S_R10,			offsetof(struct pt_regs, ARM_r10));
@ 94 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->S_R10 #40 offsetof(struct pt_regs, ARM_r10)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:95:   DEFINE(S_FP,			offsetof(struct pt_regs, ARM_fp));
@ 95 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->S_FP #44 offsetof(struct pt_regs, ARM_fp)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:96:   DEFINE(S_IP,			offsetof(struct pt_regs, ARM_ip));
@ 96 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->S_IP #48 offsetof(struct pt_regs, ARM_ip)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:97:   DEFINE(S_SP,			offsetof(struct pt_regs, ARM_sp));
@ 97 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->S_SP #52 offsetof(struct pt_regs, ARM_sp)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:98:   DEFINE(S_LR,			offsetof(struct pt_regs, ARM_lr));
@ 98 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->S_LR #56 offsetof(struct pt_regs, ARM_lr)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:99:   DEFINE(S_PC,			offsetof(struct pt_regs, ARM_pc));
@ 99 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->S_PC #60 offsetof(struct pt_regs, ARM_pc)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:100:   DEFINE(S_PSR,			offsetof(struct pt_regs, ARM_cpsr));
@ 100 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->S_PSR #64 offsetof(struct pt_regs, ARM_cpsr)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:101:   DEFINE(S_OLD_R0,		offsetof(struct pt_regs, ARM_ORIG_r0));
@ 101 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->S_OLD_R0 #68 offsetof(struct pt_regs, ARM_ORIG_r0)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:102:   DEFINE(PT_REGS_SIZE,		sizeof(struct pt_regs));
@ 102 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->PT_REGS_SIZE #72 sizeof(struct pt_regs)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:103:   DEFINE(SVC_DACR,		offsetof(struct svc_pt_regs, dacr));
@ 103 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->SVC_DACR #72 offsetof(struct svc_pt_regs, dacr)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:104:   DEFINE(SVC_ADDR_LIMIT,	offsetof(struct svc_pt_regs, addr_limit));
@ 104 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->SVC_ADDR_LIMIT #76 offsetof(struct svc_pt_regs, addr_limit)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:105:   DEFINE(SVC_REGS_SIZE,		sizeof(struct svc_pt_regs));
@ 105 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->SVC_REGS_SIZE #80 sizeof(struct svc_pt_regs)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:106:   BLANK();
@ 106 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->"
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:107:   DEFINE(SIGFRAME_RC3_OFFSET,	offsetof(struct sigframe, retcode[3]));
@ 107 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->SIGFRAME_RC3_OFFSET #756 offsetof(struct sigframe, retcode[3])"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:108:   DEFINE(RT_SIGFRAME_RC3_OFFSET, offsetof(struct rt_sigframe, sig.retcode[3]));
@ 108 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->RT_SIGFRAME_RC3_OFFSET #884 offsetof(struct rt_sigframe, sig.retcode[3])"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:109:   BLANK();
@ 109 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->"
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:111:   DEFINE(L2X0_R_PHY_BASE,	offsetof(struct l2x0_regs, phy_base));
@ 111 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->L2X0_R_PHY_BASE #0 offsetof(struct l2x0_regs, phy_base)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:112:   DEFINE(L2X0_R_AUX_CTRL,	offsetof(struct l2x0_regs, aux_ctrl));
@ 112 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->L2X0_R_AUX_CTRL #4 offsetof(struct l2x0_regs, aux_ctrl)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:113:   DEFINE(L2X0_R_TAG_LATENCY,	offsetof(struct l2x0_regs, tag_latency));
@ 113 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->L2X0_R_TAG_LATENCY #8 offsetof(struct l2x0_regs, tag_latency)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:114:   DEFINE(L2X0_R_DATA_LATENCY,	offsetof(struct l2x0_regs, data_latency));
@ 114 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->L2X0_R_DATA_LATENCY #12 offsetof(struct l2x0_regs, data_latency)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:115:   DEFINE(L2X0_R_FILTER_START,	offsetof(struct l2x0_regs, filter_start));
@ 115 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->L2X0_R_FILTER_START #16 offsetof(struct l2x0_regs, filter_start)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:116:   DEFINE(L2X0_R_FILTER_END,	offsetof(struct l2x0_regs, filter_end));
@ 116 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->L2X0_R_FILTER_END #20 offsetof(struct l2x0_regs, filter_end)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:117:   DEFINE(L2X0_R_PREFETCH_CTRL,	offsetof(struct l2x0_regs, prefetch_ctrl));
@ 117 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->L2X0_R_PREFETCH_CTRL #24 offsetof(struct l2x0_regs, prefetch_ctrl)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:118:   DEFINE(L2X0_R_PWR_CTRL,	offsetof(struct l2x0_regs, pwr_ctrl));
@ 118 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->L2X0_R_PWR_CTRL #28 offsetof(struct l2x0_regs, pwr_ctrl)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:119:   BLANK();
@ 119 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->"
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:122:   DEFINE(MM_CONTEXT_ID,		offsetof(struct mm_struct, context.id.counter));
@ 122 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->MM_CONTEXT_ID #376 offsetof(struct mm_struct, context.id.counter)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:123:   BLANK();
@ 123 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->"
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:125:   DEFINE(VMA_VM_MM,		offsetof(struct vm_area_struct, vm_mm));
@ 125 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->VMA_VM_MM #32 offsetof(struct vm_area_struct, vm_mm)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:126:   DEFINE(VMA_VM_FLAGS,		offsetof(struct vm_area_struct, vm_flags));
@ 126 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->VMA_VM_FLAGS #48 offsetof(struct vm_area_struct, vm_flags)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:127:   BLANK();
@ 127 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->"
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:128:   DEFINE(VM_EXEC,	       	VM_EXEC);
@ 128 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->VM_EXEC #4 VM_EXEC"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:129:   BLANK();
@ 129 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->"
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:130:   DEFINE(PAGE_SZ,	       	PAGE_SIZE);
@ 130 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->PAGE_SZ #4096 PAGE_SIZE"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:131:   BLANK();
@ 131 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->"
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:132:   DEFINE(SYS_ERROR0,		0x9f0000);
@ 132 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->SYS_ERROR0 #10420224 0x9f0000"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:133:   BLANK();
@ 133 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->"
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:134:   DEFINE(SIZEOF_MACHINE_DESC,	sizeof(struct machine_desc));
@ 134 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->SIZEOF_MACHINE_DESC #120 sizeof(struct machine_desc)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:135:   DEFINE(MACHINFO_TYPE,		offsetof(struct machine_desc, nr));
@ 135 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->MACHINFO_TYPE #0 offsetof(struct machine_desc, nr)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:136:   DEFINE(MACHINFO_NAME,		offsetof(struct machine_desc, name));
@ 136 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->MACHINFO_NAME #4 offsetof(struct machine_desc, name)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:137:   BLANK();
@ 137 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->"
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:138:   DEFINE(PROC_INFO_SZ,		sizeof(struct proc_info_list));
@ 138 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->PROC_INFO_SZ #52 sizeof(struct proc_info_list)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:139:   DEFINE(PROCINFO_INITFUNC,	offsetof(struct proc_info_list, __cpu_flush));
@ 139 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->PROCINFO_INITFUNC #16 offsetof(struct proc_info_list, __cpu_flush)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:140:   DEFINE(PROCINFO_MM_MMUFLAGS,	offsetof(struct proc_info_list, __cpu_mm_mmu_flags));
@ 140 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->PROCINFO_MM_MMUFLAGS #8 offsetof(struct proc_info_list, __cpu_mm_mmu_flags)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:141:   DEFINE(PROCINFO_IO_MMUFLAGS,	offsetof(struct proc_info_list, __cpu_io_mmu_flags));
@ 141 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->PROCINFO_IO_MMUFLAGS #12 offsetof(struct proc_info_list, __cpu_io_mmu_flags)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:142:   BLANK();
@ 142 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->"
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:150:   DEFINE(CPU_SLEEP_SIZE,	offsetof(struct processor, suspend_size));
@ 150 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->CPU_SLEEP_SIZE #40 offsetof(struct processor, suspend_size)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:151:   DEFINE(CPU_DO_SUSPEND,	offsetof(struct processor, do_suspend));
@ 151 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->CPU_DO_SUSPEND #44 offsetof(struct processor, do_suspend)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:152:   DEFINE(CPU_DO_RESUME,		offsetof(struct processor, do_resume));
@ 152 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->CPU_DO_RESUME #48 offsetof(struct processor, do_resume)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:158:   DEFINE(SLEEP_SAVE_SP_SZ,	sizeof(struct sleep_save_sp));
@ 158 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->SLEEP_SAVE_SP_SZ #8 sizeof(struct sleep_save_sp)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:159:   DEFINE(SLEEP_SAVE_SP_PHYS,	offsetof(struct sleep_save_sp, save_ptr_stash_phys));
@ 159 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->SLEEP_SAVE_SP_PHYS #4 offsetof(struct sleep_save_sp, save_ptr_stash_phys)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:160:   DEFINE(SLEEP_SAVE_SP_VIRT,	offsetof(struct sleep_save_sp, save_ptr_stash));
@ 160 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->SLEEP_SAVE_SP_VIRT #0 offsetof(struct sleep_save_sp, save_ptr_stash)"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:162:   BLANK();
@ 162 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->"
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:163:   DEFINE(DMA_BIDIRECTIONAL,	DMA_BIDIRECTIONAL);
@ 163 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->DMA_BIDIRECTIONAL #0 DMA_BIDIRECTIONAL"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:164:   DEFINE(DMA_TO_DEVICE,		DMA_TO_DEVICE);
@ 164 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->DMA_TO_DEVICE #1 DMA_TO_DEVICE"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:165:   DEFINE(DMA_FROM_DEVICE,	DMA_FROM_DEVICE);
@ 165 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->DMA_FROM_DEVICE #2 DMA_FROM_DEVICE"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:166:   BLANK();
@ 166 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->"
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:167:   DEFINE(CACHE_WRITEBACK_ORDER, __CACHE_WRITEBACK_ORDER);
@ 167 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->CACHE_WRITEBACK_ORDER #6 __CACHE_WRITEBACK_ORDER"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:168:   DEFINE(CACHE_WRITEBACK_GRANULE, __CACHE_WRITEBACK_GRANULE);
@ 168 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->CACHE_WRITEBACK_GRANULE #64 __CACHE_WRITEBACK_GRANULE"	@
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:169:   BLANK();
@ 169 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->"
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:177:   BLANK();
@ 177 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->"
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:181:   BLANK();
@ 181 "/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c" 1
	
.ascii "->"
@ 0 "" 2
@ /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/kernel/asm-offsets.c:194: }
	.arm
	.syntax unified
	mov	r0, #0	@,
	bx	lr	@
	.fnend
	.size	main, .-main
	.ident	"GCC: (Debian 12.2.0-14+deb12u1) 12.2.0"
	.section	.note.GNU-stack,"",%progbits
