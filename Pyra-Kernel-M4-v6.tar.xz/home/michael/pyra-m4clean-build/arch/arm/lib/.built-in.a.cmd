cmd_arch/arm/lib/built-in.a := rm -f arch/arm/lib/built-in.a; ar cDPrST arch/arm/lib/built-in.a arch/arm/lib/lib-ksyms.o
