cmd_arch/arm/lib/copy_page.o := gcc -Wp,-MD,arch/arm/lib/.copy_page.o.d -nostdinc -isystem /usr/lib/gcc/arm-linux-gnueabihf/12/include -I/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/include -I./arch/arm/include/generated -I/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include -I./include -I/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/include/uapi -I./arch/arm/include/generated/uapi -I/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include/uapi -I./include/generated/uapi -include /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include/linux/kconfig.h -D__KERNEL__ -mlittle-endian -D__ASSEMBLY__ -fno-PIE -mabi=aapcs-linux -mfpu=vfp -funwind-tables -marm -Wa,-mno-warn-deprecated -D__LINUX_ARM_ARCH__=7 -march=armv7-a -Wa,-march=armv7-a -include asm/unified.h -msoft-float -I /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/lib -I ./arch/arm/lib    -c -o arch/arm/lib/copy_page.o /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/lib/copy_page.S

source_arch/arm/lib/copy_page.o := /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/lib/copy_page.S

deps_arch/arm/lib/copy_page.o := \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include/linux/kconfig.h \
    $(wildcard include/config/cpu/big/endian.h) \
    $(wildcard include/config/booger.h) \
    $(wildcard include/config/foo.h) \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/include/asm/unified.h \
    $(wildcard include/config/cpu/v7m.h) \
    $(wildcard include/config/thumb2/kernel.h) \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include/linux/linkage.h \
    $(wildcard include/config/x86.h) \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include/linux/compiler_types.h \
    $(wildcard include/config/have/arch/compiler/h.h) \
    $(wildcard include/config/enable/must/check.h) \
    $(wildcard include/config/optimize/inlining.h) \
    $(wildcard include/config/cc/has/asm/inline.h) \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include/linux/stringify.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include/linux/export.h \
    $(wildcard include/config/modversions.h) \
    $(wildcard include/config/module/rel/crcs.h) \
    $(wildcard include/config/have/arch/prel32/relocations.h) \
    $(wildcard include/config/modules.h) \
    $(wildcard include/config/trim/unused/ksyms.h) \
    $(wildcard include/config/unused/symbols.h) \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/include/asm/linkage.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/include/asm/assembler.h \
    $(wildcard include/config/cpu/endian/be8.h) \
    $(wildcard include/config/cpu/feroceon.h) \
    $(wildcard include/config/trace/irqflags.h) \
    $(wildcard include/config/preempt/count.h) \
    $(wildcard include/config/smp.h) \
    $(wildcard include/config/debug/bugverbose.h) \
    $(wildcard include/config/kprobes.h) \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/include/asm/ptrace.h \
    $(wildcard include/config/arm/thumb.h) \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/include/uapi/asm/ptrace.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/include/asm/hwcap.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/include/uapi/asm/hwcap.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/include/asm/opcodes-virt.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/include/asm/opcodes.h \
    $(wildcard include/config/cpu/endian/be32.h) \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/include/asm/asm-offsets.h \
  include/generated/asm-offsets.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/include/asm/page.h \
    $(wildcard include/config/mmu.h) \
    $(wildcard include/config/cpu/copy/v4wt.h) \
    $(wildcard include/config/cpu/copy/v4wb.h) \
    $(wildcard include/config/cpu/copy/feroceon.h) \
    $(wildcard include/config/cpu/copy/fa.h) \
    $(wildcard include/config/cpu/sa1100.h) \
    $(wildcard include/config/cpu/xscale.h) \
    $(wildcard include/config/cpu/xsc3.h) \
    $(wildcard include/config/cpu/copy/v6.h) \
    $(wildcard include/config/kuser/helpers.h) \
    $(wildcard include/config/arm/lpae.h) \
    $(wildcard include/config/have/arch/pfn/valid.h) \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include/asm-generic/getorder.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/include/asm/thread_info.h \
    $(wildcard include/config/stackprotector/per/task.h) \
    $(wildcard include/config/crunch.h) \
    $(wildcard include/config/arm/thumbee.h) \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include/linux/compiler.h \
    $(wildcard include/config/trace/branch/profiling.h) \
    $(wildcard include/config/profile/all/branches.h) \
    $(wildcard include/config/stack/validation.h) \
    $(wildcard include/config/kasan.h) \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/include/asm/fpstate.h \
    $(wildcard include/config/vfpv3.h) \
    $(wildcard include/config/iwmmxt.h) \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/include/asm/uaccess-asm.h \
    $(wildcard include/config/cpu/use/domains.h) \
    $(wildcard include/config/cpu/spectre.h) \
    $(wildcard include/config/cpu/sw/domain/pan.h) \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/include/asm/domain.h \
    $(wildcard include/config/io/36.h) \
    $(wildcard include/config/cpu/cp15/mmu.h) \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/include/asm/memory.h \
    $(wildcard include/config/need/mach/memory/h.h) \
    $(wildcard include/config/page/offset.h) \
    $(wildcard include/config/highmem.h) \
    $(wildcard include/config/dram/base.h) \
    $(wildcard include/config/dram/size.h) \
    $(wildcard include/config/xip/kernel.h) \
    $(wildcard include/config/have/tcm.h) \
    $(wildcard include/config/arm/patch/phys/virt.h) \
    $(wildcard include/config/phys/offset.h) \
    $(wildcard include/config/xip/phys/addr.h) \
    $(wildcard include/config/debug/virtual.h) \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include/linux/const.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include/uapi/linux/const.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include/linux/types.h \
    $(wildcard include/config/have/uid16.h) \
    $(wildcard include/config/uid16.h) \
    $(wildcard include/config/arch/dma/addr/t/64bit.h) \
    $(wildcard include/config/phys/addr/t/64bit.h) \
    $(wildcard include/config/64bit.h) \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include/uapi/linux/types.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/include/uapi/asm/types.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include/asm-generic/int-ll64.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include/uapi/asm-generic/int-ll64.h \
  arch/arm/include/generated/uapi/asm/bitsperlong.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include/asm-generic/bitsperlong.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include/uapi/asm-generic/bitsperlong.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include/linux/sizes.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include/asm-generic/memory_model.h \
    $(wildcard include/config/flatmem.h) \
    $(wildcard include/config/discontigmem.h) \
    $(wildcard include/config/sparsemem/vmemmap.h) \
    $(wildcard include/config/sparsemem.h) \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include/linux/pfn.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/include/asm/cache.h \
    $(wildcard include/config/arm/l1/cache/shift.h) \
    $(wildcard include/config/aeabi.h) \

arch/arm/lib/copy_page.o: $(deps_arch/arm/lib/copy_page.o)

$(deps_arch/arm/lib/copy_page.o):
