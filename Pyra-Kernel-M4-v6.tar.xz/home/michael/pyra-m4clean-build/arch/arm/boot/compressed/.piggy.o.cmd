cmd_arch/arm/boot/compressed/piggy.o := gcc -Wp,-MD,arch/arm/boot/compressed/.piggy.o.d -nostdinc -isystem /usr/lib/gcc/arm-linux-gnueabihf/12/include -I/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/include -I./arch/arm/include/generated -I/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include -I./include -I/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/include/uapi -I./arch/arm/include/generated/uapi -I/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include/uapi -I./include/generated/uapi -include /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include/linux/kconfig.h -D__KERNEL__ -mlittle-endian -D__ASSEMBLY__ -fno-PIE -mabi=aapcs-linux -mfpu=vfp -funwind-tables -marm -Wa,-mno-warn-deprecated -D__LINUX_ARM_ARCH__=7 -march=armv7-a -Wa,-march=armv7-a -include asm/unified.h -msoft-float -DZIMAGE -I /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/compressed -I ./arch/arm/boot/compressed    -c -o arch/arm/boot/compressed/piggy.o /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/compressed/piggy.S

source_arch/arm/boot/compressed/piggy.o := /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/compressed/piggy.S

deps_arch/arm/boot/compressed/piggy.o := \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/include/linux/kconfig.h \
    $(wildcard include/config/cpu/big/endian.h) \
    $(wildcard include/config/booger.h) \
    $(wildcard include/config/foo.h) \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/include/asm/unified.h \
    $(wildcard include/config/cpu/v7m.h) \
    $(wildcard include/config/thumb2/kernel.h) \

arch/arm/boot/compressed/piggy.o: $(deps_arch/arm/boot/compressed/piggy.o)

$(deps_arch/arm/boot/compressed/piggy.o):
