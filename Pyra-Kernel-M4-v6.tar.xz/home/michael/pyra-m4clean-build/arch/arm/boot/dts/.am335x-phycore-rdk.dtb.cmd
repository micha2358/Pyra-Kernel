cmd_arch/arm/boot/dts/am335x-phycore-rdk.dtb := mkdir -p arch/arm/boot/dts/ ; gcc -E -Wp,-MD,arch/arm/boot/dts/.am335x-phycore-rdk.dtb.d.pre.tmp -nostdinc -I/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/scripts/dtc/include-prefixes -undef -D__DTS__ -x assembler-with-cpp -o arch/arm/boot/dts/.am335x-phycore-rdk.dtb.dts.tmp /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/dts/am335x-phycore-rdk.dts ; ./scripts/dtc/dtc -O dtb -o arch/arm/boot/dts/am335x-phycore-rdk.dtb -b 0 -i/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/dts/ -i/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/scripts/dtc/include-prefixes -Wno-unit_address_vs_reg -Wno-unit_address_format -Wno-avoid_unnecessary_addr_size -Wno-alias_paths -Wno-graph_child_address -Wno-simple_bus_reg -Wno-unique_unit_address -Wno-pci_device_reg  -d arch/arm/boot/dts/.am335x-phycore-rdk.dtb.d.dtc.tmp arch/arm/boot/dts/.am335x-phycore-rdk.dtb.dts.tmp ; cat arch/arm/boot/dts/.am335x-phycore-rdk.dtb.d.pre.tmp arch/arm/boot/dts/.am335x-phycore-rdk.dtb.d.dtc.tmp > arch/arm/boot/dts/.am335x-phycore-rdk.dtb.d

source_arch/arm/boot/dts/am335x-phycore-rdk.dtb := /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/dts/am335x-phycore-rdk.dts

deps_arch/arm/boot/dts/am335x-phycore-rdk.dtb := \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/dts/am335x-phycore-som.dtsi \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/dts/am33xx.dtsi \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/scripts/dtc/include-prefixes/dt-bindings/bus/ti-sysc.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/scripts/dtc/include-prefixes/dt-bindings/gpio/gpio.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/scripts/dtc/include-prefixes/dt-bindings/pinctrl/am33xx.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/scripts/dtc/include-prefixes/dt-bindings/pinctrl/omap.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/scripts/dtc/include-prefixes/dt-bindings/clock/am3.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/dts/am33xx-l4.dtsi \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/dts/am33xx-clocks.dtsi \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/scripts/dtc/include-prefixes/dt-bindings/interrupt-controller/irq.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/dts/tps65910.dtsi \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/dts/am335x-pcm-953.dtsi \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/scripts/dtc/include-prefixes/dt-bindings/input/input.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/scripts/dtc/include-prefixes/dt-bindings/input/linux-event-codes.h \

arch/arm/boot/dts/am335x-phycore-rdk.dtb: $(deps_arch/arm/boot/dts/am335x-phycore-rdk.dtb)

$(deps_arch/arm/boot/dts/am335x-phycore-rdk.dtb):
