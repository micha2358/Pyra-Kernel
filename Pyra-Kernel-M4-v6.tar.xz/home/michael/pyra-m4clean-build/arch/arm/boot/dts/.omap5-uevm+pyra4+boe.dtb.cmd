cmd_arch/arm/boot/dts/omap5-uevm+pyra4+boe.dtb := mkdir -p arch/arm/boot/dts/ ; gcc -E -Wp,-MD,arch/arm/boot/dts/.omap5-uevm+pyra4+boe.dtb.d.pre.tmp -nostdinc -I/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/scripts/dtc/include-prefixes -undef -D__DTS__ -x assembler-with-cpp -o arch/arm/boot/dts/.omap5-uevm+pyra4+boe.dtb.dts.tmp /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/dts/omap5-uevm+pyra4+boe.dts ; ./scripts/dtc/dtc -O dtb -o arch/arm/boot/dts/omap5-uevm+pyra4+boe.dtb -b 0 -i/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/dts/ -i/mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/scripts/dtc/include-prefixes -Wno-unit_address_vs_reg -Wno-unit_address_format -Wno-avoid_unnecessary_addr_size -Wno-alias_paths -Wno-graph_child_address -Wno-simple_bus_reg -Wno-unique_unit_address -Wno-pci_device_reg  -d arch/arm/boot/dts/.omap5-uevm+pyra4+boe.dtb.d.dtc.tmp arch/arm/boot/dts/.omap5-uevm+pyra4+boe.dtb.dts.tmp ; cat arch/arm/boot/dts/.omap5-uevm+pyra4+boe.dtb.d.pre.tmp arch/arm/boot/dts/.omap5-uevm+pyra4+boe.dtb.d.dtc.tmp > arch/arm/boot/dts/.omap5-uevm+pyra4+boe.dtb.d

source_arch/arm/boot/dts/omap5-uevm+pyra4+boe.dtb := /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/dts/omap5-uevm+pyra4+boe.dts

deps_arch/arm/boot/dts/omap5-uevm+pyra4+boe.dtb := \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/dts/omap5-uevm+pyra4.dts \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/dts/omap5-uevm.dts \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/dts/omap5-board-common.dtsi \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/dts/omap5.dtsi \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/scripts/dtc/include-prefixes/dt-bindings/bus/ti-sysc.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/scripts/dtc/include-prefixes/dt-bindings/gpio/gpio.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/scripts/dtc/include-prefixes/dt-bindings/interrupt-controller/arm-gic.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/scripts/dtc/include-prefixes/dt-bindings/interrupt-controller/irq.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/scripts/dtc/include-prefixes/dt-bindings/pinctrl/omap.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/scripts/dtc/include-prefixes/dt-bindings/clock/omap5.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/dts/omap4-cpu-thermal.dtsi \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/scripts/dtc/include-prefixes/dt-bindings/thermal/thermal.h \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/dts/omap5-gpu-thermal.dtsi \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/dts/omap5-core-thermal.dtsi \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/dts/omap5-l4.dtsi \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/dts/omap54xx-clocks.dtsi \
  /mnt/pyra-kernel-m4/Pyra-M4-Letux-Cleanup-Integrated-Source/kernel/linux-5.6.19-pyradef/arch/arm/boot/dts/omap5-l4-abe.dtsi \

arch/arm/boot/dts/omap5-uevm+pyra4+boe.dtb: $(deps_arch/arm/boot/dts/omap5-uevm+pyra4+boe.dtb)

$(deps_arch/arm/boot/dts/omap5-uevm+pyra4+boe.dtb):
