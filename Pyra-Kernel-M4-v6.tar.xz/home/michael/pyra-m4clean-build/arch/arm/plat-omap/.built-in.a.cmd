cmd_arch/arm/plat-omap/built-in.a := rm -f arch/arm/plat-omap/built-in.a; ar cDPrST arch/arm/plat-omap/built-in.a arch/arm/plat-omap/sram.o arch/arm/plat-omap/dma.o arch/arm/plat-omap/counter_32k.o
