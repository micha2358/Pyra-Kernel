cmd_arch/arm/net/built-in.a := rm -f arch/arm/net/built-in.a; ar cDPrST arch/arm/net/built-in.a arch/arm/net/bpf_jit_32.o
